import json
import os
import time
import uuid
from fastapi import HTTPException, Request
from pydantic import BaseModel, Field
import accounts
from configuration import read_json, validate_value


class SetupRequest(BaseModel):
    revision: str = Field(max_length=64)
    changes: dict[str, str] = Field(default_factory=dict)
    action: str = 'save'


def install(app, state, live):
    def status():
        result = read_json(live / 'setup-result.json')
        pending = (state / 'setup-request.json').exists() or (result.get('running') and time.time() - result.get('updated', 0) < 180)
        return dict(pending=bool(pending), result=result)

    def reviewed(body):
        info = read_json(live / 'setup.json')
        if info.get('revision') != body.revision or time.time() - info.get('updated', 0) > 30:
            raise HTTPException(409, 'Configuration changed or unavailable. Reload and review again.')
        if len(body.changes) > 150:
            raise HTTPException(400, 'Too many changes')
        fields = {f['id']: f for g in info.get('groups', []) for f in g['fields']}
        rows = []
        for id, value in body.changes.items():
            f = fields.get(id)
            if not f:
                raise HTTPException(400, 'Unknown setting')
            try:
                normalized = validate_value(f, value)
                if normalized is None:
                    continue
            except ValueError as exc:
                raise HTTPException(400, str(exc))
            if value != f['value']:
                rows.append(dict(label=f['label'], before='Saved secret' if f['kind'] == 'secret' else f['value'], after='Replace secret' if f['kind'] == 'secret' else value))
        return rows

    @app.get('/api/configuration')
    def get_setup(request: Request):
        accounts.require(state, request, admin=True)
        info = read_json(live / 'setup.json')
        if not info or info.get('error') or time.time() - info.get('updated', 0) > 30:
            raise HTTPException(503, info.get('error', 'Configuration worker is unavailable'))
        return dict(info, **status())

    @app.get('/api/configuration/status')
    def get_status(request: Request):
        accounts.require(state, request, admin=True)
        return status()

    @app.post('/api/configuration/review')
    def review(body: SetupRequest, request: Request):
        accounts.require(state, request, write=True, admin=True)
        return dict(changes=reviewed(body))

    @app.post('/api/configuration')
    def save(body: SetupRequest, request: Request):
        actor = accounts.require(state, request, write=True, admin=True)
        if body.action not in ('save', 'apply'):
            raise HTTPException(400, 'Unknown action')
        rows = reviewed(body)
        if body.action == 'save' and not rows:
            raise HTTPException(400, 'No changes to save')
        if status()['pending']:
            raise HTTPException(409, 'A configuration request is already running')
        job = dict(id=uuid.uuid4().hex, created=time.time(), action=body.action, changes=body.changes, revision=body.revision)
        encoded = json.dumps(job)
        if len(encoded.encode()) > 32768:
            raise HTTPException(400, 'Request too large')
        # Publish complete JSON atomically, without replacing an existing request.
        temp = state / ('setup-' + job['id'] + '.tmp')
        try:
            fd = os.open(temp, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
            with os.fdopen(fd, 'w') as f:
                f.write(encoded)
            os.link(temp, state / 'setup-request.json')
        except FileExistsError:
            raise HTTPException(409, 'Another configuration request is pending')
        finally:
            temp.unlink(missing_ok=True)
        with accounts.connect(state) as con:
            accounts.record(con, actor['username'], 'configuration ' + body.action, str(len(rows)) + ' settings; values hidden')
        return dict(id=job['id'], message='Request accepted')
