"""Configure MMOD display/listener settings without editing radio configuration."""
import argparse
import ipaddress
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess

def parser():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ['site','network','description','bind','ini','host-service','firewall-interface']:
        p.add_argument('--'+name)
    p.add_argument('--port',type=int)
    p.add_argument('--check',action='store_true')
    return p

def make_plan(args, directory=Path('/etc/mmod')):
    file=directory/'config.json'
    config=json.loads(file.read_text()) if file.exists() else dict(
        site='My DMR Repeater', network='MMOD', description='Radio dashboard',
        mmdvm_ini='/etc/mmdvm/MMDVM.ini',host_service='mmdvmhost.service',
        services=['mmdvmhost.service','dmrgateway.service','dmr2ysf.service','ysfgateway.service'],backup_files=[])
    env=directory/'listen.env'
    values=dict(line.split('=',1) for line in env.read_text().splitlines() if '=' in line and not line.startswith('#')) if env.exists() else {}
    bind=args.bind or values.get('MMOD_BIND')
    if not bind: raise ValueError('First install requires --bind LOCAL_IPV4')
    address=ipaddress.IPv4Address(bind)
    if address.is_unspecified or address.is_multicast or int(address)==0xffffffff:
        raise ValueError('Use one specific local address, not a wildcard/multicast address')
    port=args.port if args.port is not None else int(values.get('MMOD_PORT','8000'))
    if not 1024 <= port <= 65535: raise ValueError('Port must be 1024–65535')
    for key in ['site','network','description']:
        value=getattr(args,key)
        if value is not None:
            if not value.strip() or len(value)>160 or any(ord(c)<32 for c in value):
                raise ValueError(key+' must be 1–160 printable characters')
            config[key]=value
    if args.ini:
        if not PurePosixPath(args.ini).is_absolute(): raise ValueError('--ini requires an absolute Linux path')
        config['backup_files']=[x for x in config['backup_files'] if x!=config['mmdvm_ini']]
        config['mmdvm_ini']=args.ini
    if args.host_service:
        if not re.fullmatch(r'[A-Za-z0-9_.@-]+\.service',args.host_service): raise ValueError('Invalid systemd service name')
        old=config.get('host_service','mmdvmhost.service')
        config['host_service']=args.host_service
        config['services']=[args.host_service if s==old else s for s in config['services']]
    files=config['backup_files']+[config['mmdvm_ini'],'/etc/mmod/config.json','/etc/mmod/listen.env']
    files+=['/etc/systemd/system/'+s for s in config['services']]
    config['backup_files']=list(dict.fromkeys(files))
    interface=args.firewall_interface
    if interface and not re.fullmatch(r'[A-Za-z0-9_.:-]{1,15}',interface): raise ValueError('Invalid interface name')
    return dict(config=config,bind=str(address),port=port,firewall_interface=interface,ini_exists=Path(config['mmdvm_ini']).is_file())

def check_interface(plan):
    interfaces=json.loads(subprocess.check_output(['ip','-j','-4','addr','show'],text=True))
    matches=[x['ifname'] for x in interfaces if any(a.get('local')==plan['bind'] for a in x.get('addr_info',[]))]
    if not matches: raise ValueError('Bind address is not assigned to this Dell; check ip -br -4 addr')
    if plan['firewall_interface'] and plan['firewall_interface'] not in matches:
        raise ValueError('The firewall interface does not have the bind address')

def write_plan(plan,directory=Path('/etc/mmod')):
    directory.mkdir(parents=True,exist_ok=True)
    for name,data in [('config.json',json.dumps(plan['config'],indent=2)+'\n'),('listen.env',f'MMOD_BIND={plan["bind"]}\nMMOD_PORT={plan["port"]}\n')]:
        temp=directory/(name+'.tmp'); temp.write_text(data); os.chmod(temp,0o640)
        shutil.chown(temp,user='root',group='mmod'); temp.replace(directory/name)

if __name__=='__main__':
    p=parser(); args=p.parse_args()
    try:
        plan=make_plan(args); check_interface(plan)
        if args.check: print(json.dumps(plan))
        else:
            if os.geteuid()!=0: raise ValueError('Run with sudo to save settings')
            write_plan(plan)
            print(f'Saved. URL: http://{plan["bind"]}:{plan["port"]}')
            print('Run the MMOD collector and restart MMOD to apply. Radio settings were not changed.')
    except (ValueError,OSError,subprocess.SubprocessError) as error:
        p.exit(2,str(error)+'\n')
