"""Local named accounts. Existing administrator credentials remain valid."""
import hashlib, hmac, json, secrets, sqlite3, time
from fastapi import HTTPException

def connect(state):
    con=sqlite3.connect(state/'auth.sqlite', timeout=10)
    con.execute('CREATE TABLE IF NOT EXISTS users (username TEXT PRIMARY KEY, salt TEXT, hash TEXT, role TEXT, enabled INTEGER)')
    con.execute('CREATE TABLE IF NOT EXISTS sessions (id TEXT PRIMARY KEY, csrf TEXT, expires REAL, username TEXT)')
    if 'username' not in [r[1] for r in con.execute('PRAGMA table_info(sessions)')]:
        con.execute('ALTER TABLE sessions ADD COLUMN username TEXT')
        con.execute('DELETE FROM sessions')
    con.execute('CREATE TABLE IF NOT EXISTS attempts (ip TEXT, stamp REAL)')
    con.execute('CREATE TABLE IF NOT EXISTS audit (stamp REAL, username TEXT, action TEXT, detail TEXT)')
    if not con.execute('SELECT 1 FROM users LIMIT 1').fetchone():
        old=json.loads((state/'credentials.json').read_text())
        con.execute('INSERT INTO users VALUES (?,?,?,?,1)',(old['username'],old['salt'],old['hash'],'admin'))
    con.commit()
    return con

def digest(password,salt):
    return hashlib.pbkdf2_hmac('sha256',password.encode(),bytes.fromhex(salt),600000).hex()

def record(con,user,action,detail=''):
    con.execute('INSERT INTO audit VALUES (?,?,?,?)',(time.time(),user,action,detail[:500]))
    con.execute('DELETE FROM audit WHERE rowid NOT IN (SELECT rowid FROM audit ORDER BY rowid DESC LIMIT 2000)')

def identity(state,request):
    key=hashlib.sha256(request.cookies.get('mmod_session','').encode()).hexdigest()
    with connect(state) as con:
        row=con.execute('SELECT s.csrf,s.expires,u.username,u.role,u.enabled FROM sessions s JOIN users u ON u.username=s.username WHERE s.id=?',(key,)).fetchone()
    if not row or row[1]<time.time() or not row[4]: raise HTTPException(401,'Sign in to access administration')
    return dict(csrf=row[0],username=row[2],role=row[3])

def require(state,request,write=False,admin=False):
    user=identity(state,request)
    if write and not hmac.compare_digest(request.headers.get('x-csrf-token',''),user['csrf']): raise HTTPException(403,'Invalid request token')
    if admin and user['role']!='admin': raise HTTPException(403,'Administrator access required')
    return user
