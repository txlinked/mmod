"""Build a single shell installer with all MMOD sources embedded."""
import base64
import hashlib
import io
from pathlib import Path
import sys
import tarfile
import textwrap

ROOT = Path(__file__).resolve().parent

def build(destination):
    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer, mode='w:gz') as archive:
        for path in sorted(ROOT.rglob('*')):
            if path.resolve() == destination.resolve() or path.name == 'mmodinstall.sh':
                continue
            relative = path.relative_to(ROOT)
            if any(p in {'.git', '__pycache__', 'venv'} for p in relative.parts):
                continue
            if not path.is_file() or path.is_symlink():
                continue
            if path.name in {'credentials.json', 'initial-admin.txt'} or path.suffix in {'.pyc', '.sqlite'}:
                continue
            data = path.read_bytes().replace(b'\r\n', b'\n')
            item = tarfile.TarInfo('mmod/' + relative.as_posix())
            item.size = len(data)
            item.mode = 0o755 if path.suffix == '.sh' else 0o644
            archive.addfile(item, io.BytesIO(data))
    payload = buffer.getvalue()
    digest = hashlib.sha256(payload).hexdigest()
    header = '''#!/bin/bash
# MMOD standalone, single-file installer for Debian 12/13 x86_64.
# Run: sudo bash mmodinstall.sh
# Includes the dashboard, setup prompts, password tool, and documentation.
# No ai02, NAS, separate archive, or source checkout is required.
# Internet is needed for Debian/Python dependencies during installation.
set -euo pipefail
case "${1:-}" in
  --help|-h)
    echo 'Run: sudo bash mmodinstall.sh'
    echo 'Answer the setup questions. Press Enter to accept defaults.'
    echo 'Installs MMOD only; Debian and radio software are separate.'
    echo 'Use --verify-only to check the embedded package without installing.'
    exit 0 ;;
esac
if [[ "${1:-}" != --verify-only && $(id -u) != 0 ]]; then
  echo 'Please run: sudo bash mmodinstall.sh' >&2
  exit 1
fi
for utility in mktemp base64 sha256sum tar; do
  command -v "$utility" >/dev/null || { echo "Missing utility: $utility" >&2; exit 1; }
done
umask 077
mmod_stage=$(mktemp -d /tmp/mmod-installer.XXXXXXXX)
cleanup_mmod_stage() {
  case "$mmod_stage" in /tmp/mmod-installer.*) rm -rf -- "$mmod_stage" ;; esac
}
trap cleanup_mmod_stage EXIT
base64 --decode > "$mmod_stage/payload.tar.gz" <<'MMOD_EMBEDDED_PAYLOAD'
'''
    footer = f'''MMOD_EMBEDDED_PAYLOAD
printf '%s  %s\\n' '{digest}' "$mmod_stage/payload.tar.gz" | sha256sum --check --status
tar -xzf "$mmod_stage/payload.tar.gz" --no-same-owner -C "$mmod_stage"
test -f "$mmod_stage/mmod/install.sh"
test -f "$mmod_stage/mmod/install_wizard.py"
test -f "$mmod_stage/mmod/static/index.html"
if [[ "${{1:-}}" == --verify-only ]]; then
  echo 'PASS: embedded MMOD package checksum and extraction. No installation performed.'
  exit 0
fi
# Execute a file, not a stdin pipe, so interactive questions keep the terminal.
bash "$mmod_stage/mmod/install.sh" "$@"
'''
    destination.write_text(header + '\n'.join(textwrap.wrap(base64.b64encode(payload).decode(), 76)) + '\n' + footer, encoding='utf-8', newline='\n')
    print(f'Built {destination.name}: {destination.stat().st_size} bytes')

if __name__ == '__main__':
    build(Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT.parent / 'mmodinstall.sh')
