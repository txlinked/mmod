"""Discover existing local AllStar AMI access. Never modify Asterisk settings."""
import configparser,json,os,re,subprocess
from pathlib import Path

def config(path,seen=None):
    seen=set() if seen is None else seen
    path=Path(path).resolve()
    if path in seen or len(seen)>32:raise ValueError('Configuration include loop')
    seen.add(path);lines=[]
    for line in path.read_text().splitlines():
        m=re.match(r'^\s*#(?:try)?include\s+["<]?([^">]+)[">]?\s*$',line)
        if m:
            pattern=m[1].strip();matches=sorted(path.parent.glob(pattern)) if not pattern.startswith('/') else [Path(pattern)]
            for child in matches:
                if child.is_file():lines.append(config(child,seen))
        elif not line.lstrip().startswith('#'):lines.append(line)
    return '\n'.join(lines)

def discover():
    from allstar import ami
    base=Path('/etc/asterisk')
    if not (base/'rpt.conf').exists():print('AllStar: not detected; setup remains available in Administration.');return
    rpt=config(base/'rpt.conf');nodes=list(dict.fromkeys(re.findall(r'^\s*\[(\d{3,9})\]',rpt,re.M)))
    p=configparser.ConfigParser(interpolation=None,strict=False,inline_comment_prefixes=(';',))
    p.read_string(config(base/'manager.conf'))
    if p.get('general','enabled',fallback='no').lower() not in ('yes','true','1'):print('AllStar: AMI disabled; configure access in Administration.');return
    bind=p.get('general','bindaddr',fallback='127.0.0.1');host='127.0.0.1' if bind in ('0.0.0.0','::','127.0.0.1') else bind
    candidates=[]
    for user in p.sections():
        if user=='general' or not p.get(user,'secret',fallback=''):continue
        rights=p.get(user,'write',fallback='').lower().split(',')
        if not any(r.strip() in ('command','all') for r in rights):continue
        candidates.append(dict(host=host,port=p.getint('general','port',fallback=5038),username=user,secret=p.get(user,'secret'),tls=False))
    path=Path('/var/lib/mmod/state/allstar-nodes.json');saved=json.loads(path.read_text()) if path.exists() else {};added=0
    for node in nodes:
        if node in saved:continue
        for candidate in candidates:
            try:
                text=ami(candidate,'rpt stats '+node)
                if not text or 'error' in text.lower():continue
            except Exception:continue
            saved[node]=dict(candidate,node=node,name='Local AllStar '+node,favorites=[]);added+=1;break
    if added:
        temp=path.with_suffix('.discover.tmp');temp.write_text(json.dumps(saved));temp.chmod(0o600)
        import pwd,grp
        os.chown(temp,pwd.getpwnam('mmod').pw_uid,grp.getgrnam('mmod').gr_gid);temp.replace(path)
    print('AllStar: added',added,'local nodes; existing entries preserved. Unmatched nodes require Administration setup.')
if __name__=='__main__':
    try:discover()
    except Exception:print('AllStar discovery incomplete. Add the local node in Administration; no Asterisk settings changed.')
