"""Bounded, read-only radio inspection. Only MMOD snapshots/backups are written."""
import configparser
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tarfile
import time

ROOT = Path(os.environ.get('MMOD_ROOT', '/var/lib/mmod'))
LIVE = Path(os.environ.get('MMOD_LIVE', '/run/mmod'))
CONFIG = Path(os.environ.get('MMOD_CONFIG', '/etc/mmod/config.json'))
MODES = [('DMR', 'DMR'), ('D-Star', 'D-Star'), ('YSF', 'System Fusion'),
         ('P25', 'P25'), ('NXDN', 'NXDN'), ('M17', 'M17'),
         ('POCSAG', 'POCSAG'), ('FM', 'FM')]

def read(path, default=''):
    try:
        return Path(path).read_text(errors='replace').strip()
    except OSError:
        return default

def atomic(path, data):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(data))
    os.chmod(temp, 0o640)
    if os.geteuid() == 0:
        shutil.chown(temp, group='mmod')
    temp.replace(path)

def tail(path):
    try:
        with open(path, 'rb') as f:
            f.seek(0, 2)
            size = f.tell()
            f.seek(max(0, size - 131072))
            lines = f.read().decode(errors='replace').splitlines()
            return lines[1:] if size > 131072 else lines
    except OSError:
        return []

def activity(lines):
    result = []
    pattern = re.compile(r'DMR Slot ([12]), received (RF|network) end of voice transmission from (\S+) to (?:TG )?(\S+), ([\d.]+) seconds(?:, (.*))?')
    for line in lines:
        match = pattern.search(line)
        if match:
            slot, source, caller, target, seconds, quality = match.groups()
            result.append(dict(time=line[3:26], slot=int(slot), source=source,
                               caller=caller, target=target, seconds=float(seconds), quality=quality or ''))
    return result[-40:][::-1]

def services(names):
    command = ['systemctl', 'show', '--no-pager', '--property=Id,LoadState,ActiveState,SubState'] + names
    output = subprocess.run(command, capture_output=True, text=True, timeout=8).stdout
    found = {}
    for block in output.strip().split('\n\n'):
        item = dict(line.split('=', 1) for line in block.splitlines() if '=' in line)
        if item.get('Id'):
            found[item['Id']] = item
    return [dict(name=name, installed=found.get(name, {}).get('LoadState') == 'loaded',
                 status=found.get(name, {}).get('ActiveState', 'unknown'),
                 detail=found.get(name, {}).get('SubState', 'unknown')) for name in names]

def backup(config):
    folder = ROOT / 'backups'
    latest = sorted(folder.glob('config-*.tar.gz'))
    request = ROOT / 'state/backup-request'
    due = not latest or time.time() - latest[-1].stat().st_mtime > 86400
    if not due and not request.exists():
        return
    if latest and time.time() - latest[-1].stat().st_mtime < 60:
        return
    name = 'config-' + dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '.tar.gz'
    path = folder / name
    temp = folder / (name + '.tmp')
    manifest = {}
    with tarfile.open(temp, 'w:gz') as archive:
        for item in config['backup_files']:
            src = Path(item)
            if src.is_file() and not src.is_symlink():
                archive.add(src, arcname=str(src).lstrip('/'), recursive=False)
                manifest[str(src)] = hashlib.sha256(src.read_bytes()).hexdigest()
    os.chmod(temp, 0o640)
    shutil.chown(temp, group='mmod')
    temp.replace(path)
    atomic(folder / (name + '.json'), dict(files=manifest, sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    request.unlink(missing_ok=True)
    for old in sorted(folder.glob('config-*.tar.gz'))[:-14]:
        old.unlink()
        old.with_name(old.name + '.json').unlink(missing_ok=True)

def collect():
    config = json.loads(CONFIG.read_text())
    ini = configparser.ConfigParser(interpolation=None, strict=False, inline_comment_prefixes=('#', ';'))
    ini.read(config['mmdvm_ini'])
    def get(section, key, default=''):
        return ini.get(section, key, fallback=default)
    service_list = services(config['services'])
    log_folder = Path(get('Log', 'FilePath', '.'))
    if not log_folder.is_absolute():
        log_folder = Path(config['mmdvm_ini']).parent / log_folder
    log_root = get('Log', 'FileRoot', 'MMDVM')
    candidates = list(log_folder.glob(log_root + '*.log'))
    log = max(candidates, key=lambda p: p.stat().st_mtime) if candidates else None
    lines = tail(log) if log else []
    memory = {line.split(':')[0]: int(line.split()[1]) for line in read('/proc/meminfo').splitlines()}
    total = memory.get('MemTotal', 1)
    used = total - memory.get('MemAvailable', 0)
    disk = shutil.disk_usage('/')
    temperatures = []
    for sensor in Path('/sys/class/thermal').glob('thermal_zone*/temp'):
        try:
            value = float(read(sensor)) / 1000
            if 0 < value < 150:
                temperatures.append(value)
        except ValueError:
            pass
    cpu = next((line.split(':', 1)[1].strip() for line in read('/proc/cpuinfo').splitlines() if line.startswith('model name')), 'Unknown')
    cpu_ticks = list(map(int, read('/proc/stat').splitlines()[0].split()[1:]))
    previous = json.loads(read(LIVE / 'snapshot.json', '{}'))
    ticks = sum(cpu_ticks[:8]); idle = cpu_ticks[3] + cpu_ticks[4]
    delta = ticks - previous.get('_ticks', ticks)
    cpu_percent = round(100 * (1 - (idle - previous.get('_idle', idle)) / delta), 1) if delta > 0 else None
    os_name = next((line.split('=', 1)[1].strip('"') for line in read('/etc/os-release').splitlines() if line.startswith('PRETTY_NAME=')), 'Linux')
    modem_port = get('Modem', 'UARTPort') or get('Modem', 'Port')
    serial = [dict(name=p.name, target=os.path.realpath(p)) for p in Path('/dev/serial/by-id').glob('*')]
    modes = [dict(name=name, configured=ini.has_section(section), enabled=get(section, 'Enable') == '1') for name, section in MODES]
    def frequency(key):
        try:
            value=config.get('display_frequencies_hz',{}).get(key) or get('Info',key) or get('Modem',key)
            return f'{int(value) / 1000000:.5f}'
        except (ValueError,TypeError):
            return 'Unknown'
    snapshot = dict(updated=time.time(), site=config['site'],
                    network=config.get('network', 'MMOD'), description=config.get('description', 'Radio dashboard'),
                    host_service=config.get('host_service', 'mmdvmhost.service'), callsign=get('General', 'Callsign'),
                    dmr_id=get('General', 'Id'), location=get('Info', 'Location'),
                    tx=frequency('TXFrequency'), rx=frequency('RXFrequency'),
                    color_code=str(config.get('display_color_code',get('DMR', 'ColorCode'))), duplex=get('General', 'Duplex') == '1',
                    system=dict(hostname=os.uname().nodename, os=os_name, architecture=os.uname().machine,
                                hardware=read('/sys/class/dmi/id/product_name', 'Unknown'), cpu=cpu,
                                cpu_percent=cpu_percent, cores=os.cpu_count(), load=os.getloadavg()[0],
                                memory_used=used // 1024, memory_total=total // 1024,
                                disk_used=disk.used, disk_total=disk.total, disk_free=disk.free,
                                temperature=max(temperatures) if temperatures else None,
                                uptime=float(read('/proc/uptime', '0').split()[0])),
                    modem=dict(port=modem_port, serial=serial, firmware='Not reported',
                               note='Mode flags reflect MMDVMHost configuration; firmware capabilities are not assumed.'),
                    services=service_list, modes=modes, activity=activity(lines),
                    log_updated=log.stat().st_mtime if log else None, _ticks=ticks, _idle=idle)
    atomic(LIVE / 'snapshot.json', snapshot)
    # Log view contains radio events only, not arbitrary configuration or credentials.
    safe = [line for line in lines if re.search(r'DMR Slot [12],|Mode set to|overflow|watchdog', line, re.I)
            and not re.search(r'password|secret|token|authorization', line, re.I)]
    atomic(LIVE / 'logs.json', dict(lines=safe[-200:], updated=time.time()))
    backup(config)

if __name__ == '__main__':
    collect()
