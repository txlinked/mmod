"""TGIF dynamic controls using the network's session-update API (no radio config writes)."""
import re,urllib.request,urllib.error
from brandmeister import profile

def destination(value):
    if not str(value).isdigit():raise ValueError('Enter a numeric TGIF talkgroup')
    tg=int(value)
    if 6000001<=tg<=6999999:tg-=6000000
    if not 1<=tg<=999999:raise ValueError('Use TGIF 1–999999 or RF prefix 6000001–6999999')
    return tg

def operate(job):
    p=profile();device=str(p.get('tgif_id',''));slot=job.get('slot')
    if not re.fullmatch(r'[0-9]{6,9}',device):raise ValueError('Enabled TGIF gateway was not detected')
    if slot not in p.get('tgif_slots',[]):raise ValueError('TGIF routing is not configured on this timeslot')
    op=job.get('operation')
    if op not in ('link','unlink'):raise ValueError('Only dynamic TGIF Link and Unlink are supported')
    tg=4000 if op=='unlink' else destination(job.get('destination',''))
    url=f'http://tgif.network:5040/api/sessions/update/{device}/{slot-1}/{tg}'
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self,*args,**kwargs):return None
    try:
        req=urllib.request.Request(url,headers={'User-Agent':'MMOD TGIF control','Content-Type':'application/x-www-form-urlencoded'})
        with urllib.request.build_opener(NoRedirect).open(req,timeout=10) as r:raw=r.read(4097)
        if raw.strip()!=b'200':raise ValueError('TGIF did not confirm the command. Check gateway login and shared public IP.')
    except (urllib.error.URLError,TimeoutError):raise ValueError('TGIF control API unavailable; no link confirmation received') from None
    return f'TGIF accepted TS{slot} '+('disconnect' if tg==4000 else f'TG {tg}')+'. Remote audio/link state is not independently verified.'
