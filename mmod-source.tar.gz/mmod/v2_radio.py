"""Discovered allowlisted gateway operations, executed by the root worker."""
import configparser, json, os, re, shutil, socket, subprocess, time
from pathlib import Path

from brandmeister import profile, credentials

RUNTIME=Path('/run/mmod-radio-control')
BASE_MODES=[('dmr','DMR / BrandMeister'),('dmr2ysf','DMR2YSF'),('ysf','YSF / FCS gateway'),('dstar','D-Star'),('p25','P25'),('nxdn','NXDN'),('m17','M17'),('pocsag','POCSAG / DAPNET'),('fm','FM'),('ysf2dmr','YSF2DMR'),('dmr2nxdn','DMR2NXDN'),('dmr2p25','DMR2P25')]
def catalog():
    p=profile();c=credentials();bm=bool(p.get('bm_id'));key=bool(c.get('key') and c.get('device')==p.get('bm_id') and p.get('duplex'))
    out=[]
    for id,name in BASE_MODES:
        ready=(id=='dmr' and (bm or bool(p.get('bm_net')))) or (id=='ysf' and bool(p.get('ysf'))) or (id=='dmr2ysf' and bool(p.get('ysf') and p.get('ysf_net') and p.get('ysf_slot')))
        link=(key if id=='dmr' else ready and id in ('ysf','dmr2ysf'))
        note='Setup required: compatible gateway controls have not been detected.'
        if ready:note='Shares the YSF gateway. Link changes briefly restart this gateway.'
        if id=='dmr' and ready:note='BrandMeister static TG subscriptions persist until Unlink. Adding a TG preserves other subscriptions.' if key else 'Public BrandMeister link status available. Add an API key in Administration for TG controls.'
        out.append(dict(id=id,name=name,ready=bool(ready),link=bool(link),note=note,slot=p.get('ysf_slot',2) if id in ('ysf','dmr2ysf') else None,enable=bool(p.get('bm_net')) if id=='dmr' else bool(ready),default=bool(link and id!='dmr')))
    return out

def validate(job):
    mode=next((m for m in catalog() if m['id']==job.get('mode')),None)
    if not mode or not mode['ready']: raise ValueError('Setup required for this mode')
    action=job.get('operation')
    if action not in {'link','unlink','enable','disable','default'}: raise ValueError('Unknown radio operation')
    if action in {'link','unlink','default'} and not mode['link']: raise ValueError(mode['note'])
    if job.get('slot') not in (1,2): raise ValueError('Select TS1 or TS2')
    if job['mode'] in ('dmr2ysf','ysf') and job['slot']!=mode['slot']: raise ValueError('Use the configured gateway timeslot')
    if action in ('enable','disable') and not mode['enable']: raise ValueError('Network enable/disable is not configured')
    if action=='default' and not mode['default']: raise ValueError('BrandMeister static links already persist until Unlink')
    if job['mode']=='dmr' and action in ('link','unlink'):
        if job.get('family')!='BrandMeister':raise ValueError('Only the configured BrandMeister network can be controlled')
        dest=job.get('destination','')
        if not dest.isdigit() or not 0<int(dest)<=16777215:raise ValueError('Enter a valid DMR talkgroup')
        return mode
    if action in {'link','default'}:
        dest=job.get('destination',''); family=job.get('family')
        if family=='FCS':
            if not re.fullmatch(r'FCS[0-9]{5}',dest): raise ValueError('Use an FCS destination such as FCS00334')
        elif family=='YSF':
            if not re.fullmatch(r'[0-9]{5}',dest): raise ValueError('Use a five-digit YSF reflector number')
        else: raise ValueError('Select YSF or FCS')
    return mode

def system(*args):
    r=subprocess.run(['/usr/bin/systemctl',*args],capture_output=True,text=True,timeout=35)
    if r.returncode: raise RuntimeError(r.stderr.strip()[:300] or 'Service operation failed')
    return r.stdout.strip()

def udp(command):
    with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as s:
        s.settimeout(3); s.connect(('127.0.0.1',7643)); s.send(command.encode())
        reply=s.recv(1024).decode()
    if reply=='KO': raise RuntimeError('DMRGateway rejected operation')
    return reply

def prepare_dmr_remote():
    path=Path(profile()['dmr']['ini'])
    text=path.read_text()
    c=configparser.ConfigParser(strict=False); c.read_string(text)
    section=c['Remote Control']
    if section.get('Address')!='127.0.0.1' or section.get('Port')!='7643':
        raise ValueError('DMRGateway local control setup needs review')
    if section.get('Enable')=='1': return
    updated=re.sub(r'(?ms)(^\[Remote Control\]\s*\n)(.*?)(?=^\[|\Z)',
        lambda m:m[1]+re.sub(r'(?m)^Enable=.*$','Enable=1',m[2]),text)
    if updated==text: raise ValueError('DMRGateway remote setting missing')
    backup=Path('/var/backups/mmod-v2'); backup.mkdir(mode=0o700,exist_ok=True)
    shutil.copy2(path,backup/'DMRGateway.before-remote.ini')
    atomic(path,updated,path.stat().st_mode & 0o777)
    try: system('restart','dmrgateway.service'); system('is-active','dmrgateway.service')
    except Exception:
        atomic(path,text,path.stat().st_mode & 0o777)
        system('restart','dmrgateway.service')
        raise
    time.sleep(1)

def startup(text,dest):
    # Preserve comments, permissions, and all unrelated radio settings.
    parts=re.split(r'(?m)^(\[[^\n]+\]\s*)$',text)
    for i in range(1,len(parts),2):
        if parts[i].strip()=='[Network]':
            body=parts[i+1]
            if not re.search(r'(?m)^Startup=',body): raise ValueError('YSF startup setting missing')
            parts[i+1]=re.sub(r'(?m)^Startup=.*$',lambda m:'Startup='+dest,body)
            return ''.join(parts)
    raise ValueError('YSF network settings missing')

def atomic(path,text,mode=0o600):
    tmp=path.with_name(path.name+'.mmod-new')
    fd=os.open(tmp,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,mode)
    try:
        with os.fdopen(fd,'w') as f: f.write(text); f.flush(); os.fsync(f.fileno())
        tmp.replace(path)
    finally: tmp.unlink(missing_ok=True)

def execute(job):
    validate(job)
    # Refuse changing radio routing during traffic or while monitoring is stale.
    radio=json.loads(Path('/run/mmod/radio.json').read_text())
    if time.time()-radio.get('updated',0)>10: raise ValueError('Live monitor is stale; try again when it reconnects')
    if any(s.get('transmission') for s in radio.get('slots',[])): raise ValueError('Radio is keyed; wait until idle and try again')
    op=job['operation']; mode=job['mode']
    p=profile()
    if mode=='dmr' and op in ('link','unlink'):
        from brandmeister import operate
        return operate(job)
    if op in {'enable','disable'}:
        if mode in {'dmr','dmr2ysf'}:
            prepare_dmr_remote()
            reply=udp(op+' '+(p['bm_net'] if mode=='dmr' else p['ysf_net']))
            return op+' accepted by DMRGateway. '+reply+' (runtime only)'
        system('start' if op=='enable' else 'stop','ysfgateway.service')
        return 'YSFGateway '+('started' if op=='enable' else 'stopped')+'; shared DMR2YSF path affected.'
    YSF=Path(p['ysf']['ini'])
    text=YSF.read_text(); dest=job.get('destination','') if op!='unlink' else ''
    # Validate destinations against the gateway's own installed host files.
    c=configparser.ConfigParser(strict=False); c.read_string(text)
    if dest:
        host=Path(c['FCS Network']['Rooms'] if job['family']=='FCS' else c['YSF Network']['Hosts'])
        raw=host.read_text()
        if job['family']=='FCS':
            if not any(line.split(';')[0].strip()==dest for line in raw.splitlines()): raise ValueError('FCS room is not in this gateway host list')
        else:
            if not re.search(r'(?<!\d)'+re.escape(dest)+r'(?!\d)',raw): raise ValueError('YSF reflector is not in this gateway host list')
    if op=='default':
        backup=Path('/var/backups/mmod-v2'); backup.mkdir(mode=0o700,exist_ok=True)
        shutil.copy2(YSF,backup/'YSFGateway.before-default.ini')
        atomic(YSF,startup(text,dest),YSF.stat().st_mode & 0o777)
        return 'Saved startup destination '+dest+'. Current link unchanged.'
    state=RUNTIME/'selection.json'
    if op=='link' and not job.get('auto_disconnect',True):
        prior=json.loads(state.read_text()).get('destination') if state.exists() else c['Network'].get('Startup','')
        if prior and prior!=dest: raise ValueError('Unlink first, or select Disconnect before switching')
    RUNTIME.mkdir(mode=0o700,exist_ok=True)
    runtime=RUNTIME/'YSFGateway.ini'
    previous=runtime.read_text() if runtime.exists() else None
    atomic(runtime,startup(text,dest))
    drop=Path('/run/systemd/system/ysfgateway.service.d'); drop.mkdir(parents=True,exist_ok=True)
    override=drop/'90-mmod.conf'; old=override.read_text() if override.exists() else None
    atomic(override,'[Service]\nExecStart=\nExecStart='+p['ysf']['binary']+' /run/mmod-radio-control/YSFGateway.ini\n',0o644)
    try:
        system('daemon-reload'); system('restart','ysfgateway.service'); system('is-active','ysfgateway.service')
    except Exception:
        if old is None: override.unlink(missing_ok=True)
        else: atomic(override,old,0o644)
        if previous is not None: atomic(runtime,previous)
        system('daemon-reload'); system('restart','ysfgateway.service')
        raise
    atomic(state,json.dumps({'destination':dest,'updated':time.time()}))
    return ('Link requested to '+dest+'. Gateway running; confirm traffic in activity.' if dest else 'Gateway restarted without a startup link.')+' Saved boot default unchanged.'
