"""Discovered allowlisted gateway operations, executed by the root worker."""
import configparser, json, os, re, shutil, socket, subprocess, time
from pathlib import Path

from brandmeister import profile, credentials

RUNTIME=Path('/run/mmod-radio-control')
BASE_MODES=[('dmr','DMR / BrandMeister'),('dmr2ysf','DMR2YSF'),('ysf','YSF / FCS gateway'),('dstar','D-Star'),('p25','P25'),('nxdn','NXDN'),('m17','M17'),('pocsag','POCSAG / DAPNET'),('fm','FM'),('ysf2dmr','YSF2DMR'),('dmr2nxdn','DMR2NXDN'),('dmr2p25','DMR2P25')]
def catalog():
    p=profile();c=credentials();bm=bool(p.get('bm_id'));key=bool(c.get('key') and c.get('device')==p.get('bm_id') and p.get('duplex'))
    out=[]
    for id,name in BASE_MODES:
        ready=(id=='dmr' and (bm or bool(p.get('bm_net')))) or (id=='ysf' and bool(p.get('ysf')) and p.get('ysf_route')=='native') or (id=='dmr2ysf' and bool(p.get('ysf') and p.get('ysf_net') and p.get('ysf_slot') and p.get('ysf_route')=='crossmode'))
        link=(key if id=='dmr' else ready and id in ('ysf','dmr2ysf'))
        note='Setup required: compatible gateway controls have not been detected.'
        if ready:note='Native Fusion gateway; no DMR timeslot. Link changes briefly restart this gateway.' if id=='ysf' else 'DMR2YSF bridge. Link changes briefly restart this gateway.'
        if id=='dmr' and ready:note='BrandMeister static TG subscriptions persist until Unlink. Adding a TG preserves other subscriptions.' if key else 'Public BrandMeister link status available. Add an API key in Administration for TG controls.'
        if id in ('ysf','dmr2ysf') and ready:
            try:
                native_settings(p)
                note='Native gateway link/unlink; no INI changes or service restarts. Boot defaults are managed outside MMOD.'
            except PermissionError:
                note='Native gateway control; the authorized worker verifies local command access. No INI changes or restarts.'
            except (ValueError,OSError):
                link=False
                note='Enable a supported local remote-command interface in the gateway configuration to use controls.'
        elif id != 'dmr':
            link=False
        out.append(dict(id=id,name=name,ready=bool(ready),link=bool(link),note=note,slot=p.get('ysf_slot',2) if id=='dmr2ysf' else None,enable=bool(p.get('bm_net')) if id=='dmr' else False,default=False))
    return out

def validate(job):
    mode=next((m for m in catalog() if m['id']==job.get('mode')),None)
    if not mode or not mode['ready']: raise ValueError('Setup required for this mode')
    action=job.get('operation')
    if action not in {'link','unlink','enable','disable','default','clear_dynamic'}: raise ValueError('Unknown radio operation')
    if action in {'link','unlink','default','clear_dynamic'} and not mode['link']: raise ValueError(mode['note'])
    if job.get('slot') not in (1,2): raise ValueError('Select TS1 or TS2')
    if job['mode']=='dmr2ysf' and job['slot']!=mode['slot']: raise ValueError('Use the configured gateway timeslot')
    if action in ('enable','disable') and not mode['enable']: raise ValueError('Network enable/disable is not configured')
    if action=='default' and not mode['default']: raise ValueError('BrandMeister static links already persist until Unlink')
    if action=='clear_dynamic':
        if job['mode']!='dmr' or job.get('family')!='BrandMeister':raise ValueError('Dynamic groups can only be cleared on BrandMeister')
        return mode
    if job['mode']=='dmr' and action in ('link','unlink','clear_dynamic'):
        if job.get('family')!='BrandMeister':raise ValueError('Only the configured BrandMeister network can be controlled')
        dest=job.get('destination','')
        if not dest.isdigit() or not 0<int(dest)<=16777215:raise ValueError('Enter a valid DMR talkgroup')
        return mode
    if action in {'link','default'}:
        dest=job.get('destination',''); family=job.get('family')
        if family=='FCS':
            if not re.fullmatch(r'FCS[0-9]{5}',dest): raise ValueError('Use an FCS destination such as FCS00334')
        elif family=='YSF':
            if not re.fullmatch(r'[0-9]{5}',dest): raise ValueError('Use a five-digit YSF reflector number')
        else: raise ValueError('Select YSF or FCS')
    return mode

def system(*args):
    r=subprocess.run(['/usr/bin/systemctl',*args],capture_output=True,text=True,timeout=35)
    if r.returncode: raise RuntimeError(r.stderr.strip()[:300] or 'Service operation failed')
    return r.stdout.strip()

def udp(command):
    with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as s:
        s.settimeout(3); s.connect(('127.0.0.1',7643)); s.send(command.encode())
        reply=s.recv(1024).decode()
    if reply=='KO': raise RuntimeError('DMRGateway rejected operation')
    return reply

def prepare_dmr_remote():
    path=Path(profile()['dmr']['ini'])
    text=path.read_text()
    c=configparser.ConfigParser(strict=False); c.read_string(text)
    section=c['Remote Control']
    if section.get('Address')!='127.0.0.1' or section.get('Port')!='7643':
        raise ValueError('DMRGateway local control setup needs review')
    if section.get('Enable')=='1': return
    raise ValueError('DMRGateway remote control is disabled; configure it outside MMOD')


def startup(text,dest):
    # Preserve comments, permissions, and all unrelated radio settings.
    parts=re.split(r'(?m)^(\[[^\n]+\]\s*)$',text)
    for i in range(1,len(parts),2):
        if parts[i].strip()=='[Network]':
            body=parts[i+1]
            if not re.search(r'(?m)^Startup=',body): raise ValueError('YSF startup setting missing')
            parts[i+1]=re.sub(r'(?m)^Startup=.*$',lambda m:'Startup='+dest,body)
            return ''.join(parts)
    raise ValueError('YSF network settings missing')

def atomic(path,text,mode=0o600):
    tmp=path.with_name(path.name+'.mmod-new')
    fd=os.open(tmp,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,mode)
    try:
        with os.fdopen(fd,'w') as f: f.write(text); f.flush(); os.fsync(f.fileno())
        tmp.replace(path)
    finally: tmp.unlink(missing_ok=True)

def execute(job):
    validate(job)
    # Refuse changing radio routing during traffic or while monitoring is stale.
    radio=json.loads(Path('/run/mmod/radio.json').read_text())
    if time.time()-radio.get('updated',0)>10: raise ValueError('Live monitor is stale; try again when it reconnects')
    bm_subscription=job['mode']=='dmr' and job['operation'] in ('link','unlink','clear_dynamic')
    busy=[s for s in radio.get('slots',[]) if s.get('transmission') and s['transmission'].get('active') and (not bm_subscription or s.get('slot')==job['slot'])]
    if busy: raise ValueError('Selected timeslot is keyed; wait until idle and try again' if bm_subscription else 'Radio is keyed; wait until idle and try again')
    op=job['operation']; mode=job['mode']
    p=profile()
    if mode=='dmr' and op in ('link','unlink','clear_dynamic'):
        from brandmeister import operate
        return operate(job)
    if op in {'enable','disable'}:
        if mode in {'dmr','dmr2ysf'}:
            prepare_dmr_remote()
            reply=udp(op+' '+(p['bm_net'] if mode=='dmr' else p['ysf_net']))
            return op+' accepted by DMRGateway. '+reply+' (runtime only)'
        system('start' if op=='enable' else 'stop','ysfgateway.service')
        return 'YSFGateway '+('started' if op=='enable' else 'stopped')+'; shared DMR2YSF path affected.'
    return native_operate(p,job)


def native_settings(p):
    c=configparser.ConfigParser(interpolation=None,strict=False)
    if not p.get('ysf'):raise ValueError('Gateway configuration unavailable')
    c.read_string(Path(p['ysf']['ini']).read_text())
    if c.get('Remote Commands','Enable',fallback='0')!='1':raise ValueError('Gateway remote commands disabled')
    if c.has_section('MQTT'):
        if c.get('MQTT','Address',fallback='127.0.0.1') not in ('127.0.0.1','localhost','::1'):raise ValueError('Only local gateway control is supported')
        return c,'mqtt',c.getint('MQTT','Port',fallback=1883)
    port=c.getint('Remote Commands','Port',fallback=6073)
    if not 1<=port<=65535:raise ValueError('Invalid remote command port')
    return c,'udp',port


def mqtt_exchange(c,port,command):
    # One isolated MQTT 3.1.1 client; no retained commands and no monitoring dependency.
    def field(s):
        b=s.encode();return len(b).to_bytes(2,'big')+b
    def packet(kind,b):
        n=len(b);h=bytearray([kind])
        while True:
            v=n%128;n//=128;h.append(v|(128 if n else 0))
            if not n:break
        return bytes(h)+b
    with socket.create_connection(('127.0.0.1',port),timeout=3) as sock:
        sock.settimeout(3)
        def exact(n):
            b=b''
            while len(b)<n:
                v=sock.recv(n-len(b))
                if not v:raise ValueError('MQTT connection closed')
                b+=v
            return b
        def receive():
            kind=exact(1)[0];length=0;mul=1
            for _ in range(4):
                v=exact(1)[0];length+=(v&127)*mul
                if not v&128:break
                mul*=128
            else:raise ValueError('Invalid MQTT packet')
            if length>65536:raise ValueError('MQTT packet too large')
            return kind,exact(length)
        flags=2;payload=field('mmod-'+os.urandom(6).hex())
        if c.get('MQTT','Auth',fallback='0')=='1':
            flags|=192;payload+=field(c.get('MQTT','Username'))+field(c.get('MQTT','Password'))
        sock.sendall(packet(16,field('MQTT')+bytes([4,flags,0,15])+payload))
        kind,b=receive()
        if kind!=32 or len(b)!=2 or b[1]!=0:raise ValueError('Local MQTT authentication failed')
        name=c.get('MQTT','Name',fallback='ysf-gateway').strip('/')
        topic=lambda suffix:(name+'/' if name else '')+suffix
        sock.sendall(packet(130,b'\x00\x01'+field(topic('response'))+b'\x00'))
        kind,b=receive()
        if kind!=144 or b[:2]!=b'\x00\x01' or len(b)<3 or b[2]==128:raise ValueError('MQTT response subscription rejected')
        def publish(text):sock.sendall(packet(48,field(topic('command'))+text.encode()))
        publish(command)
        if command!='host':time.sleep(0.25);publish('host')
        deadline=time.monotonic()+3
        while time.monotonic()<deadline:
            kind,b=receive()
            if kind>>4==3:
                n=int.from_bytes(b[:2],'big');msg=b[2+n:].decode(errors='replace')
                if msg.startswith('ysf:"'):return msg[5:].rstrip('"')
        raise ValueError('Gateway did not confirm its current link')


def native_host(c,kind,port,command='host'):
    if kind=='mqtt':return mqtt_exchange(c,port,command)
    with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as sock:
        sock.settimeout(3);sock.connect(('127.0.0.1',port));sock.send(command.encode())
        if command!='host':time.sleep(0.25);sock.send(b'host')
        for _ in range(4):
            msg=sock.recv(2048).decode(errors='replace')
            if msg.startswith('ysf:"'):return msg[5:].rstrip('"')
        raise ValueError('Gateway did not confirm its current link')


def native_operate(p,job):
    c,kind,port=native_settings(p)
    current=native_host(c,kind,port)
    dest=job.get('destination','')
    if job['operation']=='unlink':command='UnLink';expected='NONE'
    elif job['operation']=='link':
        if current not in ('NONE','',dest) and not job.get('auto_disconnect',True):raise ValueError('Unlink first or enable auto-disconnect')
        command=('LinkFCS '+dest[3:]) if job['family']=='FCS' else ('LinkYSF '+dest)
        expected=dest
    else:raise ValueError('Only native link/unlink is supported')
    actual=native_host(c,kind,port,command)
    if actual!=expected:raise ValueError('Gateway has not confirmed the requested destination; refresh link status')
    return 'Gateway confirmed '+('unlink' if expected=='NONE' else 'link to '+actual)+' using local '+kind.upper()+'. Radio configuration unchanged.'
