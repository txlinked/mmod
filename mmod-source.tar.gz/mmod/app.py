import hashlib
import hmac
import json
import os
from pathlib import Path
import secrets
import sqlite3
import time
from urllib.parse import urlsplit

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

ROOT = Path(os.environ.get('MMOD_ROOT', '/var/lib/mmod'))
LIVE = Path(os.environ.get('MMOD_LIVE', '/run/mmod'))
STATE = ROOT / 'state'
app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)

def db():
    connection = sqlite3.connect(STATE / 'auth.sqlite', timeout=5)
    connection.execute('CREATE TABLE IF NOT EXISTS sessions (id TEXT PRIMARY KEY, csrf TEXT, expires REAL)')
    connection.execute('CREATE TABLE IF NOT EXISTS attempts (ip TEXT, stamp REAL)')
    return connection

def session(request):
    token = request.cookies.get('mmod_session', '')
    if not token:
        raise HTTPException(401, 'Sign in to access administration')
    with db() as con:
        row = con.execute('SELECT csrf,expires FROM sessions WHERE id=?', (hashlib.sha256(token.encode()).hexdigest(),)).fetchone()
    if not row or row[1] < time.time():
        raise HTTPException(401, 'Session expired; sign in again')
    return row[0]

def mutation(request):
    csrf = session(request)
    if not hmac.compare_digest(request.headers.get('x-csrf-token', ''), csrf):
        raise HTTPException(403, 'Invalid request token')

@app.middleware('http')
async def security(request, call_next):
    if request.method == 'POST':
        origin = request.headers.get('origin')
        if origin and urlsplit(origin).netloc != request.headers.get('host'):
            return JSONResponse({'detail': 'Origin rejected'}, status_code=403)
        if int(request.headers.get('content-length', '0') or 0) > 8192:
            return JSONResponse({'detail': 'Request too large'}, status_code=413)
    response = await call_next(request)
    response.headers['Cache-Control'] = 'no-store'
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['Referrer-Policy'] = 'same-origin'
    response.headers['Content-Security-Policy'] = "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"
    return response

@app.get('/')
def index():
    return FileResponse(Path(__file__).parent / 'static/index.html')

@app.get('/api/status')
def status():
    try:
        data = json.loads((LIVE / 'snapshot.json').read_text())
    except (OSError, ValueError):
        raise HTTPException(503, 'Waiting for the system collector')
    data.pop('_ticks', None); data.pop('_idle', None)
    data['stale'] = time.time() - data['updated'] > 30
    return data

@app.get('/api/radio')
def radio_status():
    try:
        data=json.loads((LIVE / 'radio.json').read_text())
    except (OSError,ValueError):
        raise HTTPException(503, 'Waiting for live radio monitor')
    data['stale']=time.time()-data['updated']>5
    return data

@app.get('/api/health')
def health():
    data = status()
    return JSONResponse({'ok': not data['stale'], 'version': '0.1.0'}, status_code=503 if data['stale'] else 200)

@app.get('/api/directories')
def directory_status():
    from directories import load
    return load()

class Login(BaseModel):
    username: str = Field(max_length=100)
    password: str = Field(max_length=256)

@app.post('/api/login')
def login(body: Login, request: Request):
    ip = request.client.host
    now = time.time()
    with db() as con:
        con.execute('DELETE FROM attempts WHERE stamp<?', (now - 900,))
        con.execute('DELETE FROM sessions WHERE expires<?', (now,))
        if con.execute('SELECT COUNT(*) FROM attempts WHERE ip=?', (ip,)).fetchone()[0] >= 10:
            raise HTTPException(429, 'Too many attempts; try again in 15 minutes')
        con.execute('INSERT INTO attempts VALUES (?,?)', (ip, now))
    auth = json.loads((STATE / 'credentials.json').read_text())
    digest = hashlib.pbkdf2_hmac('sha256', body.password.encode(), bytes.fromhex(auth['salt']), 600000).hex()
    if not hmac.compare_digest(digest, auth['hash']) or body.username != auth['username']:
        raise HTTPException(401, 'Incorrect username or password')
    token, csrf = secrets.token_urlsafe(32), secrets.token_urlsafe(32)
    with db() as con:
        con.execute('DELETE FROM attempts WHERE ip=?', (ip,))
        con.execute('INSERT INTO sessions VALUES (?,?,?)', (hashlib.sha256(token.encode()).hexdigest(), csrf, now + 28800))
    response = JSONResponse({'csrf': csrf})
    response.set_cookie('mmod_session', token, max_age=28800, httponly=True, samesite='strict', secure=request.url.scheme == 'https')
    return response

@app.get('/api/session')
def current_session(request: Request):
    return {'csrf': session(request)}

@app.post('/api/logout')
def logout(request: Request):
    mutation(request)
    with db() as con:
        con.execute('DELETE FROM sessions WHERE id=?', (hashlib.sha256(request.cookies['mmod_session'].encode()).hexdigest(),))
    response = JSONResponse({'ok': True}); response.delete_cookie('mmod_session')
    return response

class PasswordChange(BaseModel):
    current_password: str = Field(max_length=256)
    new_password: str = Field(min_length=6, max_length=256)
    confirm_password: str = Field(max_length=256)

@app.post('/api/password')
def change_password(body: PasswordChange, request: Request):
    mutation(request)
    if body.new_password != body.confirm_password:
        raise HTTPException(400, 'New passwords do not match')
    auth = json.loads((STATE / 'credentials.json').read_text())
    digest = hashlib.pbkdf2_hmac('sha256', body.current_password.encode(), bytes.fromhex(auth['salt']), 600000).hex()
    if not hmac.compare_digest(digest, auth['hash']):
        raise HTTPException(400, 'Current password is incorrect')
    # The web process owns its credential directory; no elevated permission needed.
    salt = secrets.token_bytes(32)
    auth.update(salt=salt.hex(), hash=hashlib.pbkdf2_hmac('sha256', body.new_password.encode(), salt, 600000).hex())
    temp = STATE / ('credentials-' + secrets.token_hex(12))
    fd = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'w') as stream:
        json.dump(auth, stream)
    temp.replace(STATE / 'credentials.json')
    with db() as con:
        con.execute('DELETE FROM sessions')
    response = JSONResponse({'message': 'Password changed. Sign in with your new password.'})
    response.delete_cookie('mmod_session')
    return response

class ControlRequest(BaseModel):
    action: str
    confirmation: str

@app.get('/api/control')
def control_status(request: Request):
    session(request)
    try:
        result = json.loads((LIVE / 'control-result.json').read_text())
    except (OSError, ValueError):
        result = {}
    result['pending'] = (STATE / 'control-request.json').exists()
    return result

@app.post('/api/control')
def queue_control(body: ControlRequest, request: Request):
    mutation(request)
    from control import ACTIONS
    if body.action not in ACTIONS or body.confirmation != ('REBOOT' if body.action == 'reboot' else 'CONFIRM'):
        raise HTTPException(400, 'Invalid action or confirmation')
    temp = STATE / ('control-' + secrets.token_hex(12))
    try:
        with temp.open('x') as stream:
            json.dump(dict(action=body.action, confirmation=body.confirmation, created=time.time()), stream)
        os.link(temp, STATE / 'control-request.json')
    except FileExistsError:
        raise HTTPException(409, 'A maintenance operation is already pending')
    finally:
        temp.unlink(missing_ok=True)
    return {'message': 'Operation queued. Status will update shortly.'}

@app.get('/api/logs')
def logs(request: Request):
    session(request)
    return json.loads((LIVE / 'logs.json').read_text())

@app.get('/api/backups')
def backups(request: Request):
    session(request)
    return {'pending': (STATE / 'backup-request').exists(), 'items': [dict(name=p.name, size=p.stat().st_size, created=p.stat().st_mtime,
            sha256=json.loads(p.with_name(p.name + '.json').read_text())['sha256'])
            for p in sorted((ROOT / 'backups').glob('config-*.tar.gz'), reverse=True)]}

@app.post('/api/backups')
def new_backup(request: Request):
    mutation(request)
    (STATE / 'backup-request').touch(exist_ok=True)
    return {'message': 'Backup queued. It will appear within one minute.'}

@app.get('/api/backups/{name}')
def download(name: str, request: Request):
    session(request)
    if name not in [p.name for p in (ROOT / 'backups').glob('config-*.tar.gz')]:
        raise HTTPException(404)
    return FileResponse(ROOT / 'backups' / name, filename=name, media_type='application/gzip')

app.mount('/static', StaticFiles(directory=Path(__file__).parent / 'static'), name='static')
