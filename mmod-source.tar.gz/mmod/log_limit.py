"""Keep configured radio/MMOD text logs bounded without restarting writers."""
import configparser
import json
import os
from pathlib import Path
import stat
from collector import CONFIG, ROOT

LIMIT=10*1024*1024

def trim(path):
    if path.is_symlink() or not path.is_file() or path.stat().st_size<=LIMIT:return False
    # Keep the inode/open append descriptor, like logrotate copytruncate.
    # Retain a bounded tail rather than copying an arbitrarily large archive.
    fd=os.open(path,os.O_RDWR|getattr(os,'O_NOFOLLOW',0))
    with os.fdopen(fd,'r+b') as f:
        info=os.fstat(f.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_size<=LIMIT:return False
        f.seek(-LIMIT//2,os.SEEK_END);data=f.read(LIMIT//2)
        data=data.partition(b'\n')[2]
        f.seek(0);f.write(data);f.truncate();f.flush()
        os.utime(f.fileno(),ns=(info.st_atime_ns,info.st_mtime_ns))
    return True

def paths(config):
    ini_path=Path(config['mmdvm_ini'])
    ini=configparser.ConfigParser(interpolation=None,strict=False,inline_comment_prefixes=('#',';'))
    ini.read(ini_path)
    folder=Path(ini.get('Log','FilePath',fallback=str(ini_path.parent)))
    if not folder.is_absolute():folder=ini_path.parent/folder
    found=set(folder.glob(ini.get('Log','FileRoot',fallback='MMDVM')+'*.log'))
    if config.get('radio_log_file'):found.add(Path(config['radio_log_file']))
    for source in config.get('crossmode_sources',[]):found.update(Path(source['log_directory']).glob('*.log'))
    for name in ['DMRGateway','DMR2YSF','YSFGateway','P25Gateway','NXDNGateway']:
        found.update((ini_path.parent.parent/name).glob('*.log'))
    found.update((ROOT/'console').glob('*.log'))
    found.update(Path('/var/log').glob('mmod-*.log'))
    return found

def main():
    config=json.loads(CONFIG.read_text())
    for path in paths(config):
        try:
            if trim(path):print('Trimmed oversized log:',path,flush=True)
        except OSError as error:print('Could not trim log:',path,type(error).__name__,flush=True)

if __name__=='__main__':main()
