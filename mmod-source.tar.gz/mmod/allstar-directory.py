import os,urllib.request
from pathlib import Path
p=Path('/var/lib/mmod/state/allstar-directory.txt')
req=urllib.request.Request('https://allmondb.allstarlink.org/',headers={'User-Agent':'MMOD/2.0'})
with urllib.request.urlopen(req,timeout=45) as response:data=response.read(8*1024*1024+1)
if len(data)>8*1024*1024:raise ValueError('Directory too large')
rows=[line for line in data.decode('utf-8',errors='replace').splitlines() if len(line.split('|'))>=4 and line.split('|')[0].isdigit()]
if len(rows)<25:raise ValueError('Invalid directory; retaining previous copy')
p.parent.mkdir(parents=True,exist_ok=True)
t=p.with_suffix('.tmp');t.write_text('\n'.join(rows),encoding='utf-8');os.replace(t,p)
print('Updated',len(rows),'AllStar names')
