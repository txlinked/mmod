#!/bin/bash
# Debian 12/13 x86_64 installer; see INSTALL-DELL-3040.md.
set -euo pipefail
# Prefer Debian Python over legacy /usr/local overrides.
export PATH=/usr/sbin:/usr/bin:/sbin:/bin
cd "$(dirname "$0")"
if [[ "${1:-}" == --help ]]; then
  echo 'Run sudo bash install.sh for guided setup with prompts.'
  echo 'Optional unattended usage: sudo bash install.sh --bind LOCAL_IPV4 --site "Repeater name" [options]'
  echo 'Options: --ini /absolute/MMDVM.ini --network "Club" --description "Text"'
  echo '         --port 8000 --host-service mmdvmhost.service --firewall-interface eno1'
  echo 'Existing settings are preserved unless an option is supplied.'
  exit 0
fi
[[ $(id -u) == 0 ]] || { echo 'Run with sudo.' >&2; exit 1; }
python3 platform_detect.py
platform_kind=$(python3 platform_detect.py --kind)
command -v python3 >/dev/null || { echo 'First install python3 with apt.'; exit 1; }
[[ -d /run/systemd/system ]] || { echo 'Boot Debian with systemd first.'; exit 1; }
interactive=0
if [[ $# == 0 ]]; then
  [[ -t 0 ]] || { echo 'Run in an interactive SSH terminal, or supply installation options.'; exit 1; }
  interactive=1
  wizard_args=$(python3 install_wizard.py)
  mapfile -d '' -t answers < <(printf '%s' "$wizard_args" | python3 -c 'import json,sys;sys.stdout.buffer.write(b"\0".join(x.encode() for x in json.load(sys.stdin))+b"\0")')
  set -- "${answers[@]}"
fi
plan=$(python3 setup_config.py --check "$@")
bind=$(printf '%s' "$plan" | python3 -c 'import json,sys;print(json.load(sys.stdin)["bind"])')
port=$(printf '%s' "$plan" | python3 -c 'import json,sys;print(json.load(sys.stdin)["port"])')
firewall_interface=$(printf '%s' "$plan" | python3 -c 'import json,sys;print(json.load(sys.stdin)["firewall_interface"] or "")')
if ss -ltnH "sport = :$port" | grep -q .; then
  expected=$(systemctl show mmod -p MainPID --value 2>/dev/null || true)
  sockets=$(ss -ltnpH "sport = :$port")
  [[ "$expected" =~ ^[1-9][0-9]*$ ]] && ! printf '%s\n' "$sockets" | grep -v "pid=$expected," | grep -q . || {
    echo "Port $port belongs to another process. Choose a free port."; exit 1;
  }
fi
stamp=$(date -u +%Y%m%dT%H%M%SZ)
umask 077
exec > >(tee -a "/var/log/mmod-install-$stamp.log") 2>&1
backup=/var/backups/mmod-preinstall-$stamp
install -d -m 700 "$backup"
export MMOD_INSTALL_PLAN="$plan" MMOD_INSTALL_BACKUP="$backup"
python3 - <<'PY'
import hashlib,json,os,pathlib,tarfile
p=json.loads(os.environ['MMOD_INSTALL_PLAN']); b=pathlib.Path(os.environ['MMOD_INSTALL_BACKUP']); manifest={}
with tarfile.open(b/'configuration-before.tar.gz','w:gz') as a:
 for name in p['config']['backup_files']:
  f=pathlib.Path(name)
  if f.is_file() and not f.is_symlink():
   a.add(f,arcname=name.lstrip('/'),recursive=False)
   if not name.startswith('/etc/mmod/'):
    manifest[name]=hashlib.sha256(f.read_bytes()).hexdigest()
(b/'radio-checksums.json').write_text(json.dumps(manifest,indent=2))
PY
if test -d /opt/mmod; then
  tar --exclude=venv --exclude=.git --exclude=__pycache__ -czf "$backup/previous-mmod.tar.gz" -C /opt mmod
fi
# Dashboard only: use existing radio software; never install or compile gateways.
if ! python3 -c 'import ensurepip' >/dev/null 2>&1; then
  apt-get update -qq
  DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends python3-venv
fi
id mmod >/dev/null 2>&1 || useradd --system --home /opt/mmod --shell /usr/sbin/nologin mmod
install -d -m 755 /opt/mmod /opt/mmod/static /opt/mmod/systemd /etc/mmod
install -d -m 750 -o root -g mmod /var/lib/mmod /var/lib/mmod/backups
install -d -m 700 -o mmod -g mmod /var/lib/mmod/state
python3 setup_config.py "$@"
for file in platform_detect.py discover_allstar.py idle_links.py app.py allstar.py allstar-directory.py accounts.py v2_api.py v2_radio.py brandmeister.py discover_controls.py link_status.py collector.py radio.py log_capture.py log_limit.py directories.py subscriber-update.py control.py admin.py setup_config.py requirements.txt VERSION README.md LICENSE INSTALL-DELL-3040.md ADVANCED-SETUP.md BUILDLOG.md; do
  install -m 644 "$file" /opt/mmod/
done
install -m 644 static/* /opt/mmod/static/
install -m 644 systemd/* /opt/mmod/systemd/
umask 022
python3 -m venv /opt/mmod/venv
requirements=/opt/mmod/requirements.txt
if test -f requirements.lock; then
  install -m 644 requirements.lock /opt/mmod/requirements.lock
  requirements=/opt/mmod/requirements.lock
fi
/opt/mmod/venv/bin/pip install --disable-pip-version-check --no-cache-dir -r "$requirements"
/opt/mmod/venv/bin/pip freeze > /opt/mmod/requirements.lock
umask 077
export MMOD_INSTALL_URL="http://$bind:$port"
if ! test -f /var/lib/mmod/state/credentials.json; then
  python3 - <<'PY'
import sys,secrets,os
sys.path.insert(0,'/opt/mmod')
from admin import set_password
password=secrets.token_urlsafe(18)
set_password(password)
with open('/etc/mmod/initial-admin.txt','w') as f:
 f.write('MMOD administrator\nURL: '+os.environ['MMOD_INSTALL_URL']+'\nUsername: admin\nPassword: '+password+'\n')
os.chmod('/etc/mmod/initial-admin.txt',0o600)
PY
fi
install -m 644 systemd/* /etc/systemd/system/
python3 -m py_compile /opt/mmod/*.py
systemd-analyze verify /etc/systemd/system/mmod.service /etc/systemd/system/mmod-collector.service /etc/systemd/system/mmod-collector.timer
python3 - <<'COUNTRY'
from pathlib import Path
import urllib.request
p=Path('/etc/mmod/cty.dat')
if not p.exists():
 try:
  with urllib.request.urlopen('https://www.country-files.com/cty/cty.dat',timeout=20) as response:data=response.read(2000000)
  if b'United States:' not in data:raise ValueError('Unrecognized country file')
  p.write_bytes(data);p.chmod(0o644)
 except Exception as error:print('Country lookup unavailable; names and live slots still work:',error)
COUNTRY
if [[ "$platform_kind" == wpsd ]]; then
  touch /etc/mmod/wpsd-monitor-only
  echo 'WPSD: dashboard monitoring only; radio configuration and log management remain with WPSD.'
  printf '{}\n' > /etc/mmod/control-profile.json
else
  python3 /opt/mmod/discover_controls.py
fi
/opt/mmod/venv/bin/python /opt/mmod/discover_allstar.py
systemctl daemon-reload
systemctl enable --now mmod-allstar-directory.timer
systemctl start --no-block mmod-allstar-directory.service
systemctl enable --now mmod-links.timer
systemctl start --no-block mmod-links.service
systemctl enable --now mmod-control.timer
systemctl enable --now mmod-subscribers.timer
systemctl enable --now mmod-directories.timer
systemctl start --no-block mmod-directories.service
systemctl start --no-block mmod-subscribers.service
[[ "$platform_kind" == wpsd ]] || systemctl enable --now mmod-log-capture.service
[[ "$platform_kind" == wpsd ]] || systemctl enable --now mmod-log-limit.timer
systemctl enable mmod-radio.service
systemctl restart mmod-radio.service
systemctl start mmod-collector.service
systemctl enable mmod-collector.timer mmod.service
systemctl restart mmod-collector.timer mmod.service
if [[ -n "$firewall_interface" ]]; then
  if command -v ufw >/dev/null && ufw status | grep -q '^Status: active'; then
    cp -a /etc/ufw/user.rules /etc/ufw/user6.rules "$backup/"
    ufw allow in on "$firewall_interface" to "$bind" port "$port" proto tcp comment 'MMOD dashboard'
  else
    echo 'UFW is not active; no firewall was enabled or changed. Check other firewalls separately.'
  fi
fi
python3 - <<'PY'
import hashlib,json,os,pathlib,time,urllib.request
b=pathlib.Path(os.environ['MMOD_INSTALL_BACKUP'])
for name,digest in json.loads((b/'radio-checksums.json').read_text()).items():
 assert hashlib.sha256(pathlib.Path(name).read_bytes()).hexdigest()==digest, 'Radio file changed: '+name
for attempt in range(15):
 try:
  with urllib.request.urlopen(os.environ['MMOD_INSTALL_URL']+'/api/health',timeout=2) as r:
   assert json.load(r)['ok']
  with urllib.request.urlopen(os.environ['MMOD_INSTALL_URL']+'/api/radio',timeout=2) as r:
   radio=json.load(r)
   assert not radio.get('error') and time.time()-radio['updated']<5
  print('PASS: local HTTP health and unchanged radio-file checksums'); break
 except Exception:
  if attempt==14: raise
  time.sleep(1)
PY
echo "MMOD V$(cat /opt/mmod/VERSION) installed: $MMOD_INSTALL_URL"
echo 'Admin username: admin. Initial password: sudo cat /etc/mmod/initial-admin.txt'
echo 'Change/reset password: sudo python3 /opt/mmod/admin.py'
echo "Preinstall backup: $backup"
echo "Install log: /var/log/mmod-install-$stamp.log"
if [[ "$interactive" == 1 ]]; then
  echo
  echo 'Set your dashboard admin password now (at least 6 characters).'
  echo 'This changes only the MMOD login, not your Linux/SSH password.'
  echo 'New installations generate a unique password saved in /etc/mmod/initial-admin.txt. Existing passwords are preserved.'
  read -r -p 'Choose a different password now? [y/N] ' change_now
  if [[ "$change_now" == y || "$change_now" == Y ]]; then
  until python3 /opt/mmod/admin.py; do
    read -r -p 'Try setting the password again? [Y/n] ' retry
    [[ "$retry" != n && "$retry" != N ]] || break
  done
  fi
  python3 /opt/mmod/brandmeister.py
  echo "Open $MMOD_INSTALL_URL and choose Administration. Username: admin."
fi

echo "Optional BrandMeister API key: Administration > BrandMeister Setup. Existing keys are preserved."

# Remove only legacy MMOD runtime overrides; original radio INIs are untouched.
for unit in ysfgateway mmdvmhost mmdvm-host; do
  override="/run/systemd/system/$unit.service.d/90-mmod.conf"
  if [ -f "$override" ]; then
    mkdir -p /var/backups/mmod-legacy-overrides
    cp -p "$override" "/var/backups/mmod-legacy-overrides/$unit-$(date +%s).conf"
    rm -f "$override"
    echo "Removed legacy MMOD override for $unit. Restart that radio service when idle to use its original configuration."
  fi
done
systemctl daemon-reload
