"""Capture local radio console output without MQTT or radio restarts."""
import configparser
import json
from pathlib import Path
import re
import subprocess
import time
from collector import CONFIG, ROOT, LIVE, atomic

CAPTURE = ROOT / 'console' / 'MMDVM.log'
LIMIT = 5 * 1024 * 1024

def native_log(config, ini):
    explicit = config.get('radio_log_file')
    if explicit:
        return Path(explicit) if Path(explicit).is_file() else None
    path = Path(config['mmdvm_ini'])
    folder = Path(ini.get('Log', 'FilePath', fallback=str(path.parent)))
    if not folder.is_absolute(): folder = path.parent / folder
    candidates = list(folder.glob(ini.get('Log', 'FileRoot', fallback='MMDVM') + '*.log'))
    return max(candidates, key=lambda p: p.stat().st_mtime) if candidates else None

def screen_session(exec_start):
    # Match only screen launches actually used by the configured host service.
    if not re.search(r'(?:^|[ /])screen(?:\s|;)', exec_start): return None
    match = re.search(r'(?:^|\s)-S\s+([A-Za-z0-9_.-]+)(?:\s|$)', exec_start)
    return match[1] if match else None

def run(*args):
    return subprocess.check_output(args, text=True, stderr=subprocess.PIPE, timeout=8)

def rotate(path):
    if path.exists() and path.stat().st_size >= LIMIT:
        path.replace(path.with_suffix('.previous.log'))

def journal_lines(output):
    lines = output.splitlines()
    cursor = next((line[11:] for line in reversed(lines) if line.startswith('-- cursor: ')), '')
    # Keep radio log text only; journal metadata and diagnostics are excluded.
    return [line for line in lines if re.match(r'^[A-Z]: \d{4}-\d\d-\d\d ', line)], cursor

def main():
    CAPTURE.parent.mkdir(parents=True, exist_ok=True)
    LIVE.mkdir(parents=True, exist_ok=True)
    cursor = ''
    previous_service = ''
    while True:
        screen = None
        try:
            config = json.loads(CONFIG.read_text())
            ini = configparser.ConfigParser(interpolation=None, strict=False, inline_comment_prefixes=('#',';'))
            ini.read(config['mmdvm_ini'])
            source = native_log(config, ini)
            if source or config.get('radio_log_file'):
                if not source: raise RuntimeError('Configured radio_log_file does not exist')
                atomic(LIVE/'log-source.json', dict(updated=time.time(), source='file', path=str(source), error=''))
                time.sleep(10)
                continue
            service = config.get('host_service', 'mmdvmhost.service')
            if not re.fullmatch(r'[A-Za-z0-9_.@-]+\.service', service): raise ValueError('Invalid host service')
            if service != previous_service: cursor = ''; previous_service = service
            launch = run('systemctl','show',service,'--property=ExecStart','--value')
            screen = screen_session(launch)
            if screen:
                # screen logs raw output, not the wrapped hardcopy used for diagnostics.
                if CAPTURE.exists() and CAPTURE.stat().st_size >= LIMIT:
                    run('screen','-S',screen,'-X','log','off')
                    rotate(CAPTURE)
                run('screen','-S',screen,'-X','logfile',str(CAPTURE))
                run('screen','-S',screen,'-X','logfile','flush','1')
                run('screen','-S',screen,'-X','log','on')
                source_type = 'screen'
            else:
                args = ['journalctl','-u',service,'--no-pager','-o','cat','--show-cursor','-n','500']
                if cursor: args += ['--after-cursor',cursor]
                output = run(*args)
                lines, new_cursor = journal_lines(output)
                if lines:
                    rotate(CAPTURE)
                    with CAPTURE.open('a') as f: f.write('\n'.join(lines)+'\n')
                if new_cursor: cursor = new_cursor
                source_type = 'journal'
            atomic(LIVE/'log-source.json',dict(updated=time.time(),source=source_type,path=str(CAPTURE),error=''))
        except Exception as error:
            # Avoid logging command output that may contain radio credentials.
            atomic(LIVE/'log-source.json',dict(updated=time.time(),source='unavailable',error='Local radio log capture unavailable; check host service and logging'))
            cursor = ''
        time.sleep(1 if not screen else 10)

if __name__ == '__main__': main()
