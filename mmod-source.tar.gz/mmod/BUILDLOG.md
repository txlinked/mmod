# MMOD release notes

V2.0.0 includes radio monitoring, authenticated administration, AllStar node controls and directory lookups. The AllStar Received column displays time since a locally observed transmission.
