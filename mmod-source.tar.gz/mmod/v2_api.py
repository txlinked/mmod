import json, os, re, secrets, time
from fastapi import HTTPException, Request
from pydantic import BaseModel, Field
import accounts
from v2_radio import catalog, validate

class UserChange(BaseModel):
    username: str = Field(min_length=1,max_length=32)
    password: str = Field(default='',max_length=256)
    role: str = 'operator'
    enabled: bool = True
    create: bool = False

class RadioAction(BaseModel):
    mode: str
    operation: str
    slot: int = 2
    family: str = 'FCS'
    destination: str = Field(default='',max_length=20)
    auto_disconnect: bool = True
    subscription_kind: str = 'static'

class BMSetup(BaseModel):
    key: str = Field(default='',max_length=4096)
    remove: bool = False

def install_routes(app,state,live):
    @app.get('/api/brandmeister')
    def bm_status(request:Request):
        accounts.require(state,request,admin=True)
        import brandmeister as bm
        saved=bm.credentials()
        return {'device':bm.profile().get('bm_id'),'configured':bool(saved.get('key')),'tested':saved.get('tested')}

    @app.post('/api/brandmeister')
    def bm_setup(body:BMSetup,request:Request):
        actor=accounts.require(state,request,write=True,admin=True)
        import brandmeister as bm
        try:
            if body.remove:
                (bm.STATE/'brandmeister.json').unlink(missing_ok=True)
                message='BrandMeister key removed. Public link status stays available.'
            else:message=bm.save_key(body.key.strip())
        except ValueError as e:raise HTTPException(400,str(e))
        with accounts.connect(state) as con:accounts.record(con,actor['username'],'BrandMeister key removed' if body.remove else 'BrandMeister key saved')
        return {'message':message}

    @app.get('/api/links')
    def linked_destinations():
        try:
            data=json.loads((live/'links.json').read_text())
            if time.time()-data['updated']>30:raise ValueError('stale')
            return data
        except (OSError,ValueError,KeyError):
            return {'slots':[{'slot':n,'links':[],'note':'Link status unavailable.'} for n in (1,2)]}

    @app.on_event('startup')
    def migrate_accounts():
        with accounts.connect(state): pass

    @app.get('/api/destinations')
    def destinations(request:Request,network:str='FCS',q:str=''):
        accounts.require(state,request)
        if len(network)>40 or len(q)>100: raise HTTPException(400,'Search is too long')
        from directories import load
        entries=load().get('lists',{}).get(network,{}).get('entries',{})
        matches=[{'id':k,'name':v} for k,v in entries.items() if q.lower() in (k+' '+v).lower()]
        return {'entries':matches[:200],'total':len(matches)}

    @app.get('/api/users')
    def users(request:Request):
        accounts.require(state,request,admin=True)
        with accounts.connect(state) as con:
            return {'users':[dict(zip(['username','role','enabled'],r)) for r in con.execute('SELECT username,role,enabled FROM users ORDER BY username')]}

    @app.post('/api/users')
    def update_user(body:UserChange,request:Request):
        user=accounts.require(state,request,write=True,admin=True)
        if not re.fullmatch(r'[A-Za-z0-9_.-]{1,32}',body.username): raise HTTPException(400,'Use letters, numbers, dots, underscores or hyphens in usernames')
        if body.role not in {'admin','operator'}: raise HTTPException(400,'Invalid role')
        if (body.create or body.password) and len(body.password)<6: raise HTTPException(400,'Password must have at least 6 characters')
        with accounts.connect(state) as con:
            con.execute('BEGIN IMMEDIATE')
            old=con.execute('SELECT role,enabled FROM users WHERE username=?',(body.username,)).fetchone()
            if body.create and old: raise HTTPException(409,'Username already exists')
            if not body.create and not old: raise HTTPException(404,'User not found')
            if body.username==user['username'] and (not body.enabled or body.role!='admin'): raise HTTPException(400,'You cannot disable or demote your own account')
            if old and old[0]=='admin' and old[1] and (not body.enabled or body.role!='admin'):
                if con.execute("SELECT count(*) FROM users WHERE role='admin' AND enabled=1").fetchone()[0]<=1: raise HTTPException(400,'Keep at least one enabled administrator')
            salt=secrets.token_hex(32)
            if body.create:
                con.execute('INSERT INTO users VALUES (?,?,?,?,?)',(body.username,salt,accounts.digest(body.password,salt),body.role,int(body.enabled)))
            else:
                con.execute('UPDATE users SET role=?,enabled=? WHERE username=?',(body.role,int(body.enabled),body.username))
                if body.password: con.execute('UPDATE users SET salt=?,hash=? WHERE username=?',(salt,accounts.digest(body.password,salt),body.username))
                con.execute('DELETE FROM sessions WHERE username=?',(body.username,))
            accounts.record(con,user['username'],'create user' if body.create else 'update user',body.username+' '+body.role)
        return {'message':'User saved.'}

    @app.get('/api/audit')
    def audit(request:Request):
        accounts.require(state,request,admin=True)
        with accounts.connect(state) as con:
            return {'entries':[dict(zip(['time','username','action','detail'],r)) for r in con.execute('SELECT * FROM audit ORDER BY rowid DESC LIMIT 40')]}

    @app.get('/api/radio-control')
    def radio_control(request:Request):
        accounts.require(state,request)
        try: result=json.loads((live/'control-result.json').read_text())
        except (OSError,ValueError): result={}
        return {'modes':catalog(),'result':result,'pending':(state/'control-request.json').exists()}

    @app.post('/api/radio-control')
    def radio_action(body:RadioAction,request:Request):
        user=accounts.require(state,request,write=True,admin=body.operation=='default')
        job=body.model_dump() if hasattr(body,'model_dump') else body.dict()
        try: validate(job)
        except ValueError as e: raise HTTPException(400,str(e))
        job.update(action='radio',confirmation='CONFIRM',created=time.time(),username=user['username'])
        tmp=state/('radio-'+secrets.token_hex(10))
        try:
            with tmp.open('x') as f: json.dump(job,f)
            os.link(tmp,state/'control-request.json')
        except FileExistsError: raise HTTPException(409,'Another operation is pending')
        finally: tmp.unlink(missing_ok=True)
        with accounts.connect(state) as con: accounts.record(con,user['username'],'radio '+body.operation,body.mode+' '+body.destination)
        return {'message':'Request queued. Waiting for the gateway worker.'}
