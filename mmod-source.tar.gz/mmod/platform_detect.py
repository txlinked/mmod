"""Read-only platform detection for dashboard-only installs."""
import json,platform,sys
from pathlib import Path

def detect(root=Path('/'),machine=None):
    values={}
    for line in (root/'etc/os-release').read_text().splitlines():
        if '=' in line:
            k,v=line.split('=',1);values[k]=v.strip('"')
    arch=machine or platform.machine()
    if values.get('ID') not in ('debian','raspbian','ubuntu') and 'debian' not in values.get('ID_LIKE','').split():
        raise ValueError('Requires a Debian-based system; other Linux distributions are not yet supported')
    if arch not in ('x86_64','aarch64','armv7l','armv8l'):raise ValueError('Unsupported processor: '+arch)
    if sys.version_info<(3,10):raise ValueError('Requires Python 3.10 or newer; upgrade the OS separately')
    wpsd=any((root/p).exists() for p in ('etc/wpsd-release','etc/wpsd','usr/local/sbin/wpsd-update'))
    if (root/'etc/pi-star-release').exists():wpsd=True
    return dict(os=values.get('PRETTY_NAME',values.get('ID')),architecture=arch,wpsd=wpsd)
if __name__=='__main__':
    try:
        data=detect();print('wpsd' if '--kind' in sys.argv and data['wpsd'] else 'standard' if '--kind' in sys.argv else json.dumps(data))
    except (OSError,ValueError) as e:raise SystemExit(str(e))
