"""BrandMeister v2 HTTPS integration. Never log or return API keys."""
import json, os, re, secrets, time, urllib.request, urllib.error
from pathlib import Path

STATE=Path(os.environ.get('MMOD_ROOT','/var/lib/mmod'))/'state'
PROFILE=Path(os.environ.get('MMOD_CONTROL_PROFILE','/etc/mmod/control-profile.json'))

def profile():
    try:return json.loads(PROFILE.read_text())
    except (OSError,ValueError):return {}

def credentials():
    try:return json.loads((STATE/'brandmeister.json').read_text())
    except (OSError,ValueError):return {}

def request(device,path='',method='GET',body=None,key=None):
    if not re.fullmatch(r'[0-9]{6,9}',str(device)):raise ValueError('BrandMeister device ID was not detected; check radio setup')
    headers={'Accept':'application/json','User-Agent':'MMOD/2.0.0','Content-Type':'application/json'}
    if key:headers['Authorization']='Bearer '+key
    req=urllib.request.Request('https://api.brandmeister.network/v2/device/'+str(device)+path,
        data=json.dumps(body).encode() if body is not None else None,headers=headers,method=method)
    # Credentials must never follow redirects to another host.
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self,*args,**kwargs):return None
    try:
        with urllib.request.build_opener(NoRedirect).open(req,timeout=10) as r:raw=r.read(1000001)
        if len(raw)>1000000:raise ValueError('BrandMeister response too large')
        data=json.loads(raw) if raw else {}
        if isinstance(data,dict) and (data.get('error') or data.get('success') is False):raise ValueError('BrandMeister rejected the request')
        return data
    except urllib.error.HTTPError as e:
        raise ValueError('BrandMeister denied access; check the API key and device permissions' if e.code in (401,403) else 'BrandMeister request failed (HTTP '+str(e.code)+')') from None
    except (urllib.error.URLError,TimeoutError,UnicodeError,json.JSONDecodeError):raise ValueError('BrandMeister is unavailable; try again later') from None

def subscriptions(data):
    if not isinstance(data,dict) or not any(k in data for k in ('staticSubscriptions','dynamicSubscriptions')):raise ValueError('Unrecognized BrandMeister profile')
    result=[]
    for kind,field in [('static','staticSubscriptions'),('dynamic','dynamicSubscriptions')]:
        rows=data.get(field,[])
        if not isinstance(rows,list):raise ValueError('Unrecognized BrandMeister subscriptions')
        for row in rows:
            if not isinstance(row,dict):continue
            try:slot=int(row['slot']);tg=int(row['talkgroup'])
            except (ValueError,TypeError,KeyError):continue
            if slot in (0,1,2) and 0<tg<=16777215:result.append({'slot':slot,'tg':str(tg),'kind':kind})
    return result

def save_key(key):
    if not re.fullmatch(r'[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+',key) or len(key)>4096:raise ValueError('Enter a BrandMeister v2 API key')
    device=profile().get('bm_id')
    # /profile is public: do not misrepresent success there as credential validation.
    data=request(device,'/profile');subscriptions(data)
    temp=STATE/('bm-'+secrets.token_hex(12))
    fd=os.open(temp,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    try:
        with os.fdopen(fd,'w') as f:json.dump({'key':key,'device':str(device),'tested':time.time()},f)
        temp.replace(STATE/'brandmeister.json')
    finally:temp.unlink(missing_ok=True)
    return 'Key saved. Device profile is reachable. Key authorization is verified by BrandMeister when you make a control request.'

def operate(job):
    c=credentials();device=profile().get('bm_id')
    if not c.get('key') or c.get('device')!=str(device):raise ValueError('Configure BrandMeister in Administration first')
    if not profile().get('duplex'):raise ValueError('Simplex BrandMeister control requires setup; use SelfCare')
    slot=job['slot'];tg=str(job.get('destination',''))
    if job['operation']=='clear_dynamic':
        if slot not in (1,2):raise ValueError('Select TS1 or TS2')
        request(device,'/action/dropDynamicGroups/'+str(slot),key=c['key'])
        Path('/run/mmod/bm-subscriptions.json').unlink(missing_ok=True)
        return 'BrandMeister accepted clearing all dynamic TGs on TS'+str(slot)+'. Static TGs are unchanged.'
    if slot not in (1,2) or not tg.isdigit() or not 0<int(tg)<=16777215:raise ValueError('Select a valid talkgroup and timeslot')
    if job.get('subscription_kind','static')!='static':raise ValueError('Dynamic unlink clears every dynamic TG on that slot; use BrandMeister SelfCare for this operation')
    if job['operation']=='unlink':
        request(device,'/talkgroup/'+str(slot)+'/'+tg,'DELETE',key=c['key'])
        return 'BrandMeister accepted removal of static TG '+tg+' on TS'+str(slot)+'.'
    if job['operation'] not in ('link','default'):raise ValueError('Unsupported BrandMeister action')
    # Preserve other static TGs. A checkbox must not silently delete subscriptions.
    request(device,'/talkgroup','POST',{'slot':slot,'group':int(tg)},c['key'])
    return 'BrandMeister accepted static TG '+tg+' on TS'+str(slot)+'. This persists until Unlink; other TGs are unchanged.'

if __name__=='__main__':
    import getpass,shutil
    print('Optional BrandMeister API key: enables static TG link/unlink. Public link status works without a key.')
    if input('Configure now? [y/N]: ').strip().lower() in ('y','yes'):
        try:
            print(save_key(getpass.getpass('BrandMeister v2 API key (hidden): ')))
            shutil.chown(STATE/'brandmeister.json',user='mmod',group='mmod')
        except ValueError as e:print(str(e)+'. You can finish in Administration.')
