"""Read-only confirmed gateway links; never infer from last-heard traffic."""
import json,re,subprocess,time
from pathlib import Path

def parse(lines):
    result=None
    for line in lines:
        m=re.search(r"Linked to (.+)$",line)
        if m:
            name=m[1].strip()
            f=re.fullmatch(r"FCS(\d{3})-(\d{2})",name)
            result={'family':'FCS' if f else 'YSF','destination':'FCS'+f[1]+f[2] if f else '', 'name':name}
        elif any(x in line for x in ['Link has failed','Disconnect by remote','Disconnecting due','Disconnect has been requested','Disconnect via DTMF','No connection startup','Closing YSF network','Closing FCS network','Connect by remote command','Automatic (re-)connection','(re-)connection to']):
            result=None
    return result

def run(*args):
    return subprocess.check_output(args,text=True,timeout=8).strip()

def main():
    import brandmeister as bm
    p=bm.profile()
    slots=[{'slot':n,'links':[],'note':'No confirmed links.'} for n in (1,2)]
    try:directories=json.loads(Path('/var/lib/mmod/directories.json').read_text()).get('lists',{})
    except (OSError,ValueError):directories={}
    if p.get('bm_id'):
        cache=Path('/run/mmod/bm-subscriptions.json')
        try:data=json.loads(cache.read_text())
        except (OSError,ValueError):data={}
        if data.get('device')!=p['bm_id'] or time.time()-data.get('updated',0)>30:
            try:data={'device':p['bm_id'],'updated':time.time(),'rows':bm.subscriptions(bm.request(p['bm_id'],'/profile'))}
            except ValueError:data={'device':p['bm_id'],'updated':time.time(),'error':True,'rows':[]}
            cache.write_text(json.dumps(data));cache.chmod(0o644)
        key=bm.credentials();can_unlink=bool(key.get('key') and key.get('device')==p['bm_id'] and p.get('duplex'))
        for slot in slots:slot['note']='BrandMeister status unavailable.' if data.get('error') else 'Confirmed BrandMeister subscriptions.'
        for row in data.get('rows',[]):
            # BrandMeister simplex slot 0 is displayed on RF TS2.
            slot=row['slot'] or 2
            name=directories.get('BrandMeister',{}).get('entries',{}).get(row['tg'],'TG '+row['tg'])
            slots[slot-1]['links'].append(dict(mode='dmr',family='BrandMeister',slot=slot,destination=row['tg'],name=name,kind=row['kind'],unlink=can_unlink and row['kind']=='static' and row['slot'] in (1,2)))
    else:slots[0]['note']='BrandMeister device not detected.'
    if p.get('ysf'):
        slot=p.get('ysf_slot',2)
        try:
            invocation=run('systemctl','show','ysfgateway','-p','InvocationID','--value')
            if not re.fullmatch(r'[a-f0-9]{32}',invocation) or run('systemctl','is-active','ysfgateway')!='active':raise ValueError('Gateway unavailable')
            link=parse(run('journalctl','_SYSTEMD_INVOCATION_ID='+invocation,'-n','2000','--no-pager','-o','cat').splitlines())
            if link:
                entries=directories.get(link['family'],{}).get('entries',{})
                if link['destination']:link['name']=entries.get(link['destination'],link['name']).split(' · ')[0]
                else:
                    matches=[k for k,v in entries.items() if link['name'].strip() in [s.strip() for s in v.split(' · ')]]
                    if len(matches)==1:link['destination']=matches[0]
                link.update(mode='dmr2ysf' if p.get('ysf_net') else 'ysf',slot=slot,unlink=True,kind='gateway')
                slots[slot-1]['links'].append(link);slots[slot-1]['note']='Confirmed network links.'
        except Exception:
            if not slots[slot-1]['links']:slots[slot-1]['note']='Gateway link status unavailable.'
    out=Path('/run/mmod/links.json');tmp=out.with_suffix('.new')
    tmp.write_text(json.dumps({'updated':time.time(),'slots':slots}));tmp.chmod(0o644);tmp.replace(out)
if __name__=='__main__':main()
