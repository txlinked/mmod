"""Prepare the configuration worker sandbox from root-owned discovered paths."""
from pathlib import Path
import configuration

def prepare():
    paths=configuration.files()
    dirs=sorted({str(p.parent) for p,_ in paths.values() if p.parent!=Path('/etc/mmod')})
    if any(not __import__('re').fullmatch(r'/[A-Za-z0-9_./-]+',p) for p in dirs): raise ValueError('Unsupported configuration directory')
    Path('/var/backups/mmod-configuration').mkdir(mode=0o700,exist_ok=True)
    drop=Path('/etc/systemd/system/mmod-configuration.service.d/paths.conf');drop.parent.mkdir(parents=True,exist_ok=True)
    drop.write_text('[Service]\n'+('ReadWritePaths='+' '.join(dirs)+'\n' if dirs else ''))
if __name__=='__main__': prepare()
