import configparser
import tempfile
import unittest
from pathlib import Path
from log_capture import native_log, screen_session, journal_lines, rotate
from unittest.mock import patch

class LocalLogTests(unittest.TestCase):
 def test_screen_detection(self):
  self.assertEqual(screen_session('{ path=/usr/bin/screen ; argv[]=/usr/bin/screen -S MMDVM-Host -D -m /home/repeater/MMDVM-Host ; }'),'MMDVM-Host')
  self.assertIsNone(screen_session('/usr/bin/MMDVMHost /etc/MMDVM.ini'))
 def test_journal_cursor_and_radio_only(self):
  line='M: 2026-09-16 10:18:08.611 DMR Slot 2, received network voice header from N3DMC to TG 9'
  self.assertEqual(journal_lines('service started\n'+line+'\n-- cursor: abc123\n'),([line],'abc123'))
 def test_file_selection_and_rotation(self):
  with tempfile.TemporaryDirectory() as folder:
   p=Path(folder);ini=configparser.ConfigParser();ini.read_dict({'Log':{'FilePath':folder,'FileRoot':'MMDVM'}})
   log=p/'MMDVM.log';log.write_text('abc')
   self.assertEqual(native_log({'mmdvm_ini':str(p/'MMDVM.ini')},ini),log)
   with patch('log_capture.LIMIT',2):rotate(log)
   self.assertFalse(log.exists());self.assertEqual(log.with_suffix('.previous.log').read_text(),'abc')
