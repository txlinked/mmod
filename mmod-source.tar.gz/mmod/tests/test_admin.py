import hashlib,json,secrets,tempfile,time,unittest
from pathlib import Path
from unittest.mock import patch
from starlette.requests import Request
from fastapi import HTTPException
import app

class AdminTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
  self.state=patch.object(app,'STATE',self.root);self.state.start()
  salt=secrets.token_bytes(32)
  (self.root/'credentials.json').write_text(json.dumps(dict(username='admin',salt=salt.hex(),hash=hashlib.pbkdf2_hmac('sha256',b'old-password-testing',salt,600000).hex())))
  with app.db() as db:db.execute('INSERT INTO sessions VALUES (?,?,?)',(hashlib.sha256(b'test-token').hexdigest(),'csrf-test',time.time()+600))
 def tearDown(self):self.state.stop();self.temp.cleanup()
 def request(self,csrf=True):return Request({'type':'http','headers':[(b'cookie',b'mmod_session=test-token')]+([(b'x-csrf-token',b'csrf-test')] if csrf else [])})
 def test_password_requires_csrf_and_current_password(self):
  body=app.PasswordChange(current_password='wrong',new_password='new-password-testing',confirm_password='new-password-testing')
  with self.assertRaises(HTTPException):app.change_password(body,self.request(False))
  with self.assertRaises(HTTPException):app.change_password(body,self.request())
 def test_password_replaces_hash_and_invalidates_sessions(self):
  body=app.PasswordChange(current_password='old-password-testing',new_password='new-password-testing',confirm_password='new-password-testing')
  app.change_password(body,self.request())
  auth=json.loads((self.root/'credentials.json').read_text());self.assertEqual(auth['hash'],hashlib.pbkdf2_hmac('sha256',b'new-password-testing',bytes.fromhex(auth['salt']),600000).hex())
  with self.assertRaises(HTTPException):app.session(self.request())
 def test_control_requires_csrf_and_prevents_duplicate(self):
  body=app.ControlRequest(action='restart',confirmation='CONFIRM')
  with self.assertRaises(HTTPException):app.queue_control(body,self.request(False))
  app.queue_control(body,self.request())
  with self.assertRaises(HTTPException):app.queue_control(body,self.request())
  self.assertEqual(json.loads((self.root/'control-request.json').read_text())['action'],'restart')

if __name__=='__main__':unittest.main()
