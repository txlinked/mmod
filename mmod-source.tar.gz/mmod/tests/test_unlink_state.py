"""Regressions for external unlink leaving DMR2YSF's cached TG selected."""
import unittest
from unittest.mock import patch
import v2_radio

class UnlinkState(unittest.TestCase):
    def job(self, mode='dmr2ysf', operation='unlink'):
        return dict(mode=mode, operation=operation, family='FCS', destination='FCS00381', slot=2)

    def run_operation(self, job, replies, restart_error=None):
        with patch.object(v2_radio, 'native_settings', return_value=(None,'mqtt',18884)), patch.object(v2_radio,'native_host',side_effect=replies), patch.object(v2_radio,'system',side_effect=restart_error) as reset:
            result=v2_radio.native_operate({},job)
            return result,reset.call_args_list

    def test_confirmed_unlink_resets_cached_selection(self):
        result,calls=self.run_operation(self.job(),['FCS00381','NONE'])
        self.assertEqual(len(calls),1)
        self.assertEqual(calls[0].args,('try-restart','dmr2ysf.service'))
        self.assertIn('state reset',result)

    def test_native_fusion_does_not_restart_converter(self):
        result,calls=self.run_operation(self.job('ysf'),['FCS00381','NONE'])
        self.assertEqual(calls,[])

    def test_link_does_not_restart_converter(self):
        result,calls=self.run_operation(self.job(operation='link'),['NONE','FCS00381'])
        self.assertEqual(calls,[])

    def test_unconfirmed_unlink_does_not_reset_converter(self):
        with patch.object(v2_radio,'system') as reset:
            with patch.object(v2_radio,'native_settings',return_value=(None,'mqtt',18884)),patch.object(v2_radio,'native_host',side_effect=['FCS00381','FCS00381']):
                with self.assertRaisesRegex(ValueError,'not confirmed'):v2_radio.native_operate({},self.job())
            reset.assert_not_called()

    def test_reset_failure_is_not_reported_as_success(self):
        with self.assertRaisesRegex(RuntimeError,'reset failed'):
            self.run_operation(self.job(),['FCS00381','NONE'],RuntimeError('reset failed'))

if __name__=='__main__':unittest.main()
