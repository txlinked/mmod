import hashlib, http.cookiejar, json, os, socket, subprocess, sys, tempfile, time, unittest, urllib.request, urllib.error
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import v2_radio

PROFILE={'ysf':{'ini':'/test/YSFGateway.ini','binary':'/test/YSFGateway'},'dmr':{'ini':'/test/DMRGateway.ini'},'ysf_net':'net5','ysf_slot':2,'bm_id':'123456','bm_net':'net1','duplex':True}
class RadioValidation(unittest.TestCase):
    def setUp(self):
        p=patch('v2_radio.profile',return_value=PROFILE);p.start();self.addCleanup(p.stop)
        p=patch('v2_radio.credentials',return_value={});p.start();self.addCleanup(p.stop)

    def job(self,**kw): return dict(mode='dmr2ysf',operation='link',slot=2,family='FCS',destination='FCS00334',**kw)
    def test_reject_uninstalled(self):
        j=self.job();j['mode']='p25'
        with self.assertRaises(ValueError):v2_radio.validate(j)
    def test_no_arbitrary_commands(self):
        for dest in ['FCS00334; reboot','../../etc/passwd','FCS00334\n']:
            j=self.job();j['destination']=dest
            with self.assertRaises(ValueError):v2_radio.validate(j)
    def test_preserve_config(self):
        text='[General]\nCallsign=N3DMC\n[Network]\nStartup=FCS00334\nRevert=0\n[Other]\nStartup=keep\n'
        self.assertEqual(v2_radio.startup(text,'12345'),text.replace('Startup=FCS00334','Startup=12345'))
    def test_keyed_rejected(self):
        with patch('pathlib.Path.read_text',return_value=json.dumps({'updated':time.time(),'slots':[{'transmission':{'call':'TEST'}}]})):
            with self.assertRaisesRegex(ValueError,'keyed'):v2_radio.execute(self.job())
    def test_stale_rejected(self):
        with patch('pathlib.Path.read_text',return_value=json.dumps({'updated':0,'slots':[]})):
            with self.assertRaisesRegex(ValueError,'stale'):v2_radio.execute(self.job())

class AccountsAPI(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory();root=Path(cls.tmp.name);(root/'state').mkdir();(root/'backups').mkdir()
        salt='11'*32
        (root/'state/credentials.json').write_text(json.dumps({'username':'admin','salt':salt,'hash':hashlib.pbkdf2_hmac('sha256',b'testadmin',bytes.fromhex(salt),600000).hex()}))
        with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
        cls.base=f'http://127.0.0.1:{port}/api/'
        (root/'profile.json').write_text(json.dumps(PROFILE))
        cls.proc=subprocess.Popen([sys.executable,'-m','uvicorn','app:app','--host','127.0.0.1','--port',str(port),'--no-access-log'],cwd=Path(__file__).resolve().parents[1],env={**os.environ,'MMOD_CONTROL_PROFILE':str(root/'profile.json'),'MMOD_ROOT':str(root),'MMOD_LIVE':str(root)},stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        for _ in range(100):
            try:urllib.request.urlopen(cls.base+'directories',timeout=1);break
            except Exception:time.sleep(.1)
        cls.state=root/'state'
    @classmethod
    def tearDownClass(cls):cls.proc.terminate();cls.proc.wait(timeout=10);cls.tmp.cleanup()
    def client(self):return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
    def req(self,c,path,body=None,csrf=None):
        headers={'Content-Type':'application/json'}
        if csrf:headers['X-CSRF-Token']=csrf
        req=urllib.request.Request(self.base+path,data=json.dumps(body).encode() if body is not None else None,headers=headers)
        try:
            with c.open(req,timeout=10) as r:return r.status,json.load(r)
        except urllib.error.HTTPError as e:return e.code,json.load(e)
    def test_full_account_workflow(self):
        a=self.client();o=self.client()
        self.assertEqual(self.req(a,'radio-control')[0],401)
        status,session=self.req(a,'login',{'username':'admin','password':'testadmin'});self.assertEqual(status,200);csrf=session['csrf']
        self.assertEqual(self.req(a,'users',{'username':'operator','password':'abcdef','create':True},'bad')[0],403)
        self.assertEqual(self.req(a,'users',{'username':'operator','password':'abc','create':True},csrf)[0],400)
        self.assertEqual(self.req(a,'users',{'username':'operator','password':'abcdef','create':True},csrf)[0],200)
        status,operator=self.req(o,'login',{'username':'operator','password':'abcdef'});self.assertEqual(status,200)
        self.assertEqual(self.req(o,'users')[0],403)
        self.assertEqual(self.req(o,'brandmeister')[0],403)
        self.assertEqual(self.req(a,'brandmeister',{'remove':True},'bad')[0],403)
        self.assertEqual(self.req(a,'brandmeister')[1]['configured'],False)
        self.assertEqual(self.req(o,'control',{'action':'reboot','confirmation':'REBOOT'},operator['csrf'])[0],403)
        self.assertEqual(self.req(o,'radio-control',{'mode':'dmr2ysf','operation':'default','destination':'FCS00334'},operator['csrf'])[0],403)
        self.assertEqual(self.req(o,'radio-control',{'mode':'p25','operation':'link','destination':'12345'},operator['csrf'])[0],400)
        self.assertEqual(self.req(o,'radio-control',{'mode':'dmr2ysf','operation':'link','destination':'FCS00334'},operator['csrf'])[0],200)
        job=json.loads((self.state/'control-request.json').read_text());self.assertEqual(job['username'],'operator')
        self.assertEqual(self.req(o,'radio-control',{'mode':'dmr2ysf','operation':'link','destination':'FCS00334'},operator['csrf'])[0],409)
        self.assertEqual(self.req(a,'users',{'username':'admin','role':'operator'},csrf)[0],400)
        self.assertEqual(self.req(a,'users',{'username':'operator','role':'operator','enabled':False},csrf)[0],200)
        self.assertEqual(self.req(o,'session')[0],401)
        self.assertEqual(self.req(a,'password',{'current_password':'testadmin','new_password':'newpass','confirm_password':'newpass'},csrf)[0],200)
        self.assertEqual(self.req(a,'session')[0],401)
        self.assertEqual(self.req(a,'login',{'username':'admin','password':'newpass'})[0],200)

if __name__=='__main__':unittest.main()
