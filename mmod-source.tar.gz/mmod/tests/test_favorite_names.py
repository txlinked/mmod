import tempfile,json,unittest
from pathlib import Path
from unittest.mock import patch
from fastapi import FastAPI,HTTPException
import allstar
class FavoritesTest(unittest.TestCase):
 def test_save_names_preserve_credentials_and_legacy_favorites(self):
  with tempfile.TemporaryDirectory() as folder:
   state=Path(folder);p=state/'allstar-nodes.json';p.write_text(json.dumps({'12345':{'node':'12345','name':'Test','secret':'keep','favorites':['559820']}}))
   app=FastAPI();allstar.install(app,state)
   save=next(r.endpoint for r in app.routes if r.path=='/api/allstar/favorite')
   with patch.object(allstar.accounts,'require',return_value={'username':'test'}) as auth,patch.object(allstar.accounts,'connect'),patch.object(allstar.accounts,'record'):
    save(allstar.Favorite(node='12345',target='559820',name='Racknerd'),object())
    auth.assert_called_once();self.assertTrue(auth.call_args.kwargs['write'])
    save(allstar.Favorite(node='12345',target='559820',name='Hub One'),object())
    result=json.loads(p.read_text())['12345'];self.assertEqual(result['favorites'],['559820']);self.assertEqual(result['favorite_names']['559820'],'Hub One');self.assertEqual(result['secret'],'keep')
    with self.assertRaises(HTTPException):save(allstar.Favorite(node='12345',target='invalid',name='Bad'),object())
   with patch.object(allstar.accounts,'require',side_effect=HTTPException(401)):
    with self.assertRaises(HTTPException):save(allstar.Favorite(node='12345',target='559821',name='Denied'),object())
   self.assertEqual(json.loads(p.read_text())['12345'],result)
 def test_directory_name_fallback_and_custom_override(self):
  with tempfile.TemporaryDirectory() as folder:
   state=Path(folder);p=state/'allstar-nodes.json';p.write_text(json.dumps({'12345':{'node':'12345','secret':'keep','favorites':[]}}))
   (state/'allstar-directory.txt').write_text('503600|N3DMC|Waco TX N3DMC.org|VPS\n',encoding='utf-8')
   app=FastAPI();allstar.install(app,state)
   lookup=next(r.endpoint for r in app.routes if r.path=='/api/allstar/directory/{target}')
   save=next(r.endpoint for r in app.routes if r.path=='/api/allstar/favorite')
   self.assertEqual(lookup('503600')['name'],'N3DMC · Waco TX N3DMC.org · VPS')
   with patch.object(allstar.accounts,'require',return_value={'username':'test'}),patch.object(allstar.accounts,'connect'),patch.object(allstar.accounts,'record'):
    save(allstar.Favorite(node='12345',target='503600'),object())
    self.assertEqual(json.loads(p.read_text())['12345']['favorite_names']['503600'],lookup('503600')['name'])
    save(allstar.Favorite(node='12345',target='503600',name='My hub'),object())
    self.assertEqual(json.loads(p.read_text())['12345']['favorite_names']['503600'],'My hub')
    with self.assertRaises(HTTPException):save(allstar.Favorite(node='12345',target='999999'),object())
   with self.assertRaises(HTTPException):lookup('invalid')
if __name__=='__main__':unittest.main()
