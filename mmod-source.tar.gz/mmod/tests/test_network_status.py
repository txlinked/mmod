import unittest,tempfile,json,time
from pathlib import Path
from link_status import configured_dmr_routes,add_unconfirmed_status
class NetworkStatusTest(unittest.TestCase):
 def test_range_and_unconfirmed_request(self):
  with tempfile.TemporaryDirectory() as folder:
   root=Path(folder);ini=root/'gateway.ini';ini.write_text('[DMR Network 3]\nEnabled=1\nName=TGIF_Network\nAddress=tgif.network\nTGRewrite0=1,6000001,1,1,999999\nTGRewrite1=2,6000001,2,1,999999\n')
   p={'dmr':{'ini':str(ini)},'tgif_id':'123456','tgif_slots':[1,2]}
   routes=configured_dmr_routes(p);self.assertEqual(len(routes),2)
   slots=[{'slot':n,'links':[r for r in routes if r['slot']==n]} for n in [1,2]]
   (root/'tgif-requests.json').write_text(json.dumps({'1':{'device':'123456','talkgroup':'5656'}}))
   (root/'snapshot.json').write_text(json.dumps({'updated':time.time(),'modes':[{'name':'P25','enabled':True},{'name':'DMR','enabled':True},{'name':'NXDN','enabled':False}]}))
   add_unconfirmed_status(slots,p,root)
   self.assertEqual(slots[0]['links'][0]['destination'],'5656');self.assertIn('unverified',slots[0]['links'][0]['kind']);self.assertTrue(slots[0]['links'][0]['unlink'])
   self.assertEqual(slots[2]['label'],'P25');self.assertEqual(len(slots),3)
   (root/'tgif-requests.json').write_text(json.dumps({'1':{'device':'123456','talkgroup':'4000'}}));add_unconfirmed_status(slots[:2],p,root)
   self.assertFalse(slots[0]['links'][0]['unlink'])
if __name__=='__main__':unittest.main()
