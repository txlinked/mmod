import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import setup_config as config

class SetupTests(unittest.TestCase):
    def test_requires_address_and_rejects_wildcard(self):
        with tempfile.TemporaryDirectory() as d:
            for options in [[],['--bind','0.0.0.0'],['--bind','224.0.0.1'],['--bind','1.2.3.4','--port','80']]:
                with self.assertRaises(ValueError): config.make_plan(config.parser().parse_args(options),Path(d))

    def test_fresh_install_and_no_waco_identity(self):
        with tempfile.TemporaryDirectory() as d:
            plan=config.make_plan(config.parser().parse_args(['--bind','192.168.1.50','--site','North Site']),Path(d))
            self.assertEqual(plan['port'],8000)
            self.assertEqual(plan['config']['site'],'North Site')
            self.assertNotIn('OldSite',json.dumps(plan))
            self.assertNotIn('192.0.2.8',json.dumps(plan))

    def test_existing_settings_preserved_and_service_updated(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            base=config.make_plan(config.parser().parse_args(['--bind','192.168.1.50']),root)['config']
            base['backup_files'].append('/my/gateway.ini')
            (root/'config.json').write_text(json.dumps(base))
            (root/'listen.env').write_text('MMOD_BIND=192.168.1.50\nMMOD_PORT=8090\n')
            plan=config.make_plan(config.parser().parse_args(['--site','Hilltop','--host-service','custom.service']),root)
            self.assertEqual(plan['port'],8090)
            self.assertEqual(plan['config']['services'][0],'custom.service')
            self.assertIn('/my/gateway.ini',plan['config']['backup_files'])

    def test_interface_must_own_address(self):
        plan={'bind':'192.168.1.50','firewall_interface':'eno1'}
        listing=[{'ifname':'eno1','addr_info':[{'local':'192.168.1.50'}]}]
        with patch('subprocess.check_output',return_value=json.dumps(listing)):
            config.check_interface(plan)
            plan['firewall_interface']='eno2'
            with self.assertRaises(ValueError): config.check_interface(plan)

if __name__=='__main__': unittest.main()
