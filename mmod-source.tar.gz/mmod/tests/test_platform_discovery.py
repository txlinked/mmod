import unittest,tempfile,sys
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import platform_detect,discover_allstar
class DiscoveryTests(unittest.TestCase):
 def test_platforms_and_wpsd(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d);(p/'etc').mkdir();(p/'etc/os-release').write_text('ID=debian\n')
   for arch in ('x86_64','aarch64','armv7l'):
    self.assertEqual(platform_detect.detect(p,arch)['architecture'],arch)
   (p/'etc/wpsd-release').touch();self.assertTrue(platform_detect.detect(p,'aarch64')['wpsd'])
   with self.assertRaises(ValueError):platform_detect.detect(p,'mips')
 def test_include_and_loop(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d);(p/'manager.conf').write_text('[general]\n#include "user.conf"\n');(p/'user.conf').write_text('[user]\nwrite=command\n')
   self.assertIn('write=command',discover_allstar.config(p/'manager.conf'))
   (p/'user.conf').write_text('#include "manager.conf"\n')
   with self.assertRaises(ValueError):discover_allstar.config(p/'manager.conf')
 def test_no_radio_installs(self):
  root=Path(__file__).resolve().parents[1]
  for name in ('install.sh','mmodupdate.sh'):
   text=(root/name).read_text()
   self.assertNotIn('modules.py --install',text)
   self.assertIn('discover_allstar.py',text)
   self.assertIn('idle_links.py',text)
if __name__=='__main__':unittest.main()
