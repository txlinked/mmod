import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import radio

class BridgeDuplicates(unittest.TestCase):
 def sample(self):
  lines=['M: 2026-09-18 10:17:15.217 DMR Slot 2, received network voice header from 314583 to TG 7100334',
         'M: 2026-09-18 10:17:16.728 DMR Slot 2, received network end of voice transmission from 314583 to TG 7100334, 1.6 seconds, 0% packet loss',
         'M: 2026-09-18 10:17:16.775 DMR Slot 2, received network late entry from 314583 to TG 7100334',
         'M: 2026-09-18 10:17:18.278 DMR Slot 2, network watchdog has expired, 1.2 seconds, 90% packet loss']
  snapshot=radio.events(lines)
  for r in snapshot['activity']:r['mode']='DMR2YSF';r['caller']='KJ5GLE'
  return snapshot
 def test_bridge_fragment_removed_from_saved_history_and_last_caller(self):
  with tempfile.TemporaryDirectory() as folder,patch.object(radio,'ROOT',Path(folder)):
   snap=self.sample();radio.preserve_history(snap);radio.retain_callers(snap)
   radio.suppress_bridge_tails(snap);radio.retain_callers(snap);radio.preserve_history(snap)
   self.assertEqual(len(snap['activity']),1)
   self.assertEqual(snap['last_calls'][0]['seconds'],1.6)
   self.assertEqual(snap['activity'][0]['loss'],0)
 def test_real_rekeys_and_unproven_fragments_preserved(self):
  for field,value in [('start_kind','header'),('mode','DMR'),('loss',0),('end_reason','end'),('seconds',4)]:
   snap=self.sample();snap['activity'][0][field]=value
   radio.suppress_bridge_tails(snap);self.assertEqual(len(snap['activity']),2,(field,value))
  snap=self.sample();snap['activity'][0]['started']+=2
  radio.suppress_bridge_tails(snap);self.assertEqual(len(snap['activity']),2)
