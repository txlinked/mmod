import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import directories as d

class DirectoryTests(unittest.TestCase):
    def test_network_offsets_are_not_global(self):
        self.assertEqual(d.parse_text(b'5001001;Central Texas\n1117309;Other', 'pair', 5000000), {'1001': 'Central Texas', '1117309': 'Other'})
        self.assertEqual(d.parse_text(b'5001001;Different', 'pair'), {'5001001': 'Different'})

    def test_formats(self):
        self.assertEqual(d.parse_text(b'00006;GR-HELLAS;Zone A;1.2.3.4;42000', 'ysf')['00006'], 'GR-HELLAS · Zone A')
        self.assertEqual(d.parse_text(b'FCS00334;Texas;FCS003 - Texas;;;', 'fcs')['FCS00334'], 'Texas · FCS003 - Texas')
        self.assertIn('REF001', d.parse_text(b'REF001\t1.2.3.4', 'host'))
        self.assertEqual(d.parse_bm(b'{"91":"Worldwide"}'), {'91':'Worldwide'})
        self.assertEqual(d.parse_rubrics(b'[{"number":42,"label":"Weather"}]'), {'42':'Weather'})

    def test_reject_html(self):
        with self.assertRaises(ValueError): d.parse_text(b'<html>Error;bad</html>', 'pair')

    def test_outage_keeps_last_success_and_reports_failure(self):
        with tempfile.TemporaryDirectory() as folder, patch.object(d, 'ROOT', Path(folder)), patch.object(d, 'fetch', side_effect=OSError('offline')):
            d.atomic(d.ROOT/'directories.json', {'lists': {'YSF': {'entries': {'123':'Test'}, 'updated':1}}})
            d.update()
            item = d.load()['lists']['YSF']
            self.assertEqual(item['entries'], {'123':'Test'})
            self.assertEqual(item['updated'], 1)
            self.assertTrue(item['error'])
