import contextlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import install_wizard

class WizardTests(unittest.TestCase):
    def command(self,args,**kwargs):
        if args[0]=='ufw': return 'Status: inactive'
        return json.dumps([{'ifname':'eno1','addr_info':[{'scope':'global','local':'192.168.1.50'}]}])

    def test_enter_accepts_defaults(self):
        with tempfile.TemporaryDirectory() as d, patch('subprocess.check_output',side_effect=self.command), patch('builtins.input',side_effect=['']*6), contextlib.redirect_stderr(io.StringIO()):
            args=install_wizard.wizard(Path(d))
            self.assertEqual(args[args.index('--bind')+1],'192.168.1.50')
            self.assertEqual(args[args.index('--port')+1],'8000')
            self.assertNotIn('--firewall-interface',args)
            self.assertFalse((Path(d)/'config.json').exists())

    def test_selects_detected_dell_address(self):
        interfaces=[{'ifname':'lo','addr_info':[{'scope':'host','local':'127.0.0.1'}]},
                    {'ifname':'eno1','addr_info':[{'scope':'global','local':'192.168.1.50'}]},
                    {'ifname':'zt123','addr_info':[{'scope':'global','local':'192.0.2.9'}]}]
        def command(args,**kwargs):
            return 'Status: inactive' if args[0]=='ufw' else json.dumps(interfaces)
        output=io.StringIO()
        with tempfile.TemporaryDirectory() as d, patch('subprocess.check_output',side_effect=command), patch('builtins.input',side_effect=['','','2','','','']), contextlib.redirect_stderr(output):
            args=install_wizard.wizard(Path(d))
        self.assertEqual(args[args.index('--bind')+1],'192.168.1.50')
        self.assertIn('192.168.1.50 (eno1)',output.getvalue())
        self.assertIn('192.0.2.9 (zt123)',output.getvalue())
        self.assertNotIn('127.0.0.1',output.getvalue())

    def test_cancel_does_not_write(self):
        with tempfile.TemporaryDirectory() as d, patch('subprocess.check_output',side_effect=self.command), patch('builtins.input',side_effect=['','','','','','n']), contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaisesRegex(ValueError,'cancelled'): install_wizard.wizard(Path(d))
            self.assertFalse((Path(d)/'config.json').exists())

    def test_invalid_choice_reprompts_and_name_is_data(self):
        with tempfile.TemporaryDirectory() as d, patch('subprocess.check_output',side_effect=self.command), patch('builtins.input',side_effect=['Club $(example)','', '99','1','','','']), contextlib.redirect_stderr(io.StringIO()):
            args=install_wizard.wizard(Path(d))
            self.assertEqual(args[1],'Club $(example)')

if __name__=='__main__': unittest.main()
