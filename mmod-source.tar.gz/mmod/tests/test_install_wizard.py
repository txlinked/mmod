import contextlib,io,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import install_wizard
class WizardTests(unittest.TestCase):
 def test_defaults_all_interfaces(self):
  with tempfile.TemporaryDirectory() as d,patch('builtins.input',side_effect=['']*5),contextlib.redirect_stderr(io.StringIO()):
   args=install_wizard.wizard(Path(d));self.assertEqual(args[args.index('--bind')+1],'0.0.0.0');self.assertEqual(args[args.index('--port')+1],'8000')
 def test_cancel_no_write(self):
  with tempfile.TemporaryDirectory() as d,patch('builtins.input',side_effect=['','','','','n']),contextlib.redirect_stderr(io.StringIO()):
   with self.assertRaisesRegex(ValueError,'cancelled'):install_wizard.wizard(Path(d))
   self.assertFalse((Path(d)/'listen.env').exists())
