import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from link_status import parse
class Links(unittest.TestCase):
 def test_confirmed_fcs(self):self.assertEqual(parse(['Linked to FCS003-34'])['destination'],'FCS00334')
 def test_traffic_is_not_link(self):self.assertIsNone(parse(['DMR Slot 1, received network voice header from TEST to TG 3100']))
 def test_fail_and_switch_clear(self):
  for line in ['Link has failed, polls lost','Disconnect by remote command','Connect by remote command to FCS00100','Closing YSF network connection']:
   self.assertIsNone(parse(['Linked to FCS003-34',line]))
 def test_latest_confirmed(self):self.assertEqual(parse(['Linked to FCS003-34','Connect by remote command to FCS00100','Linked to FCS001-00'])['destination'],'FCS00100')
