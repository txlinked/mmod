import unittest
import tempfile
from pathlib import Path
from unittest.mock import patch
import radio

class HistoryTests(unittest.TestCase):
 def test_preserve_identity_and_restart(self):
  with tempfile.TemporaryDirectory() as folder, patch.object(radio,'ROOT',Path(folder)):
   row=dict(slot=2,started=100,target='7',ended=102,active=False,caller='N5NZZ',name='Test',location='Texas')
   radio.preserve_history(dict(updated=103,activity=[row]))
   blank=dict(row,name='',location='')
   snap=dict(updated=104,activity=[blank]);radio.preserve_history(snap)
   self.assertEqual(snap['activity'][0]['name'],'Test')
   snap=dict(updated=105,activity=[]);radio.preserve_history(snap)
   self.assertEqual(snap['activity'][0]['location'],'Texas')
   snap=dict(updated=86502,activity=[]);radio.preserve_history(snap)
   self.assertEqual(snap['activity'],[])
 def test_bridge_end_matches_delayed_radio_record(self):
  with tempfile.TemporaryDirectory() as folder:
   Path(folder,'DMR2YSF-test.log').write_text('M: 2026-09-16 05:32:02.983 Received YSF Header: Src: N5NZZ Dst: *****\nM: 2026-09-16 05:32:02.984 DMR ID not found, using default ID: 314583, DstID: TG 100334\nM: 2026-09-16 05:32:07.973 YSF received end of voice transmission, 5.0 seconds\n')
   row=dict(source='network',slot=2,caller='314583',target='7100334',started=1789536728.341)
   radio.crossmode({'activity':[row]}, {'crossmode_sources':[dict(log_directory=folder,slot=2,target_offset=7000000)]})
   self.assertEqual(row['caller'],'N5NZZ')
