import unittest
import tempfile
from pathlib import Path
from unittest.mock import patch
import radio

class HistoryTests(unittest.TestCase):
 def test_preserve_identity_and_restart(self):
  with tempfile.TemporaryDirectory() as folder, patch.object(radio,'ROOT',Path(folder)):
   row=dict(slot=2,started=100,target='7',ended=102,active=False,caller='N5NZZ',name='Test',location='Texas')
   radio.preserve_history(dict(updated=103,activity=[row]))
   blank=dict(row,name='',location='')
   snap=dict(updated=104,activity=[blank]);radio.preserve_history(snap)
   self.assertEqual(snap['activity'][0]['name'],'Test')
   snap=dict(updated=105,activity=[]);radio.preserve_history(snap)
   self.assertEqual(snap['activity'][0]['location'],'Texas')
   snap=dict(updated=86502,activity=[]);radio.preserve_history(snap)
   self.assertEqual(len(snap['activity']),1)
 def test_bridge_end_matches_delayed_radio_record(self):
  with tempfile.TemporaryDirectory() as folder:
   Path(folder,'DMR2YSF-test.log').write_text('M: 2026-09-16 05:32:02.983 Received YSF Header: Src: N5NZZ Dst: *****\nM: 2026-09-16 05:32:02.984 DMR ID not found, using default ID: 314583, DstID: TG 100334\nM: 2026-09-16 05:32:07.973 YSF received end of voice transmission, 5.0 seconds\n')
   row=dict(source='network',slot=2,caller='314583',target='7100334',started=1789536728.341)
   radio.crossmode({'activity':[row]}, {'crossmode_sources':[dict(log_directory=folder,slot=2,target_offset=7000000)]})
   self.assertEqual(row['caller'],'N5NZZ')

 def test_latest_twenty_in_order(self):
  with tempfile.TemporaryDirectory() as folder, patch.object(radio,'ROOT',Path(folder)):
   rows=[dict(slot=1,started=i,target='3100',seconds=1,active=False) for i in range(25)]
   snap=dict(updated=90000,activity=rows);radio.preserve_history(snap)
   self.assertEqual([r['started'] for r in snap['activity']],list(range(24,4,-1)))
   snap=dict(updated=90001,activity=[]);radio.preserve_history(snap)
   self.assertEqual(len(snap['activity']),20)

 def test_service_reply_does_not_replace_person_and_repairs_saved_state(self):
  with tempfile.TemporaryDirectory() as folder, patch.object(radio,'ROOT',Path(folder)):
   import json
   person=dict(slot=2,started=100,target='9990',active=False,source='RF',caller='KJ5RNV',name='Mark',location='Hewitt, Texas, USA')
   reply=dict(slot=2,started=103,target='KJ5RNV',active=False,source='network',caller='9990')
   Path(folder,'last-callers.json').write_text(json.dumps({'2':reply}))
   snap=dict(activity=[reply,person]);radio.retain_callers(snap)
   self.assertEqual(snap['last_calls'],[person])
   self.assertEqual(len(snap['activity']),2)
   snap=dict(activity=[reply]);radio.retain_callers(snap)
   self.assertEqual(snap['last_calls'],[person])
 def test_unresolved_subscriber_is_not_discarded(self):
  with tempfile.TemporaryDirectory() as folder, patch.object(radio,'ROOT',Path(folder)):
   row=dict(slot=1,started=100,target='3100',active=False,source='network',caller='1234567')
   snap=dict(activity=[row]);radio.retain_callers(snap)
   self.assertEqual(snap['last_calls'],[row])
 def test_disconnect_reply_does_not_replace_person(self):
  self.assertTrue(radio.service_reply(dict(source='network',caller='4000')))
  self.assertFalse(radio.service_reply(dict(source='RF',caller='4000')))
