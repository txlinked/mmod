import tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import radio

class RetentionTests(unittest.TestCase):
 def test_busy_slot_does_not_displace_other_slot(self):
  with tempfile.TemporaryDirectory() as folder,patch.object(radio,'ROOT',Path(folder)),patch.object(radio,'atomic',side_effect=lambda p,d:p.write_text(__import__('json').dumps(d))):
   radio.retain_callers({'activity':[{'slot':2,'started':1,'caller':'N5YAI','active':False}]})
   snapshot={'activity':[{'slot':1,'started':n,'caller':'TEST','active':False} for n in range(2,50)]}
   radio.retain_callers(snapshot)
   self.assertEqual(next(r for r in snapshot['last_calls'] if r['slot']==2)['caller'],'N5YAI')
