import unittest
from unittest.mock import patch
import v2_radio
class TimerOptIn(unittest.TestCase):
 def test_missing_or_disabled_policy_cancels_queued_timeout(self):
  for exists,policy in [(False,'{}'),(True,'{}'),(True,'{"enabled":false}')]:
   with self.subTest(exists=exists,policy=policy),patch.object(v2_radio,'validate'),patch('pathlib.Path.exists',return_value=exists),patch('pathlib.Path.read_text',return_value=policy),patch.object(v2_radio,'native_operate') as native:
    result=v2_radio.execute({'username':'auto-timeout','created':0})
    self.assertIn('Timeout cancelled',result)
    native.assert_not_called()
