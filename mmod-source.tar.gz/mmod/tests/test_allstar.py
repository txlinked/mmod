import unittest
from unittest.mock import patch
import allstar

class AllStarTests(unittest.TestCase):
 def test_commands(self):
  for op,n in [('link',3),('monitor',2),('unlink',1)]:self.assertEqual(allstar.command('640770',op,'559822'),f'rpt cmd 640770 ilink {n} 559822')
 def test_reject_injection_and_self(self):
  for target in ['123\r\nAction: Command',';reboot','0','640770']:
   with self.assertRaises(ValueError):allstar.command('640770','link',target)
  with self.assertRaises(ValueError):allstar.command('640770','restart','559822')
 def test_status(self):
  d=allstar.parse_status('System........: ENABLED\nNodes currently connected to us........: 559822 12345\nUptime.......: 01:02:03')
  self.assertEqual(d['connected'],['559822','12345']);self.assertEqual(d['system'],'ENABLED')
  with self.assertRaises(ValueError):allstar.parse_status('No such command')
 def test_ami_protocol(self):
  import io
  class Sock:
   def __init__(self):self.sent=[]
   def __enter__(self):return self
   def __exit__(self,*a):pass
   def settimeout(self,n):pass
   def makefile(self,mode):return io.BytesIO(b'Asterisk Call Manager/5.0\r\nResponse: Success\r\nMessage: Authentication accepted\r\n\r\nResponse: Follows\r\nPrivilege: Command\r\nOutput: Nodes currently connected to us: 12345\r\nOutput: --END COMMAND--\r\n\r\n')
   def sendall(self,b):self.sent.append(b)
  s=Sock()
  with patch('socket.create_connection',return_value=s):
   out=allstar.ami(dict(host='127.0.0.1',port=5038,username='test',secret='test'),'rpt stats 640770')
  self.assertIn('12345',out);self.assertIn(b'Events: off',s.sent[0]);self.assertIn(b'Command: rpt stats',s.sent[1])
