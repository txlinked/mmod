import unittest,threading
from collections import deque
from types import SimpleNamespace
from radio import MQTTLogs,events

class MQTTTests(unittest.TestCase):
 def test_live_messages_feed_both_slots_and_ignore_retained(self):
  reader=MQTTLogs.__new__(MQTTLogs);reader.lines=deque(maxlen=1500);reader.lock=threading.Lock()
  for slot in (1,2):
   payload=f'M: 2026-09-16 01:00:00.000 DMR Slot {slot}, received network voice header from K5GGC to TG 91'.encode()
   reader.on_message(None,None,SimpleNamespace(retain=True,payload=payload))
   self.assertEqual(len(reader.read()),slot-1)
   reader.on_message(None,None,SimpleNamespace(retain=False,payload=payload))
  result=events(reader.read(),1789520401)
  self.assertTrue(all(s['transmission'] for s in result['slots']))
  self.assertEqual(len(result['activity']),2)
 def test_disconnect_clears_connection_state(self):
  reader=MQTTLogs.__new__(MQTTLogs);reader.connected=True
  reader.on_disconnect(None,None,None,None,None)
  self.assertFalse(reader.connected)
