import unittest
from unittest.mock import patch,MagicMock
import tgif,v2_radio
class TGIFTest(unittest.TestCase):
 def test_prefix(self):
  self.assertEqual(tgif.destination('6005656'),5656);self.assertEqual(tgif.destination('6004000'),4000)
  for v in ['0','7000000','bad']:
   with self.assertRaises(ValueError):tgif.destination(v)
 def test_slots_and_confirmation(self):
  profile={'tgif_id':'3202139','tgif_slots':[1,2]}
  for slot in [1,2]:
   for op,tg in [('link',5656),('unlink',4000)]:
    response=MagicMock();response.__enter__.return_value.read.return_value=b'200'
    opener=MagicMock();opener.open.return_value=response
    with patch.object(tgif,'profile',return_value=profile),patch('urllib.request.build_opener',return_value=opener):
     tgif.operate({'slot':slot,'operation':op,'destination':'6005656'})
     self.assertTrue(opener.open.call_args.args[0].full_url.endswith(f'/3202139/{slot-1}/{tg}'))
    response.__enter__.return_value.read.return_value=b'<html>error</html>'
    with patch.object(tgif,'profile',return_value=profile),patch('urllib.request.build_opener',return_value=opener):
     with self.assertRaises(ValueError):tgif.operate({'slot':slot,'operation':op,'destination':'6005656'})
 def test_capability(self):
  with patch.object(v2_radio,'profile',return_value={'tgif_id':'3202139','tgif_slots':[1,2]}),patch.object(v2_radio,'credentials',return_value={}):
   v2_radio.validate({'mode':'dmr','family':'TGIF','slot':1,'operation':'link','destination':'6005656'})
   with self.assertRaises(ValueError):v2_radio.validate({'mode':'dmr','family':'TGIF','slot':1,'operation':'enable'})
if __name__=='__main__':unittest.main()
