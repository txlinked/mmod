import unittest
from radio import events
class RadioTests(unittest.TestCase):
 def test_slots_and_end(self):
  lines=['M: 2026-09-15 12:00:01.000 DMR Slot 1, received network voice header from K1ABC to TG 3100','M: 2026-09-15 12:00:02.000 DMR Slot 2, received RF voice header from G1ABC to TG 9']
  import datetime
  now=datetime.datetime(2026,9,15,12,0,4,tzinfo=datetime.timezone.utc).timestamp()
  d=events(lines,now);self.assertTrue(all(s['transmission'] for s in d['slots']))
  lines.append('M: 2026-09-15 12:00:03.000 DMR Slot 1, received network end of voice transmission from K1ABC to TG 3100, 2.0 seconds')
  d=events(lines,now);self.assertIsNone(d['slots'][0]['transmission']);self.assertIsNotNone(d['slots'][1]['transmission']);self.assertEqual(len(d['activity']),2)
  self.assertIsNone(events(lines,now+181)['slots'][1]['transmission'])
 def test_watchdog(self):
  lines=['M: 2026-09-15 12:00:01.000 DMR Slot 2, received network late entry from 123 to TG 9','M: 2026-09-15 12:00:02.000 DMR Slot 2, network watchdog has expired']
  self.assertIsNone(events(lines)['slots'][1]['transmission'])
