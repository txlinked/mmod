import tempfile
from pathlib import Path
import unittest
import collector

class CollectorTests(unittest.TestCase):
    def test_actual_formats_and_direction(self):
        lines = ['M: 2026-09-12 11:14:24.595 DMR Slot 1, received network end of voice transmission from NB2E to TG 3100, 1.6 seconds, 0% packet loss, BER: 0.0%',
                 'M: 2026-09-12 11:15:24.595 DMR Slot 2, received RF end of voice transmission from TESTCALL to TG 9, 3.2 seconds, BER: 0.1%, RSSI: -80 dBm',
                 'M: 2026-09-12 11:16:24.595 DMR Slot 1, received network voice header from TEST to TG 10']
        result = collector.activity(lines)
        self.assertEqual(len(result), 2)
        self.assertEqual(result[0]['source'], 'RF')
        self.assertEqual(result[1]['target'], '3100')
        self.assertEqual(result[1]['seconds'], 1.6)

    def test_tail_bounds_and_missing(self):
        with tempfile.TemporaryDirectory() as folder:
            p=Path(folder)/'large.log'
            p.write_text('discard\n' * 50000 + 'last event\n')
            result=collector.tail(p)
            self.assertEqual(result[-1], 'last event')
            self.assertLess(len('\n'.join(result)), 131072)
            self.assertEqual(collector.tail(Path(folder)/'missing'), [])

if __name__ == '__main__':
    unittest.main()
