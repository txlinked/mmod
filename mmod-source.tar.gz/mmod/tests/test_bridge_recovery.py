import json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import radio
class BridgeRecovery(unittest.TestCase):
 def test_restart_recovers_original_past_debug_noise(self):
  with tempfile.TemporaryDirectory() as d,patch.object(radio,'ROOT',Path(d)),patch.object(radio,'atomic',side_effect=lambda p,v:p.write_text(json.dumps(v))):
   root=Path(d); log=root/'host.log'
   lines=['M: 2026-10-06 18:00:44.914 DMR Slot 2, received network late entry from 1 to TG 7100334','M: 2026-10-06 18:00:46.252 DMR Slot 2, received network end of voice transmission from 1 to TG 7100334, 1.6 seconds, 0% packet loss','M: 2026-10-06 18:00:46.299 DMR Slot 2, received network late entry from 1 to TG 7100334','M: 2026-10-06 18:00:47.803 DMR Slot 2, network watchdog has expired, 1.6 seconds, 92% packet loss']
   snap=radio.events(lines)
   for row in snap['activity']:row['mode']='DMR2YSF'
   radio.retain_callers(snap)
   log.write_text('\n'.join(lines)+'\n'+('D: debug audio noise\n'*10000))
   radio.seed_last_callers(log,{'crossmode_sources':[{'slot':2,'log_directory':d,'routed_targets':['7100334']}]},radio.Lookup())
   saved=json.loads((root/'last-callers.json').read_text())['2']
   self.assertEqual(saved['end_reason'],'end');self.assertEqual(saved['loss'],0)
   self.assertEqual(saved['display_caller'],'Unknown bridge caller')
   self.assertEqual(saved['caller'],'1')
 def test_identity_label_is_scoped_and_reversible(self):
  for row in [dict(mode='DMR',source='network',caller='1'),dict(mode='DMR2YSF',source='RF',caller='1'),dict(mode='DMR2YSF',source='network',caller='1',callsign='K1ABC')]:
   radio.label_bridge_identity(row);self.assertNotIn('display_caller',row)
 def test_startup_scan_has_byte_bound(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'log';p.write_text('M: 2026-10-06 18:00:44.914 DMR Slot 2, received network late entry from 1 to TG 7100334\n'+'noise\n'*100)
   self.assertEqual(list(radio.seed_event_lines(p,100)),[])
