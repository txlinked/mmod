import tempfile,unittest
from pathlib import Path
from radio import crossmode,events

class CrossmodeTests(unittest.TestCase):
 def test_matches_origin_and_rejects_wrong_target(self):
  with tempfile.TemporaryDirectory() as folder:
   Path(folder,'DMR2YSF.log').write_text('M: 2026-09-16 01:20:47.883 Received YSF Header: Src: N5YAI-JOHN Dst: *****\nM: 2026-09-16 01:20:47.884 DMR ID not found, using default ID: 314583, DstID: TG 100334\n')
   config={'crossmode_sources':[{'log_directory':folder,'slot':2,'target_offset':7000000}]}
   for target,expected in [('7100334','N5YAI'),('3100','314583')]:
    d=events([f'M: 2026-09-16 01:20:47.889 DMR Slot 2, received network voice header from 314583 to TG {target}'])
    crossmode(d,config)
    self.assertEqual(d['activity'][0]['caller'],expected)
