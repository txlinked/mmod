import json
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import patch
import radio
import log_limit

class BoundedMonitorTests(unittest.TestCase):
 def test_startup_uses_tail_and_preserves_saved_slot(self):
  with tempfile.TemporaryDirectory() as folder, patch.object(radio,'ROOT',Path(folder)), patch.object(radio,'tail',return_value=[]) as tail:
   root=Path(folder)
   old=dict(slot=2,started=100,target='3148',caller='N1WP',seconds=1,active=False,name='Test')
   (root/'last-callers.json').write_text(json.dumps({'2':old}))
   radio.seed_last_callers(root/'not-opened.log',{},radio.Lookup())
   tail.assert_called_once()
   self.assertEqual(json.loads((root/'last-callers.json').read_text())['2'],old)

 def test_directory_rebuild_does_not_block_live_thread(self):
  entered=threading.Event();release=threading.Event()
  def slow(worker,path):
   entered.set();release.wait(5);worker.repeaters={'123':{'callsign':'K1ABC'}}
  with tempfile.TemporaryDirectory() as folder, patch.object(radio,'ROOT',Path(folder)), patch.object(radio.Lookup,'refresh',slow):
   lookup=radio.Lookup()
   try:
    lookup.refresh_async(None)
    self.assertTrue(entered.wait(2));self.assertFalse(lookup.pending.done())
    self.assertEqual(len(radio.events([])['slots']),2)
    release.set();lookup.pending.result(timeout=2);lookup.finish_refresh()
    self.assertEqual(lookup.repeaters['123']['callsign'],'K1ABC')
   finally:
    release.set();lookup.executor.shutdown(wait=True)

 def test_log_trim_keeps_tail_inode_and_mtime(self):
  with tempfile.TemporaryDirectory() as folder, patch.object(log_limit,'LIMIT',100):
   p=Path(folder)/'MMDVM.log';p.write_bytes(b'old\n'*100+b'newest call\n')
   before=p.stat()
   self.assertTrue(log_limit.trim(p));self.assertLessEqual(p.stat().st_size,50)
   self.assertTrue(p.read_bytes().endswith(b'newest call\n'))
   self.assertEqual(p.stat().st_ino,before.st_ino);self.assertEqual(p.stat().st_mtime_ns,before.st_mtime_ns)
   self.assertFalse(log_limit.trim(p))
