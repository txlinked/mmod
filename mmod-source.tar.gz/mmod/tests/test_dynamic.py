import unittest,json,time
from unittest.mock import patch
import brandmeister as bm
import v2_radio as radio

class DynamicTests(unittest.TestCase):
 def test_dynamic_endpoint_does_not_mutate_static(self):
  with patch.object(bm,'profile',return_value={'bm_id':'314583','duplex':True}),patch.object(bm,'credentials',return_value={'key':'test','device':'314583'}),patch.object(bm,'request',return_value={}) as request,patch('pathlib.Path.unlink'):
   bm.operate({'operation':'clear_dynamic','slot':2})
   request.assert_called_once_with('314583','/action/dropDynamicGroups/2',key='test')
 def test_other_slot_does_not_block_bm(self):
  for operation in ['link','unlink','clear_dynamic']:
   job={'mode':'dmr','operation':operation,'slot':2,'family':'BrandMeister','destination':'91'}
   for slot in [1,2]:
    with patch.object(radio,'validate'),patch.object(radio,'profile',return_value={}),patch('pathlib.Path.read_text',return_value=json.dumps({'updated':time.time(),'slots':[{'slot':slot,'transmission':{'caller':'TEST'}}]})),patch('brandmeister.operate',return_value='mock') as operate:
     if slot==1:
      self.assertEqual(radio.execute(job),'mock');operate.assert_called_once()
     else:
      with self.assertRaisesRegex(ValueError,'Selected timeslot'):radio.execute(job)
      operate.assert_not_called()
 def test_clear_requires_key_and_valid_slot(self):
  with patch.object(radio,'profile',return_value={'bm_id':'314583','duplex':True}),patch.object(radio,'credentials',return_value={}):
   with self.assertRaises(ValueError):radio.validate({'mode':'dmr','operation':'clear_dynamic','slot':2,'family':'BrandMeister'})
