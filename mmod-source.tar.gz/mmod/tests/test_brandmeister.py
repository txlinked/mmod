import json,os,tempfile,unittest,urllib.error
from pathlib import Path
from unittest.mock import patch
import brandmeister as bm
import discover_controls as discover

class BrandMeisterTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        for target,value in [('STATE',Path(self.tmp.name)),('profile',lambda:{'bm_id':'123456','duplex':True})]:
            p=patch.object(bm,target,value);p.start();self.addCleanup(p.stop)
    def test_normalize_subscriptions(self):
        self.assertEqual(bm.subscriptions({'staticSubscriptions':[{'slot':'1','talkgroup':'3100'},{'slot':9,'talkgroup':1}], 'dynamicSubscriptions':[{'slot':2,'talkgroup':3148}]}),[{'slot':1,'tg':'3100','kind':'static'},{'slot':2,'tg':'3148','kind':'dynamic'}])
        with self.assertRaises(ValueError):bm.subscriptions({'html':'error'})
    def test_secret_saved_restrictively_and_failed_replace_preserves_it(self):
        with patch.object(bm,'request',return_value={'staticSubscriptions':[]}) as request:
            message=bm.save_key('test.key.secret');request.assert_called_once_with('123456','/profile')
        self.assertNotIn('test.key.secret',message)
        f=bm.STATE/'brandmeister.json';self.assertEqual(f.stat().st_mode&0o777,0o600)
        with patch.object(bm,'request',side_effect=ValueError('Offline')):
            with self.assertRaises(ValueError):bm.save_key('replacement.key.secret')
        self.assertEqual(bm.credentials()['key'],'test.key.secret')
    def test_targeted_static_controls_and_no_dynamic_wipe(self):
        with patch.object(bm,'credentials',return_value={'device':'123456','key':'secret'}),patch.object(bm,'request',return_value={}) as request:
            job={'operation':'unlink','slot':1,'destination':'3100'};bm.operate(job)
            request.assert_called_once_with('123456','/talkgroup/1/3100','DELETE',key='secret')
            request.reset_mock();job['operation']='link';bm.operate(job)
            request.assert_called_once_with('123456','/talkgroup','POST',{'slot':1,'group':3100},'secret')
            request.reset_mock();job['subscription_kind']='dynamic'
            with self.assertRaises(ValueError):bm.operate(job)
            request.assert_not_called()
    def test_http_errors_do_not_reveal_credentials(self):
        class Fail:
            def open(self,*args,**kwargs):raise urllib.error.HTTPError('https://example.invalid/SECRET',403,'SECRET',{},None)
        with patch('urllib.request.build_opener',return_value=Fail()):
            with self.assertRaisesRegex(ValueError,'denied access') as error:bm.request('123456','/profile',key='SECRET')
        self.assertNotIn('SECRET',str(error.exception))

class DiscoveryTests(unittest.TestCase):
    def test_local_config_and_nondefault_network_indices(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);modem=root/'MMDVM.ini';gateway=root/'DMRGateway.ini'
            modem.write_text('[General]\nDuplex=1\n[DMR]\nId=123456\n')
            gateway.write_text('[DMR Network 3]\nEnabled=1\nName=BrandMeister\n[DMR Network 4]\nEnabled=1\nName=DMR2YSF\nTGRewrite0=1,7000000,2,0,999999\n')
            def service(name,binary):return {'ini':str(gateway),'binary':'/radio/'+binary} if binary=='DMRGateway' else {'ini':'/radio/ysf.ini','binary':'/radio/YSFGateway'}
            with patch.object(discover,'service',side_effect=service):result=discover.discover({'mmdvm_ini':str(modem)})
            self.assertEqual(result['bm_id'],'123456');self.assertEqual(result['bm_net'],'net3');self.assertEqual(result['ysf_slot'],1);self.assertEqual(result['ysf_net'],'net4')
    def test_missing_gateways_have_no_invented_controls(self):
        with patch.object(discover,'service',return_value={}):result=discover.discover({})
        self.assertNotIn('ysf',result);self.assertNotIn('bm_id',result)
