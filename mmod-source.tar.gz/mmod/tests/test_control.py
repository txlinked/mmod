import json
from pathlib import Path
import tempfile
import time
import unittest
from unittest.mock import patch
from types import SimpleNamespace
import control

class ControlTests(unittest.TestCase):
    def test_only_allowlisted_services_and_no_shell(self):
        calls=[]
        def run(args):
            calls.append(args)
            return SimpleNamespace(returncode=0,stdout='loaded\n',stderr='')
        job=dict(action='stop',confirmation='CONFIRM',created=time.time())
        with patch.object(control,'run',side_effect=run):
            result=control.execute(job,{'services':['mmdvmhost.service','mmod.service','--bad.service','bad;evil.service']})
        self.assertEqual([x['service'] for x in result],['mmdvmhost.service'])
        self.assertIn(['stop','mmdvmhost.service'],calls)
    def test_invalid_or_stale_requests_do_nothing(self):
        with patch.object(control,'run') as run:
            for job in [dict(action='shell',confirmation='CONFIRM',created=time.time()),dict(action='reboot',confirmation='CONFIRM',created=time.time()),dict(action='stop',confirmation='CONFIRM',created=0)]:
                with self.assertRaises(ValueError):control.execute(job,{})
            run.assert_not_called()
    def test_reload_does_not_restart(self):
        def run(args):return SimpleNamespace(returncode=0,stdout='loaded' if 'LoadState' in ' '.join(args) else 'no',stderr='')
        with patch.object(control,'run',side_effect=run) as mock:
            result=control.execute(dict(action='reload',confirmation='CONFIRM',created=time.time()),{'services':['mmdvmhost.service']})
        self.assertFalse(result[0]['ok']);self.assertEqual(mock.call_count,2)
    def test_reboot_requires_exact_confirmation(self):
        with patch.object(control,'run',return_value=SimpleNamespace(returncode=0,stderr='')) as run:
            control.execute(dict(action='reboot',confirmation='REBOOT',created=time.time()),{})
            run.assert_called_once_with(['--no-block','reboot'])

if __name__=='__main__':unittest.main()
