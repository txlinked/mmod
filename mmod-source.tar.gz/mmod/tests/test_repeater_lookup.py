import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import radio

class RepeaterLookupTests(unittest.TestCase):
 def test_directory_refresh_repairs_saved_calls_without_new_traffic(self):
  with tempfile.TemporaryDirectory() as folder, patch.object(radio,'ROOT',Path(folder)):
   root=Path(folder);lookup=radio.Lookup()
   row=dict(slot=2,started=100,target='3148',caller='314803',seconds=1.2,active=False,name='',country='')
   radio.retain_callers(dict(activity=[row]));radio.preserve_history(dict(activity=[row]))
   directory=root/'repeaters.json'
   directory.write_text(json.dumps({'rptrs':[dict(id=314803,callsign='N1WP',city='College Station',state='Texas',country='United States')]}))
   lookup.refresh(None)
   snap=dict(activity=[]);radio.retain_callers(snap,lookup);radio.preserve_history(snap,lookup)
   for record in [snap['last_calls'][0],snap['activity'][0]]:
    self.assertEqual(record['callsign'],'N1WP');self.assertEqual(record['name'],'Repeater')
    self.assertEqual(record['location'],'College Station, Texas, USA')
   self.assertEqual(json.loads((root/'caller-history.json').read_text())[0]['callsign'],'N1WP')
   self.assertEqual(json.loads((root/'last-callers.json').read_text())['2']['callsign'],'N1WP')
   directory.write_text('bad download');lookup.refresh(None)
   fresh=dict(row);lookup.enrich({'activity':[fresh]});self.assertEqual(fresh['callsign'],'N1WP')

 def test_subscriber_wins_and_unknown_id_stays_unknown(self):
  with tempfile.TemporaryDirectory() as folder, patch.object(radio,'ROOT',Path(folder)):
   root=Path(folder)
   (root/'repeaters.json').write_text(json.dumps({'rptrs':[dict(id=123456,callsign='K1RPT')]}))
   users=root/'users.csv';users.write_text('RADIO_ID,CALLSIGN,FIRST_NAME,CITY,STATE,COUNTRY\n123456,K1USER,Alice,Town,Texas,United States\n')
   lookup=radio.Lookup();lookup.refresh(users)
   rows=[dict(caller=x,name='',country='') for x in ['123456','999999']]
   lookup.enrich({'activity':rows})
   self.assertEqual(rows[0]['callsign'],'K1USER');self.assertEqual(rows[0]['name'],'Alice')
   self.assertNotIn('callsign',rows[1]);lookup.db.close()
