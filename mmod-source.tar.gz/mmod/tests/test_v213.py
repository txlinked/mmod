import ast,json,subprocess,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import directories as d
class ReleaseTests(unittest.TestCase):
 def test_download_deadline(self):
  with patch.object(d.subprocess,'run',side_effect=subprocess.TimeoutExpired('download',50)):
   with self.assertRaises(OSError):d.fetch('https://example.invalid')
 def test_size_bound(self):
  with patch.object(d.subprocess,'run',return_value=subprocess.CompletedProcess([],0,b'12345',b'')):
   with self.assertRaises(ValueError):d.fetch('https://example.invalid',4)
 def test_download_error(self):
  with patch.object(d.subprocess,'run',return_value=subprocess.CompletedProcess([],1,b'',b'failed')):
   with self.assertRaises(OSError):d.fetch('https://example.invalid')
 def test_health_uses_installed_version(self):
  source=Path(__file__).resolve().parents[1]/'app.py'
  fn=next(n for n in ast.parse(source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='health');fn.decorator_list=[]
  with tempfile.TemporaryDirectory() as folder:
   root=Path(folder);(root/'VERSION').write_text('2.0.13')
   ns={'status':lambda:{'stale':False},'JSONResponse':lambda data,**kw:data,'Path':Path,'__file__':str(root/'app.py')}
   exec(compile(ast.Module(body=[fn],type_ignores=[]),'health-test','exec'),ns)
   self.assertEqual(ns['health']()['version'],'2.0.13')
   (root/'VERSION').write_text('2.0.14');self.assertEqual(ns['health']()['version'],'2.0.14')
