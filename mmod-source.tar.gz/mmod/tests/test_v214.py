import tempfile,unittest
from pathlib import Path
from radio import crossmode_records,events,log_timestamp
class CacheTests(unittest.TestCase):
 def test_live_timer(self):
  line='M: 2026-11-01 14:00:00.000 DMR Slot 1, received RF voice header from N3DMC to TG 3100'
  stamp=log_timestamp(line[3:26])
  self.assertEqual(events([line],stamp+5)['slots'][0]['transmission']['seconds'],5)
  self.assertIsNone(events([line],stamp+181)['slots'][0]['transmission'])
 def test_file_changes(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'DMR2YSF.log'
   p.write_text('M: 2026-11-01 14:00:00.000 Received YSF Header: Src: N3DMC\nM: 2026-11-01 14:00:00.000 DMR ID of N3DMC: 123, DstID: TG 334\n')
   def read():
    s=p.stat();return crossmode_records(((str(p),s.st_mtime_ns,s.st_size),),7100000)
   a=read();self.assertEqual(a[0][3],'7100334');self.assertIs(a,read())
   p.write_text(p.read_text()+'M: 2026-11-01 14:00:05.000 YSF received end of voice transmission\n')
   self.assertGreater(read()[0][4],a[0][4])
   p.write_text('');self.assertEqual(read(),[])
