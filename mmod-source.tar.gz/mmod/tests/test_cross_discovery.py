import unittest,tempfile,json
from pathlib import Path
from unittest.mock import patch
import discover_controls as dc
import radio
class CrossDiscovery(unittest.TestCase):
 def test_local_path_and_range(self):
  with tempfile.TemporaryDirectory() as tmp:
   b=Path(tmp)/'bridge.ini';b.write_text('[Log]\nFileLevel=1\nFilePath=.\nFileRoot=DMR2YSF\n')
   g=Path(tmp)/'gateway.ini';g.write_text('[DMR Network 2]\nTGRewrite0=2,7100000,2,100000,100000\n')
   data={'ysf_route':'crossmode','ysf_net':'net2','dmr':{'ini':str(g)}}
   with patch.object(dc,'service',return_value={'ini':str(b),'binary':tmp+'/DMR2YSF'}),patch.object(dc.subprocess,'check_output',return_value=tmp):
    rows=dc.crossmode_sources(data)
   self.assertEqual(rows[0]['target_offset'],7000000);self.assertEqual(rows[0]['target_range'],[7100000,7199999]);self.assertEqual(rows[0]['log_directory'],str(Path(tmp).resolve()))
 def test_native_not_cross(self):self.assertEqual(dc.crossmode_sources({'ysf_route':'native'}),[])
 def test_replaces_repeater_identity(self):
  import datetime
  with tempfile.TemporaryDirectory() as tmp:
   Path(tmp,'DMR2YSF-test.log').write_text('M: 2026-09-20 00:00:00.000 Received YSF Header: Src: N5CLE Dst: *****\nM: 2026-09-20 00:00:00.010 DMR ID not found, using default ID: 312298, DstID: TG 100381\n')
   row=dict(slot=2,target='7100381',source='network',caller='312298',started=datetime.datetime(2026,9,20,tzinfo=datetime.timezone.utc).timestamp()+.2,callsign='K5CRA',name='Cove Repeater',country='USA',location='Cove')
   radio.crossmode({'activity':[row]},{'crossmode_sources':[dict(slot=2,log_directory=tmp,target_offset=7000000,target_range=[7100000,7199999])]})
   self.assertEqual(row['callsign'],'N5CLE');self.assertEqual(row['name'],'');self.assertEqual(row['location'],'');self.assertEqual(row['mode'],'DMR2YSF')
