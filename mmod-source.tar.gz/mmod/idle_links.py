"""Expire confirmed temporary links after 15 minutes without local RF activity."""
import configparser,json,os,time
from pathlib import Path
LIMIT=900

def read(path):
    try:return json.loads(Path(path).read_text())
    except (OSError,ValueError):return {}

def due(links,radio,remember,now,default='',limit=LIMIT):
    jobs=[];active={};rows=radio.get('activity',[])
    for group in links.get('slots',[]):
        slot=group.get('slot');dynamic=[]
        for link in group.get('links',[]):
            kind=link.get('kind');dest=str(link.get('destination',''))
            if kind=='static' or not dest:continue
            gateway=kind=='gateway'
            # Native Fusion needs an RF activity source; DMR-only samples cannot prove it idle.
            if gateway and link.get('mode')=='ysf' and not any(r.get('mode') in ('YSF','System Fusion') for r in rows):continue
            if gateway and (dest==default or link.get('mode') not in ('dmr2ysf','ysf')):continue
            if not gateway and kind!='dynamic':continue
            key='|'.join([str(slot),link.get('family',''),dest])
            start=float(remember.get(key,now));start=min(start,now)
            for row in rows:
                if str(row.get('source','')).lower()!='rf':continue
                if slot is not None and row.get('slot')!=slot:continue
                if not gateway and str(row.get('target',''))!=dest:continue
                stamp=now if row.get('active') else row.get('ended',row.get('started',0))
                if isinstance(stamp,(int,float)) and stamp<=now+5:start=max(start,min(stamp,now))
            active[key]=start
            if gateway:
                if now-start>=limit:jobs.append(dict(mode=link['mode'],family=link['family'],slot=slot or 2,destination=dest,operation='unlink'))
            else:dynamic.append(start)
        if dynamic and group.get('clear_dynamic') and now-max(dynamic)>=limit:
            jobs.append(dict(mode='dmr',family='BrandMeister',slot=slot,destination='',operation='clear_dynamic'))
    return jobs,active

def tick():
    now=time.time();runtime=Path('/run/mmod');history=runtime/'idle-links.json'
    prior=read(history)
    if now-prior.get('checked',0)<10:return
    links=read(runtime/'links.json');radio=read(runtime/'radio.json')
    if now-links.get('updated',0)>30 or now-radio.get('updated',0)>5 or radio.get('error'):return
    from brandmeister import profile
    p=profile();default=''
    if p.get('ysf',{}).get('ini'):
        c=configparser.ConfigParser(strict=False,interpolation=None);c.read(p['ysf']['ini']);default=c.get('Network','Startup',fallback='').strip()
    policy=read('/var/lib/mmod/state/dynamic-timer.json')
    minutes=policy.get('minutes',15)
    if type(minutes) is not int or not 1<=minutes<=1440:minutes=15
    jobs,active=due(links,radio,prior.get('links',{}),now,default,minutes*60)
    history.write_text(json.dumps(dict(checked=now,attempt=prior.get('attempt',0),links=active)));history.chmod(0o600)
    if any(s.get('transmission') for s in radio.get('slots',[])):return
    if not jobs or now-prior.get('attempt',0)<60:return
    from v2_radio import validate
    job=jobs[0]
    try:validate(job)
    except ValueError:return
    job.update(action='radio',confirmation='CONFIRM',created=now,username='auto-timeout')
    state=Path('/var/lib/mmod/state');tmp=state/'idle-request.tmp'
    try:
        tmp.write_text(json.dumps(job));tmp.chmod(0o600);os.link(tmp,state/'control-request.json')
    except FileExistsError:return
    finally:tmp.unlink(missing_ok=True)
    history.write_text(json.dumps(dict(checked=now,attempt=now,links=active)))
    print('MMOD inactivity timeout ('+str(minutes)+' minutes):',job['mode'],'slot',job['slot'],flush=True)
