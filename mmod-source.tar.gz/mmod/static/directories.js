(() => {
  const section = document.getElementById('system');
  const el = (tag, text) => { const e = document.createElement(tag); if (text !== undefined) e.textContent = text; return e; };
  const panel = el('article'); panel.className = 'panel';
  panel.append(el('h3', 'Talkgroup & reflector directories'));
  panel.append(el('p', 'Updated weekly. Search by network, number, or name. Directory entries do not enable radio modes or change routing.'));
  const select = el('select'); select.setAttribute('aria-label', 'Directory network');
  const search = el('input'); search.placeholder = 'Search number or name…'; search.setAttribute('aria-label', 'Search directories');
  const info = el('p'), result = el('div'), attribution = el('details');
  result.className = 'table-wrap'; attribution.append(el('summary', 'Directory source & attribution'));
  const credit = el('pre'); credit.style.whiteSpace = 'pre-wrap'; attribution.append(credit);
  panel.append(select, search, info, result, attribution); section.append(panel);
  let lists = {};
  function render() {
    const item = lists[select.value] || {entries: {}};
    const rows = Object.entries(item.entries).filter(([id, name]) => `${id} ${name}`.toLowerCase().includes(search.value.toLowerCase()));
    const updated = item.updated ? new Date(item.updated * 1000).toLocaleString() : 'Never';
    info.textContent = `${rows.length} entries · Last successful update: ${updated}${item.error ? ' · ' + item.error : ''}`;
    if (select.value === 'POCSAG / DAPNET') info.textContent += ' · Paging categories, not voice talkgroups or personal pager addresses.';
    const t = el('table'), head = el('tr'); head.append(el('th', 'Number / reflector'), el('th', 'Name')); t.append(head);
    rows.slice(0, 100).forEach(([id, name]) => {const row = el('tr'); row.append(el('td', id), el('td', name)); t.append(row);});
    result.replaceChildren(t);
    if (rows.length > 100) result.append(el('p', 'Showing first 100 results. Narrow your search to find others.'));
    credit.textContent = (item.source || 'Upstream unavailable') + '\n' + (item.attribution || '');
  }
  async function refresh() {
    try {
      const response = await fetch('/api/directories'); if (!response.ok) throw Error();
      const data = await response.json(); lists = data.lists || {};
      const previous = select.value;
      select.replaceChildren(...Object.keys(lists).map(name => {const o = el('option', name); o.value = name; return o;}));
      if (lists[previous]) select.value = previous;
      if (!Object.keys(lists).length) {info.textContent = 'Initial directory download is running. Lists will appear automatically.'; return;}
      render();
    } catch {info.textContent = 'Directory status unavailable; retrying shortly.';}
  }
  select.addEventListener('change', render); search.addEventListener('input', render);
  refresh(); setInterval(refresh, 60000);
})();
