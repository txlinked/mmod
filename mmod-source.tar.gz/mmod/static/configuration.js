'use strict';
(() => {
 let info=null, approved=null, dirty=false;
 const inputs=new Map();
 const liveIds=new Set(['host.Modem.RXInvert','host.Modem.TXInvert','host.Modem.PTTInvert']);
 const liveBadges=new Map();
 let liveBusy=false;
 const message=t=>{$('setup-message').textContent=t;};
 function edits(){const result={};for(const [id,{input,field}] of inputs){const v=field.kind==='bool'?(input.checked?'1':'0'):input.value;if(v!==field.value && !(field.kind==='secret'&&!v))result[id]=v;}return result;}
 function changed(){approved=null;dirty=Object.keys(edits()).length>0;$('setup-save').disabled=true;$('setup-review-box').hidden=true;message(dirty?'Unsaved changes. Review before saving.':'');}
 function render(data){
  info=data;inputs.clear();liveBadges.clear();$('setup-groups').replaceChildren();$('setup-advanced-groups').replaceChildren();$('setup-advanced').open=false;$('setup-warnings').replaceChildren(...data.warnings.map(t=>node('p',t,'caption')));
  const basicIds=new Set(['host.NXDN.Id','station.site','host.General.Callsign','host.General.Id','host.Info.Location','host.General.Duplex','host.DMR.ColorCode','host.Modem.TXFrequency','host.Modem.RXFrequency','host.Info.TXFrequency','host.Info.RXFrequency','host.Modem.UARTPort','host.Modem.Port','host.Modem.Protocol','host.Modem.UARTSpeed']);
  const sections=[];
  for(const group of data.groups){
   const main=['Station','Radio / modem','Modes','Cross modes'].includes(group.title);
   const basic=main?group.fields.filter(f=>['Modes','Cross modes'].includes(group.title)||basicIds.has(f.id)):[];
   const extra=group.fields.filter(f=>!basic.includes(f));
   if(basic.length)sections.push({title:group.title==='Radio / modem'?'Radio':group.title,fields:basic,basic:true});
   if(extra.length)sections.push({title:main?group.title+' · additional settings':group.title,fields:extra,basic:false});
  }
  sections.sort((a,b)=>Number(b.basic)-Number(a.basic));
  for(const group of sections){
   const details=node('details',undefined,'panel setup-group');details.open=group.basic;details.append(node('summary',group.title));
   const grid=node('div',undefined,'setup-grid');
   for(const f of group.fields){
    const label=node('label',undefined,f.kind==='bool'?'setup-toggle':'');label.append(node('span',f.label));
    const input=document.createElement('input');input.dataset.setting=f.id;
    if(f.kind==='bool'){input.type='checkbox';input.checked=f.value==='1';}
    else{input.type=f.kind==='secret'?'password':['int','decimal','frequency'].includes(f.kind)?'number':'text';input.value=f.value;input.autocomplete=f.kind==='secret'?'new-password':'off';input.maxLength=200;
     if(input.type==='number'){input.step=f.kind==='int'?'1':'any';if(f.low!==null)input.min=f.low;if(f.high!==null)input.max=f.high;}
     if(f.kind==='secret')input.placeholder=f.configured?'Saved — leave blank to keep':'Not set';}
    input.addEventListener('input',changed);label.append(input);
    if(liveIds.has(f.id)){const badge=node('small','File: '+(f.value==='1'?'On':'Off'),'setup-live-value');label.append(badge);liveBadges.set(f.id,badge);}grid.append(label);inputs.set(f.id,{input,field:f});
   }
   if(group.title==='Cross modes')details.append(node('p','Select a configured conversion route, then Review, Save and Apply. DMR → YSF also carries FCS rooms.','caption'));
   if(group.title==='Cross modes'){
    const available=new Set(group.fields.map(f=>f.label));
    for(const name of ['DMR → YSF / FCS','DMR → NXDN','DMR → P25','YSF → DMR','YSF → NXDN','YSF → P25']){
     if(available.has(name))continue;
     const label=node('label',undefined,'setup-toggle');label.append(node('span',name+' · Setup required'));
     const input=document.createElement('input');input.type='checkbox';input.disabled=true;label.append(input);grid.append(label);
    }
   }
   details.append(grid);$(group.basic?'setup-groups':'setup-advanced-groups').append(details);
  }
  $('setup-apply').disabled=!data.pending_services.length||data.pending;
  $('setup-pending').textContent=data.pending_services.length?'Saved changes await Apply: '+data.pending_services.join(', '):'No service restarts pending.';
  $('setup-save').disabled=true;$('setup-review-box').hidden=true;approved=null;dirty=false;
 }
 async function load(){
  if(window.v2Identity?.role!=='admin')return;
  message('Loading station configuration…');
  try{render(await api('configuration'));message('');}catch(e){message(e.message);}
 }
 $('setup-reload').onclick=()=>{if(!dirty||confirm('Discard unsaved configuration edits?'))load();};
 $('setup-review').onclick=async()=>{
  if(!info)return;
  try{const changes=edits();const response=await api('configuration/review',{method:'POST',body:JSON.stringify({revision:info.revision,changes})});
   if(!response.changes.length){message('No changes to save.');return;}
   $('setup-review-list').replaceChildren(...response.changes.map(c=>node('li',`${c.label}: ${c.before||'(blank)'} → ${c.after||'(blank)'}`)));
   approved=JSON.stringify(changes);$('setup-review-box').hidden=false;$('setup-save').disabled=false;message('Review the changes below. Saving does not restart the radio.');
  }catch(e){message(e.message);}
 };
 async function submit(action){
  if(!info)return;const changes=action==='save'?edits():{};
  if(action==='save'&&JSON.stringify(changes)!==approved){message('Review the changes first.');return;}
  if(action==='apply'&&(dirty||!confirm('Restart the affected running radio services now? This interrupts radio traffic.'))){if(dirty)message('Save or discard your edits before applying.');return;}
  $('setup-save').disabled=true;$('setup-apply').disabled=true;$('setup-review').disabled=true;
  try{const job=await api('configuration',{method:'POST',body:JSON.stringify({revision:info.revision,changes,action})});message('Processing…');
   for(let attempt=0;attempt<95;attempt++){
    await new Promise(resolve=>setTimeout(resolve,2000));const s=await api('configuration/status');
    if(s.result.id===job.id&&!s.result.running){const result=s.result;await load();message(result.message);return;}
   }
   message('No completion received. Reload to check status before submitting again.');
  }catch(e){message(e.message);}finally{$('setup-review').disabled=false;}
 }
 $('setup-save').onclick=()=>submit('save');$('setup-apply').onclick=()=>submit('apply');
 document.querySelector('[data-view="configuration"]').addEventListener('click',()=>{if(!dirty)load();});
 async function refreshFileValues(){
  if(liveBusy||!info||view!=='configuration'||window.v2Identity?.role!=='admin')return;
  liveBusy=true;
  try{
   const current=await api('configuration');
   if(view!=='configuration'||window.v2Identity?.role!=='admin')return;
   const stamp=new Date(current.updated*1000).toLocaleTimeString();
   for(const group of current.groups)for(const f of group.fields){
    const badge=liveBadges.get(f.id);
    if(badge){badge.textContent='File: '+(f.value==='1'?'On':'Off')+' · '+stamp;badge.title='Read from the saved configuration file. Running radio settings change only after Apply.';}
   }
   // Keep the original revision and edits if the file changes underneath the form.
   if(current.revision!==info.revision){
    if(dirty){approved=null;$('setup-save').disabled=true;$('setup-review-box').hidden=true;message('The file changed. Your edits are preserved; reload settings before reviewing and saving.');}
    else{
     for(const group of current.groups)for(const f of group.fields){const entry=inputs.get(f.id);if(entry){if(f.kind==='bool')entry.input.checked=f.value==='1';else entry.input.value=f.value;entry.field=f;}}
     info=current;
    }
   }
  }catch(e){for(const badge of liveBadges.values())badge.textContent='File: unavailable';}
  finally{liveBusy=false;}
 }
 setInterval(refreshFileValues,3000);
 let lastAdmin=false;
 setInterval(()=>{const admin=window.v2Identity?.role==='admin';$('setup-entry').hidden=!admin;
  if(lastAdmin&&!admin){info=null;inputs.clear();$('setup-groups').replaceChildren();$('setup-advanced-groups').replaceChildren();$('setup-review-list').replaceChildren();approved=null;dirty=false;if(view==='configuration')document.querySelector('[data-view="overview"]').click();}
  if(admin&&!lastAdmin&&view==='configuration')load();
  lastAdmin=admin;
 },500);
 window.addEventListener('beforeunload',event=>{if(dirty){event.preventDefault();event.returnValue='';}});
})();
