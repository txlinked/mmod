'use strict';
const themeDefaults={mode:'dark',accent:'teal',density:'comfortable'};
let themeSettings={...themeDefaults};
const themeOptions={mode:['dark','light','system'],accent:['teal','blue','violet','amber','rose'],density:['comfortable','compact']};
try{const stored=JSON.parse(localStorage.getItem('mmod-theme')||'{}');for(const key of Object.keys(themeOptions)){if(themeOptions[key].includes(stored[key]))themeSettings[key]=stored[key];}}catch{}
const systemTheme=matchMedia('(prefers-color-scheme: dark)');
function applyTheme(){const root=document.documentElement;root.dataset.theme=themeSettings.mode==='system'?(systemTheme.matches?'dark':'light'):themeSettings.mode;root.dataset.accent=themeSettings.accent;root.dataset.density=themeSettings.density;}
applyTheme();systemTheme.addEventListener('change',applyTheme);
function saveTheme(){applyTheme();try{localStorage.setItem('mmod-theme',JSON.stringify(themeSettings));document.getElementById('theme-saved').textContent='Saved in this browser. Your preferences will return on your next visit.';}catch{document.getElementById('theme-saved').textContent='Theme applied. Browser storage is unavailable, so this choice lasts for this visit.';}}
for(const key of Object.keys(themeOptions)){const input=document.getElementById('theme-'+key);input.value=themeSettings[key];input.addEventListener('change',()=>{themeSettings[key]=input.value;saveTheme();});}
document.getElementById('theme-reset').addEventListener('click',()=>{themeSettings={...themeDefaults};for(const key of Object.keys(themeOptions))document.getElementById('theme-'+key).value=themeSettings[key];saveTheme();});
