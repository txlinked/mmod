'use strict';
const $ = id => document.getElementById(id);
let data=null, radioData=null, csrf=null, view='overview';
const names={'mmdvmhost.service':'MMDVMHost','dmrgateway.service':'DMR Gateway','dmr2ysf.service':'DMR → YSF','ysfgateway.service':'YSF Gateway'};
function node(tag,text,cls){const n=document.createElement(tag);if(text!==undefined)n.textContent=text;if(cls)n.className=cls;return n;}
function fill(id,text){$(id).textContent=text;}
function age(seconds){let d=Math.floor(seconds/86400),h=Math.floor(seconds/3600)%24,m=Math.floor(seconds/60)%60;return d?`${d}d ${h}h`:`${h}h ${m}m`;}
function details(id,values){$(id).replaceChildren(...Object.entries(values).map(([k,v])=>{const n=node('div');n.append(node('dt',k),node('dd',v||'Not reported'));return n;}));}
function table(target,rows){const wrap=node('div',undefined,'table-wrap'),t=node('table'),head=node('thead'),tr=node('tr');['Time','Callsign / ID','Talkgroup','Slot','Source','Duration'].forEach(x=>tr.append(node('th',x)));head.append(tr);t.append(head);const body=node('tbody');for(const r of rows){const row=node('tr');[r.time.slice(11,19),r.caller,`TG ${r.target}`,`TS ${r.slot}`,r.source,r.active?'LIVE':`${r.seconds.toFixed(1)}s`].forEach((v,i)=>row.append(node('td',v,i===1?'caller':'')));body.append(row);}t.append(body);wrap.append(t);if(!rows.length)wrap.append(node('div','No completed transmissions in the recent log window.','empty'));$(target).replaceChildren(wrap);}
function showActivity(){if(!radioData&&!data)return;const activity=radioData?.activity||data.activity;const query=$('filter').value.toLowerCase();table('recent',activity.slice(0,6));table('all-activity',activity.filter(r=>`${r.caller} ${r.target}`.toLowerCase().includes(query)));}
async function api(path,options={}){const res=await fetch('/api/'+path,{...options,headers:{'Content-Type':'application/json',...(csrf?{'X-CSRF-Token':csrf}:{}),...options.headers}});if(!res.ok){let err=await res.json().catch(()=>({}));throw new Error(typeof err.detail==='string'?err.detail:`Request failed (${res.status})`);}return res.json();}
function render(d){data=d;fill('site-title',d.site);fill('site-breadcrumb',d.site);fill('network-name',d.network||'MMOD');fill('site-description',d.description||'Radio dashboard');fill('station-identity',[d.callsign,d.location].filter(Boolean).join(' · ')||d.site);document.title='MMOD · '+d.site;const s=d.system, host=d.services.find(x=>x.name===(d.host_service||'mmdvmhost.service'));const online=host?.status==='active'&&!d.stale;fill('connection',d.stale?'● Data delayed':'● Live · 5s refresh');$('connection').classList.toggle('bad',d.stale);fill('radio-status',d.stale?'Status unavailable':online?'Repeater online':!host?.installed?'MMDVMHost not installed':'MMDVMHost '+(host?.status||'unknown'));fill('radio-detail',`${d.callsign} · ${d.location} · ${d.duplex?'Duplex repeater':'Simplex'} · ${d.modes.filter(m=>m.enabled).map(m=>m.name).join(', ')||'No modes enabled'}`);fill('call',d.callsign);fill('tx',d.tx);fill('rx',d.rx);fill('dmr-id',d.dmr_id);fill('color-code',d.color_code);fill('duplex',d.duplex?'Duplex':'Simplex');fill('cpu',s.cpu_percent===null?'Sampling':s.cpu_percent.toFixed(1)+'%');$('cpu-bar').style.width=Math.min(100,s.cpu_percent||0)+'%';fill('cpu-note',`${s.cores} cores · Load ${s.load.toFixed(2)}`);let mem=s.memory_used/s.memory_total*100;fill('memory',mem.toFixed(0)+'%');$('memory-bar').style.width=mem+'%';fill('memory-note',`${s.memory_used} / ${s.memory_total} MB`);fill('temperature',s.temperature===null?'N/A':s.temperature.toFixed(0)+'°C');fill('uptime',age(s.uptime));fill('updated','Updated '+new Date(d.updated*1000).toLocaleTimeString());$('notice').hidden=!d.stale;if(d.stale)fill('notice','The collector has not updated for more than 30 seconds. Displayed data may be out of date.');
$('services').replaceChildren(...d.services.filter(x=>x.installed).map(x=>{const row=node('div',undefined,'service'),name=node('div',names[x.name]||x.name);name.append(node('small',x.name));row.append(name,node('span',(x.status==='active'?'● Running':x.status),'status'+(x.status==='active'?'':' bad')));return row;}));$('mode-chips').replaceChildren(...d.modes.filter(m=>m.configured).map(m=>node('span',m.name,'chip'+(m.enabled?' on':''))));
details('hardware',{'Computer':s.hardware,'Operating system':s.os,'Architecture':s.architecture,'Processor':s.cpu,'Hostname':s.hostname,'Storage':`${(s.disk_free/1073741824).toFixed(2)} GiB free of ${(s.disk_total/1073741824).toFixed(2)} GiB`});details('modem',{'Configured device':d.modem.port,'USB serial devices':d.modem.serial.map(x=>x.name+' → '+x.target).join('\n'),'Firmware':d.modem.firmware});$('modes-table').replaceChildren(...d.modes.map(m=>{const row=node('div',undefined,'service');row.append(node('span',m.name),node('span',!m.configured?'Not configured':m.enabled?'Enabled':'Disabled','status'+(m.enabled?'':' bad')));return row;}));showActivity();}
async function refresh(){try{render(await api('status'));if(csrf&&view==='admin')await loadAdmin();}catch(e){fill('connection','● Connection unavailable');$('connection').classList.add('bad');$('notice').hidden=false;fill('notice',e.message+' · Retrying automatically.');}finally{setTimeout(refresh,5000);}}
function setAdmin(loggedIn){$('login').hidden=loggedIn;$('admin-content').hidden=!loggedIn;$('logout').hidden=!loggedIn;}
async function loadAdmin(){try{await maintenanceStatus();const [logs,backups]=await Promise.all([api('logs'),api('backups')]);fill('logs',logs.lines.join('\n'));$('backups').replaceChildren(...backups.items.map(b=>{const row=node('div',undefined,'backup-row'),info=node('div',new Date(b.created*1000).toLocaleString());info.append(node('small',`${(b.size/1024).toFixed(1)} KB · SHA-256 ${b.sha256}`));const a=node('a','Download archive ↓');a.href='/api/backups/'+encodeURIComponent(b.name);row.append(info,a);return row;}));if(backups.pending)fill('backup-message','Backup queued; waiting for the next collector cycle.');else if($('backup-message').textContent)fill('backup-message','Latest backup is ready.');}catch(e){if(/sign in|session/i.test(e.message)){csrf=null;setAdmin(false);}else throw e;}}
document.querySelectorAll('[data-view]').forEach(b=>b.addEventListener('click',()=>{view=b.dataset.view;document.querySelectorAll('.view').forEach(s=>s.hidden=s.id!==view);document.querySelectorAll('nav button').forEach(n=>n.classList.toggle('selected',n.dataset.view===view));if(view==='admin'&&csrf)loadAdmin().catch(e=>fill('backup-message',e.message));}));$('filter').addEventListener('input',showActivity);
$('login').addEventListener('submit',async e=>{e.preventDefault();fill('login-error','');try{const r=await api('login',{method:'POST',body:JSON.stringify({username:$('username').value,password:$('password').value})});csrf=r.csrf;$('password').value='';setAdmin(true);await loadAdmin();}catch(e){fill('login-error',e.message);}});
$('logout').addEventListener('click',async()=>{try{await api('logout',{method:'POST'});csrf=null;setAdmin(false);}catch(e){fill('backup-message',e.message);}});
$('backup').addEventListener('click',async()=>{try{const r=await api('backups',{method:'POST'});fill('backup-message',r.message);}catch(e){fill('backup-message',e.message);}});
api('session').then(r=>{csrf=r.csrf;setAdmin(true);}).catch(()=>setAdmin(false));refresh();

$('change-password').addEventListener('submit',async e=>{
 e.preventDefault(); const button=e.target.querySelector('button'); button.disabled=true;
 try { const r=await api('password',{method:'POST',body:JSON.stringify({current_password:$('current-password').value,new_password:$('new-password').value,confirm_password:$('confirm-password').value})});
 e.target.reset();csrf=null;setAdmin(false);fill('login-error',r.message);
 } catch(error){fill('password-message',error.message);}finally{button.disabled=false;}
});
async function maintenanceStatus(){
 const r=await api('control');
 document.querySelectorAll('[data-control]').forEach(b=>b.disabled=r.pending);
 fill('control-services',(data?.services||[]).filter(s=>s.installed).map(s=>s.name+' ('+s.status+')').join(' · '));
 if(r.pending)fill('control-message','Maintenance operation in progress…');
 else if(r.results)fill('control-message',r.results.length?r.results.map(s=>s.service+': '+s.message).join(' · '):'No installed radio services found.');
 else if(r.message)fill('control-message',r.message);
}
document.querySelectorAll('[data-control]').forEach(button=>button.addEventListener('click',async()=>{
 const action=button.dataset.control;
 if(action==='reboot') {if(prompt('Reboot the system and interrupt radio traffic? Type REBOOT to confirm.')!=='REBOOT')return;}
 else if(!confirm(action.toUpperCase()+' all listed radio services?'+(['stop','restart'].includes(action)?' This interrupts radio traffic.':'')))return;
 document.querySelectorAll('[data-control]').forEach(b=>b.disabled=true);
 try{const r=await api('control',{method:'POST',body:JSON.stringify({action,confirmation:action==='reboot'?'REBOOT':'CONFIRM'})});fill('control-message',r.message);}
 catch(error){fill('control-message',error.message);document.querySelectorAll('[data-control]').forEach(b=>b.disabled=false);}
}));

async function refreshRadio(){
 try{const d=await api('radio');radioData=d;
 for(const slot of [1,2]){const row=d.slots.find(s=>s.slot===slot)?.transmission;const element=$('slot-'+slot);element.classList.toggle('transmitting',!!row&&!d.stale&&!d.error);
 element.textContent=d.stale||d.error?`TS${slot} · Live status unavailable`:row?`TS${slot} · ${row.callsign||row.caller} · ${row.name||'Name unavailable'} · ${row.country||'Country unavailable'} · TG ${row.target} · ${row.source} · ${Math.floor(row.seconds)}s`:`TS${slot} · Idle`;}
 showActivity();
 }catch(error){for(const slot of [1,2]){fill('slot-'+slot,`TS${slot} · Live status unavailable`);$('slot-'+slot).classList.remove('transmitting');}}
 finally{setTimeout(refreshRadio,1000);}
}
refreshRadio();
