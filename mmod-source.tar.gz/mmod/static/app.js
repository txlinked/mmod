'use strict';
const $ = id => document.getElementById(id);
let data=null, radioData=null, csrf=null, view='overview';
const names={'mmdvmhost.service':'MMDVMHost','dmrgateway.service':'DMR Gateway','dmr2ysf.service':'DMR → YSF','ysfgateway.service':'YSF Gateway'};
function node(tag,text,cls){const n=document.createElement(tag);if(text!==undefined)n.textContent=text;if(cls)n.className=cls;return n;}
function fill(id,text){$(id).textContent=text;}
function age(seconds){let d=Math.floor(seconds/86400),h=Math.floor(seconds/3600)%24,m=Math.floor(seconds/60)%60;return d?`${d}d ${h}h`:`${h}h ${m}m`;}
function callerAgo(seconds){const n=Math.max(0,Math.floor(seconds));return n<60?`${n}s ago`:n<3600?`${Math.floor(n/60)} min ago`:`${Math.floor(n/3600)} ${n<7200?'hour':'hours'} ago`;}
function callVisible(r,now){return !!r&&now-(r.ended??(r.started+r.seconds))<86400;}
function details(id,values){$(id).replaceChildren(...Object.entries(values).map(([k,v])=>{const n=node('div');n.append(node('dt',k),node('dd',v||'Not reported'));return n;}));}
function countryLabel(country){const codes={'United States':'US','Canada':'CA','Brazil':'BR','England':'GB','Scotland':'GB','Wales':'GB','Northern Ireland':'GB','Germany':'DE','France':'FR','Italy':'IT','Spain':'ES','Australia':'AU','Japan':'JP','Netherlands':'NL','Portugal':'PT','Mexico':'MX','Argentina':'AR','New Zealand':'NZ','South Africa':'ZA','Belgium':'BE','Sweden':'SE','Norway':'NO','Finland':'FI','Poland':'PL','Austria':'AT','Switzerland':'CH','Ireland':'IE','Alaska':'US','Hawaii':'US'};const code=codes[country];return (code?Array.from(code,c=>String.fromCodePoint(127397+c.charCodeAt(0))).join('')+' ':'')+(country||'—');}
function radioTable(headers,rows){const t=node('table'),head=node('thead'),tr=node('tr');t.className='radio-table';headers.forEach(x=>tr.append(node('th',x)));head.append(tr);t.append(head);const body=node('tbody');rows.forEach(values=>{const row=node('tr');values.forEach((v,i)=>{const cell=node('td');cell.dataset.label=headers[i];if(headers[i]==='Callsign'&&/[a-z]/i.test(String(v))&&/^[a-z0-9/]+$/i.test(String(v))){const link=node('a',v);link.href='https://www.qrz.com/db/'+encodeURIComponent(String(v));link.target='_blank';link.rel='noopener noreferrer';link.title='View '+v+' on QRZ';cell.append(link);}else cell.textContent=v;row.append(cell);});body.append(row);});t.append(body);return t;}
function localCallTime(r){return new Date(r.time.replace(' ','T')+'Z').toLocaleString(undefined,{month:'short',day:'numeric',hour:'2-digit',minute:'2-digit',second:'2-digit'});}
function table(target,rows){const wrap=node('div',undefined,'table-wrap');wrap.append(radioTable(['Time (local)','Callsign','Name','Location','Mode','Target','Src','Dur(s)','Loss'],rows.map(r=>[localCallTime(r),r.callsign||r.caller,r.name||'—',r.location||'—',`${r.mode||(r.identity_source==='DMR2YSF log'?'DMR2YSF':'DMR')} TS${r.slot}`,`TG ${r.target}`,r.source==='network'?'Net':'RF',r.active?'LIVE':r.seconds.toFixed(1),r.loss==null?'—':r.loss+'%'])));if(!rows.length)wrap.append(node('div','No recent calls.','empty'));$(target).replaceChildren(wrap);}
function renderCurrent(d){
 const elapsed=Math.max(0,(performance.now()-(d.receivedAt||performance.now()))/1000);
 const fresh=!d.stale&&!d.error&&elapsed<5;
 const keyed=[];
 const rows=[1,2].map(slot=>{
  const live=fresh?d.slots.find(s=>s.slot===slot)?.transmission:null;
  keyed.push(Boolean(live));
  const r=live||d.last_calls?.find(r=>r.slot===slot)||d.activity.find(r=>r.slot===slot);
  if(!r||(!live&&!callVisible(r,d.updated+elapsed)))return ['—','—','—',`DMR TS${slot}`,'—','—',fresh?'IDLE · Listening':'Status unavailable'];
  const ago=Math.max(0,Math.floor(d.updated+elapsed-(r.ended||r.started+r.seconds)));
  const duration=live?`● KEYED · ${(r.seconds+elapsed).toFixed(1)}s`:!fresh?'Status unavailable':`IDLE · Last ${r.seconds.toFixed(1)}s · ${callerAgo(ago)}`;
  return [r.callsign||r.caller,r.name||'—',r.location||'—',`${r.mode||(r.identity_source==='DMR2YSF log'?'DMR2YSF':'DMR')} TS${slot}`,`TG ${r.target}`,r.source==='network'?'Net':'RF',duration];
 });
 const table=radioTable(['Callsign','Name','Location','Mode','Target','Src','Status / Duration'],rows);
 table.querySelectorAll('tbody tr').forEach((row,i)=>{row.classList.toggle('keyed',keyed[i]);row.style.setProperty('--pulse-offset',`-${(performance.now()/1000)%1.2}s`);});
 $('current-callers').replaceChildren(table);
 fill('radio-note',fresh?`● Live monitor · ${new Date((d.updated+elapsed)*1000).toLocaleTimeString()} · 0.5s refresh`:'Live status unavailable; reconnecting…');
 $('radio-note').classList.toggle('bad',!fresh);
}
function showActivity(){if(!radioData&&!data)return;const activity=[...(radioData?.activity||data.activity||[])].sort((a,b)=>b.started-a.started).slice(0,15);const query=$('filter').value.toLowerCase();table('recent',activity);table('all-activity',activity.filter(r=>`${r.callsign||r.caller} ${r.target}`.toLowerCase().includes(query)));}

async function api(path,options={}){const res=await fetch('/api/'+path,{...options,headers:{'Content-Type':'application/json',...(csrf?{'X-CSRF-Token':csrf}:{}),...options.headers}});if(!res.ok){let err=await res.json().catch(()=>({}));throw new Error(typeof err.detail==='string'?err.detail:`Request failed (${res.status})`);}return res.json();}
function render(d){data=d;fill('site-title',d.site);fill('site-breadcrumb',d.site);fill('network-name',d.network||'MMOD');fill('site-description',d.description||'Radio dashboard');fill('station-identity',[d.callsign,d.location].filter(Boolean).join(' · ')||d.site);document.title='MMOD · '+d.site;const s=d.system, host=d.services.find(x=>x.name===(d.host_service||'mmdvmhost.service'));const online=host?.status==='active'&&!d.stale;fill('connection',d.stale?'● Data delayed':'● Live · 5s refresh');$('connection').classList.toggle('bad',d.stale);fill('radio-status',d.stale?'Status unavailable':online?'Repeater online':!host?.installed?'MMDVMHost not installed':'MMDVMHost '+(host?.status||'unknown'));fill('radio-detail',`${d.callsign} · ${d.location} · ${d.duplex?'Duplex repeater':'Simplex'} · ${d.modes.filter(m=>m.enabled).map(m=>m.name).join(', ')||'No modes enabled'}`);fill('call',d.callsign);fill('tx',d.tx);fill('rx',d.rx);fill('dmr-id',d.dmr_id);fill('color-code',d.color_code);fill('duplex',d.duplex?'Duplex':'Simplex');fill('cpu',s.cpu_percent===null?'Sampling':s.cpu_percent.toFixed(1)+'%');$('cpu-bar').style.width=Math.min(100,s.cpu_percent||0)+'%';fill('cpu-note',`${s.cores} cores · Load ${s.load.toFixed(2)}`);let mem=s.memory_used/s.memory_total*100;fill('memory',mem.toFixed(0)+'%');$('memory-bar').style.width=mem+'%';fill('memory-note',`${s.memory_used} / ${s.memory_total} MB`);fill('temperature',s.temperature===null?'N/A':s.temperature.toFixed(0)+'°C');fill('uptime',age(s.uptime));fill('updated','Updated '+new Date(d.updated*1000).toLocaleTimeString());$('notice').hidden=!d.stale;if(d.stale)fill('notice','The collector has not updated for more than 30 seconds. Displayed data may be out of date.');
$('services').replaceChildren(...d.services.filter(x=>x.installed).map(x=>{const row=node('div',undefined,'service'),name=node('div',names[x.name]||x.name);name.append(node('small',x.name));row.append(name,node('span',(x.status==='active'?'● Running':x.status),'status'+(x.status==='active'?'':' bad')));return row;}));$('mode-chips').replaceChildren(...d.modes.filter(m=>m.configured).map(m=>node('span',m.name,'chip'+(m.enabled?' on':''))));
details('hardware',{'Computer':s.hardware,'Operating system':s.os,'Architecture':s.architecture,'Processor':s.cpu,'Hostname':s.hostname,'Storage':`${(s.disk_free/1073741824).toFixed(2)} GiB free of ${(s.disk_total/1073741824).toFixed(2)} GiB`});details('modem',{'Configured device':d.modem.port,'USB serial devices':d.modem.serial.map(x=>x.name+' → '+x.target).join('\n'),'Firmware':d.modem.firmware});$('modes-table').replaceChildren(...d.modes.map(m=>{const row=node('div',undefined,'service');row.append(node('span',m.name),node('span',!m.configured?'Not configured':m.enabled?'Enabled':'Disabled','status'+(m.enabled?'':' bad')));return row;}));showActivity();}
async function refresh(){try{render(await api('status'));if(csrf&&view==='admin')await loadAdmin();}catch(e){fill('connection','● Connection unavailable');$('connection').classList.add('bad');$('notice').hidden=false;fill('notice',e.message+' · Retrying automatically.');}finally{setTimeout(refresh,5000);}}
function setAdmin(loggedIn){$('login').hidden=loggedIn;$('admin-content').hidden=!loggedIn;$('logout').hidden=!loggedIn;}
async function loadAdmin(){try{await maintenanceStatus();const [logs,backups]=await Promise.all([api('logs'),api('backups')]);fill('logs',logs.lines.join('\n'));$('backups').replaceChildren(...backups.items.map(b=>{const row=node('div',undefined,'backup-row'),info=node('div',new Date(b.created*1000).toLocaleString());info.append(node('small',`${(b.size/1024).toFixed(1)} KB · SHA-256 ${b.sha256}`));const a=node('a','Download archive ↓');a.href='/api/backups/'+encodeURIComponent(b.name);row.append(info,a);return row;}));if(backups.pending)fill('backup-message','Backup queued; waiting for the next collector cycle.');else if($('backup-message').textContent)fill('backup-message','Latest backup is ready.');}catch(e){if(/sign in|session/i.test(e.message)){csrf=null;setAdmin(false);}else throw e;}}
document.querySelectorAll('[data-view]').forEach(b=>b.addEventListener('click',()=>{view=b.dataset.view;document.querySelectorAll('.view').forEach(s=>s.hidden=s.id!==view);document.querySelectorAll('nav button').forEach(n=>n.classList.toggle('selected',n.dataset.view===view));if(view==='admin'&&csrf)loadAdmin().catch(e=>fill('backup-message',e.message));}));$('filter').addEventListener('input',showActivity);
$('login').addEventListener('submit',async e=>{e.preventDefault();fill('login-error','');try{const r=await api('login',{method:'POST',body:JSON.stringify({username:$('username').value,password:$('password').value})});csrf=r.csrf;$('password').value='';setAdmin(true);await loadAdmin();}catch(e){fill('login-error',e.message);}});
$('logout').addEventListener('click',async()=>{try{await api('logout',{method:'POST'});csrf=null;setAdmin(false);}catch(e){fill('backup-message',e.message);}});
$('backup').addEventListener('click',async()=>{try{const r=await api('backups',{method:'POST'});fill('backup-message',r.message);}catch(e){fill('backup-message',e.message);}});
api('session').then(r=>{csrf=r.csrf;setAdmin(true);}).catch(()=>setAdmin(false));refresh();

$('change-password').addEventListener('submit',async e=>{
 e.preventDefault(); const button=e.target.querySelector('button'); button.disabled=true;
 try { const r=await api('password',{method:'POST',body:JSON.stringify({current_password:$('current-password').value,new_password:$('new-password').value,confirm_password:$('confirm-password').value})});
 e.target.reset();csrf=null;setAdmin(false);fill('login-error',r.message);
 } catch(error){fill('password-message',error.message);}finally{button.disabled=false;}
});
async function maintenanceStatus(){
 const r=await api('control');
 document.querySelectorAll('[data-control]').forEach(b=>b.disabled=r.pending);
 fill('control-services',(data?.services||[]).filter(s=>s.installed).map(s=>s.name+' ('+s.status+')').join(' · '));
 if(r.pending)fill('control-message','Maintenance operation in progress…');
 else if(r.results)fill('control-message',r.results.length?r.results.map(s=>s.service+': '+s.message).join(' · '):'No installed radio services found.');
 else if(r.message)fill('control-message',r.message);
}
document.querySelectorAll('[data-control]').forEach(button=>button.addEventListener('click',async()=>{
 const action=button.dataset.control;
 if(action==='reboot') {if(prompt('Reboot the system and interrupt radio traffic? Type REBOOT to confirm.')!=='REBOOT')return;}
 else if(!confirm(action.toUpperCase()+' all listed radio services?'+(['stop','restart'].includes(action)?' This interrupts radio traffic.':'')))return;
 document.querySelectorAll('[data-control]').forEach(b=>b.disabled=true);
 try{const r=await api('control',{method:'POST',body:JSON.stringify({action,confirmation:action==='reboot'?'REBOOT':'CONFIRM'})});fill('control-message',r.message);}
 catch(error){fill('control-message',error.message);document.querySelectorAll('[data-control]').forEach(b=>b.disabled=false);}
}));

async function refreshRadio(){
 try{const d=await api('radio',{cache:'no-store',signal:AbortSignal.timeout(4000)});d.receivedAt=performance.now();radioData=d;renderCurrent(d);showActivity();}
 catch(error){if(radioData){radioData.stale=true;renderCurrent(radioData);}else fill('radio-note','Live status unavailable; reconnecting…');}
 finally{setTimeout(refreshRadio,500);}
}
setInterval(()=>{if(radioData){renderCurrent(radioData);showActivity();}},500);
refreshRadio();
