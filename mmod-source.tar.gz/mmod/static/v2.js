'use strict';
let controlModes=[],editingUser=false,controlPending=false,destinationLists={};
const dialog=$('login-dialog');
function showLogin(){if(!dialog.open)dialog.showModal();$('username').focus();}
$('admin-login-button').onclick=()=>window.v2Identity?document.querySelector('[data-view="admin"]').click():showLogin();
$('admin-open-login').onclick=showLogin;
$('login-close').onclick=()=>dialog.close();
$('header-logout').onclick=()=>$('logout').click();
async function authChanged(loggedIn){
 if(!loggedIn){$('admin-log-dialog').close();$('user-audit').replaceChildren();$('bm-key').value='';window.v2Identity=null;$('radio-controls').hidden=true;$('header-logout').hidden=true;$('admin-open-login').hidden=false;fill('admin-login-button','Admin Login');return;}
 try{const user=await api('session');window.v2Identity=user;csrf=user.csrf;dialog.close();$('radio-controls').hidden=false;$('header-logout').hidden=false;$('admin-open-login').hidden=true;fill('signed-in-user',user.username+' · '+user.role);fill('admin-login-button',user.username);$('admin-content').hidden=false;Array.from($('admin-content').children).forEach(el=>el.hidden=user.role!=='admin'&&el.id!=='change-password');
 await loadControls();await destinations();if(user.role==='admin'){await loadUsers();await loadBM();}
 }catch(e){csrf=null;setAdmin(false);}
}
window.v2AuthChanged=authChanged;
async function loadControls(){
 const r=await api('radio-control');controlPending=r.pending;controlModes=r.modes;
 if(!$('rc-mode').options.length){for(const m of r.modes){const o=new Option(m.name+(m.ready?'':' — Setup required'),m.id);$('rc-mode').add(o);}$('rc-mode').value=r.modes.find(m=>m.ready&&m.id==='dmr2ysf')?.id||r.modes.find(m=>m.ready&&m.id==='ysf')?.id||'dmr';}
 updateMode();
 const status=r.pending?'Operation pending…':r.result.results?r.result.results.map(x=>x.message).join(' · '):r.result.message||'';
 fill('rc-message',status);if($('linked-feedback'))fill('linked-feedback',status);
}
const families={dmr:['BrandMeister','TGIF','DMR+','FreeDMR','ADN','AmComm','QuadNet'],dmr2ysf:['FCS','YSF'],ysf:['FCS','YSF'],dstar:['D-Star REF','D-Star XRF','D-Star DCS','D-Star XLX'],p25:['P25'],nxdn:['NXDN'],m17:['M17'],pocsag:['POCSAG / DAPNET'],fm:['FM'],ysf2dmr:['BrandMeister'],dmr2nxdn:['NXDN'],dmr2p25:['P25']};
function updateMode(){const m=controlModes.find(x=>x.id===$('rc-mode').value);if(!m)return;fill('rc-note',m.note+(m.id==='pocsag'?' DAPNET entries are rubrics, not pager addresses.':m.id==='fm'?' FM uses frequency/channel settings, not talkgroups.':''));if(m.slot)$('rc-slot').value=String(m.slot);$('rc-slot').disabled=m.id==='ysf'||!!m.slot||!m.ready;$('rc-slot').parentElement.hidden=m.id==='ysf';
const available=families[m.id]||[];if(!available.includes($('rc-family').value)){$('rc-family').replaceChildren(...available.map(x=>new Option(x,x)));$('rc-destination').value='';destinations().catch(e=>{console.error(e);fill('rc-message','Directory unavailable: '+e.message);});}else if(Array.from($('rc-family').options).map(x=>x.value).join('|')!==available.join('|')){const selected=$('rc-family').value;$('rc-family').replaceChildren(...available.map(x=>new Option(x,x)));$('rc-family').value=selected;}
document.querySelector('[data-radio="link"]').textContent=m.id==='dmr'&&$('rc-family').value==='BrandMeister'?'Add static TG':'Link now';
$('rc-auto').disabled=m.id==='dmr'||!m.link||controlPending;document.querySelectorAll('[data-radio]').forEach(b=>{b.hidden=b.dataset.radio==='default'&&window.v2Identity?.role!=='admin';b.disabled=controlPending||!m.ready||(['link','unlink','default'].includes(b.dataset.radio)&&(!m.link||(m.id==='dmr'&&$('rc-family').value!=='BrandMeister')))||(b.dataset.radio==='default'&&!m.default)||(['enable','disable'].includes(b.dataset.radio)&&!m.enable);});}
$('rc-mode').onchange=()=>{updateMode();destinations().catch(e=>{console.error(e);fill('rc-message','Directory unavailable: '+e.message);});};
async function destinations(){if(!csrf)return;const network=$('rc-family').value,query=$('rc-search').value;const r=await api('destinations?network='+encodeURIComponent(network)+'&q='+encodeURIComponent(query));if(network!==$('rc-family').value||query!==$('rc-search').value)return;const options=r.entries.map(e=>new Option(e.id+' — '+e.name,e.id));$('rc-picker').replaceChildren(new Option(options.length?(r.total>200?'Choose a destination (first 200; type to filter)…':'Choose a destination…'):'No matching entries — manual entry available',''),...options);}
$('rc-search').oninput=()=>destinations().catch(e=>{console.error(e);fill('rc-message','Directory unavailable: '+e.message);});
$('rc-picker').onchange=()=>{if($('rc-picker').value)$('rc-destination').value=$('rc-picker').value;};
$('rc-family').onchange=()=>{updateMode();$('rc-destination').value='';$('rc-search').value='';destinations().catch(e=>{console.error(e);fill('rc-message','Directory unavailable: '+e.message);});};
document.querySelectorAll('[data-radio]').forEach(b=>b.onclick=async()=>{
 const operation=b.dataset.radio;const mode=controlModes.find(x=>x.id===$('rc-mode').value);
 const warning=mode.id==='dmr'&&['link','unlink'].includes(operation)?`${operation==='link'?'Add':'Remove'} static TG ${$('rc-destination').value} on TS${$('rc-slot').value}? This changes the persistent BrandMeister subscription.`:operation==='default'?'Save this destination for startup after reboot?':operation==='link'||operation==='unlink'?'This briefly restarts the shared YSF gateway and interrupts its traffic. Continue?':`${operation==='disable'?'Disable':'Enable'} ${mode.name}? This affects radio traffic.`;
 if(!confirm(warning))return;
 try{controlPending=true;updateMode();const r=await api('radio-control',{method:'POST',body:JSON.stringify({mode:mode.id,operation,slot:Number($('rc-slot').value),family:$('rc-family').value,destination:$('rc-destination').value.trim().toUpperCase(),auto_disconnect:$('rc-auto').checked})});fill('rc-message',r.message);}catch(e){fill('rc-message',e.message);}finally{controlPending=false;updateMode();}
});
async function loadUsers(){const r=await api('users');$('user-list').replaceChildren(...r.users.map(u=>{const row=node('div');row.append(node('span',`${u.username} · ${u.role} · ${u.enabled?'Enabled':'Disabled'}`));const b=node('button','Edit / reset password');b.onclick=()=>{editingUser=true;$('user-name').value=u.username;$('user-name').readOnly=true;$('user-role').value=u.role;$('user-enabled').checked=!!u.enabled;$('user-password').value='';fill('user-save','Save user');};row.append(b);return row;}));}
$('user-new').onclick=()=>{editingUser=false;$('user-form').reset();$('user-name').readOnly=false;fill('user-save','Add user');};
$('user-form').onsubmit=async e=>{e.preventDefault();try{const r=await api('users',{method:'POST',body:JSON.stringify({username:$('user-name').value,password:$('user-password').value,role:$('user-role').value,enabled:$('user-enabled').checked,create:!editingUser})});$('user-password').value='';fill('user-message',r.message);await loadUsers();}catch(e){fill('user-message',e.message);}};
setInterval(()=>{if(csrf)loadControls().catch(e=>{if(/sign in|session/i.test(e.message)){csrf=null;setAdmin(false);}else {fill('rc-message',e.message);if($('linked-feedback'))fill('linked-feedback','Connection lost or status unavailable: '+e.message);}});},3000);
destinations().catch(e=>{console.error(e);fill('rc-message','Directory unavailable: '+e.message);});
api('session').then(()=>authChanged(true)).catch(()=>authChanged(false));

async function loadBM(){const s=await api('brandmeister');fill('bm-status','Device ID: '+(s.device||'Not detected')+' · '+(s.configured?'Key saved':'No key saved'));$('bm-remove').disabled=!s.configured;}
$('bm-form').onsubmit=async e=>{e.preventDefault();const b=e.submitter;b.disabled=true;try{const result=await api('brandmeister',{method:'POST',body:JSON.stringify({key:$('bm-key').value})});fill('bm-message',result.message);await loadBM();await loadControls();}catch(e){fill('bm-message',e.message);}finally{$('bm-key').value='';b.disabled=false;}};
$('bm-remove').onclick=async()=>{if(!confirm('Remove the saved BrandMeister key? Existing links remain.'))return;try{const r=await api('brandmeister',{method:'POST',body:JSON.stringify({remove:true})});fill('bm-message',r.message);await loadBM();await loadControls();}catch(e){fill('bm-message',e.message);}};

$('admin-log-open').onclick=async()=>{const popup=$('admin-log-dialog');if(!popup.open)popup.showModal();$('user-audit').replaceChildren(node('p','Loading saved log…'));try{const a=await api('audit');$('user-audit').replaceChildren(...(a.entries.length?a.entries.map(e=>node('div',[new Date(e.time*1000).toLocaleString(),e.username,e.action,e.detail].filter(Boolean).join(' · '))):[node('p','No administration activity yet.')]));}catch(e){$('user-audit').replaceChildren(node('p',e.message));}};
$('admin-log-close').onclick=()=>$('admin-log-dialog').close();
