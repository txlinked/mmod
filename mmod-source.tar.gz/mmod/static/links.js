'use strict';
let lastLinks='';
async function refreshLinks(){
 try{
  const r=await api('links');const signed=!!(csrf&&window.v2Identity);const signature=JSON.stringify([r.slots,signed]);if(signature===lastLinks)return;lastLinks=signature;
  $('linked-slots').replaceChildren(...r.slots.map(slot=>{
   const box=node('section');box.append(node('h4','TS'+slot.slot));
   for(const link of slot.links){const row=node('div',undefined,'linked-row');const label=(link.family==='BrandMeister'?'TG ':'')+(link.destination||link.family)+(link.name==='TG '+link.destination?'':' · '+link.name)+(link.kind&&link.kind!=='gateway'?' ('+link.kind+')':'');
    const choice=node(signed&&link.destination?'button':'div',label,'linked-choice');
    if(signed&&link.destination){choice.title='Load into Radio Control';choice.onclick=async()=>{await loadControls();document.querySelector('[data-view="overview"]').click();$('rc-mode').value=link.mode;updateMode();$('rc-slot').value=String(slot.slot);$('rc-family').value=link.family;$('rc-search').value='';await destinations();$('rc-destination').value=link.destination;$('radio-controls').scrollIntoView({behavior:'smooth',block:'nearest'});};}
    row.append(choice);
    if(signed&&link.unlink){const unlink=node('button','Unlink','linked-unlink');unlink.onclick=async()=>{if(!confirm('Unlink '+(link.destination||link.name)+(link.family==='BrandMeister'?'? This removes the static BrandMeister subscription.':'? This restarts the shared YSF gateway.')))return;unlink.disabled=true;try{const result=await api('radio-control',{method:'POST',body:JSON.stringify({mode:link.mode,slot:slot.slot,operation:'unlink',family:link.family,destination:link.destination,subscription_kind:link.kind||'static'})});fill('linked-feedback',result.message);}catch(e){fill('linked-feedback',e.message);}finally{unlink.disabled=false;}};row.append(unlink);}
    box.append(row);
   }
   box.append(node('p',slot.note,'linked-note'));return box;
  }));
 }catch(e){lastLinks='';$('linked-slots').replaceChildren(...[1,2].map(n=>{const s=node('section');s.append(node('h4','TS'+n),node('p','Link status unavailable.','linked-note'));return s;}));}
}
$('linked-sidebar').append(node('p','','linked-note'));$('linked-sidebar').lastChild.id='linked-feedback';
refreshLinks();setInterval(refreshLinks,3000);

// Keep the station heading and status banner above both columns.
const side=$('linked-sidebar'),layout=document.querySelector('.dashboard-layout'),overview=$('overview'),controls=$('radio-controls');
function alignLinks(){const mobile=matchMedia('(max-width:1000px)').matches;const target=controls.hidden?overview.querySelector('.live-radio'):controls;if(mobile){if(side.parentElement!==overview)overview.insertBefore(side,controls);side.style.marginTop='';}else{if(side.parentElement!==layout)layout.insertBefore(side,layout.firstChild);const offset=overview.hidden?18:Math.max(18,target.getBoundingClientRect().top-layout.getBoundingClientRect().top);side.style.marginTop=offset+'px';}}
new ResizeObserver(alignLinks).observe(document.querySelector('main'));
new MutationObserver(alignLinks).observe(controls,{attributes:true,attributeFilter:['hidden']});
new MutationObserver(alignLinks).observe(overview,{attributes:true,attributeFilter:['hidden']});
window.addEventListener('resize',alignLinks);alignLinks();
