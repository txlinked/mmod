'use strict';
(()=>{
 const panel=node('article',undefined,'panel');panel.hidden=true;
 panel.append(node('h3','Dynamic talkgroup timer'));
 panel.append(node('p','Default: 15 minutes without local RF key-up. Static talkgroups and saved gateway defaults stay linked. This timer does not apply to AllStar.','caption'));
 const form=document.createElement('form'),label=node('label','Inactivity timeout (minutes) '),input=document.createElement('input');
 input.type='number';input.min='1';input.max='1440';input.step='1';input.required=true;input.value='15';label.append(input);form.append(label);
 const save=node('button','Save timer','primary');save.type='submit';form.append(save);
 const reset=node('button','Use default (15 min)');reset.type='button';reset.onclick=()=>{input.value='15';};form.append(reset);
 const message=node('p');message.setAttribute('role','status');form.append(message);panel.append(form);
 ($('configuration')||$('admin-content')).append(panel);
 let loaded=false;
 setInterval(async()=>{const admin=window.v2Identity?.role==='admin';panel.hidden=!admin;if(!admin){loaded=false;input.value='15';return;}if(!loaded){loaded=true;try{const d=await api('dynamic-timer');input.value=d.minutes;}catch(e){message.textContent=e.message;loaded=false;}}},1000);
 form.onsubmit=async e=>{e.preventDefault();save.disabled=true;try{const d=await api('dynamic-timer',{method:'POST',body:JSON.stringify({minutes:Number(input.value)})});message.textContent='Saved: '+d.minutes+' minutes. Applies to current and future temporary radio links; AllStar is unaffected.';}catch(e){message.textContent=e.message;}finally{save.disabled=false;}};
})();
