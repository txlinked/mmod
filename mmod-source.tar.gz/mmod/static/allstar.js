'use strict';
let asNodes=[],asSettings=[],asBusy=false,asLoading=false,asAdminLoaded=false;
function asAccess(){const admin=window.v2Identity?.role==='admin';if(admin&&!asAdminLoaded){asAdminLoaded=true;asSetup();}if(!admin){asAdminLoaded=false;$('as-secret').value='';}const signed=!!(csrf&&window.v2Identity);$('as-controls').hidden=!signed;$('as-login-note').hidden=signed;return signed;}
async function asList(){const d=await api('allstar');asNodes=d.nodes;const selected=$('as-node').value;$('as-node').replaceChildren(...asNodes.map(n=>new Option(n.name+' · '+n.node,n.node)));if(asNodes.some(n=>n.node===selected))$('as-node').value=selected;await asRefresh();}
function asReceived(row,now){if(row.keyed===true)return 'Now';if(!row.last_keyed)return 'Not observed';const seconds=Math.max(0,Math.floor(now-row.last_keyed));return String(Math.floor(seconds/3600)).padStart(3,'0')+':'+String(Math.floor(seconds/60)%60).padStart(2,'0')+':'+String(seconds%60).padStart(2,'0');}
async function asRefresh(){
 if(asLoading)return;asAccess();asLoading=true;
 try{
  const selected=asNodes.find(n=>n.node===$('as-node').value);
  $('as-favorites').replaceChildren(new Option('Choose a favorite',''),...(selected?.favorites||[]).map(x=>new Option(x,x)));
  const container=$('as-connected');
  if(container.children.length!==asNodes.length)container.replaceChildren(...asNodes.map(n=>node('article',n.name+' · Loading…','as-node-card')));
  await Promise.all(asNodes.map(async (n,index)=>{
   const card=node('article',undefined,'as-node-card');card.append(node('h3',n.name+' · '+n.node));
   try{
    const d=await api('allstar/'+encodeURIComponent(n.node));
    card.append(node('p',d.ok?(d.tx?'● Transmitting':'● Idle')+' · Updated '+new Date(d.updated*1000).toLocaleTimeString():d.error));
    if(d.ok){
     card.classList.toggle('as-transmitting',d.tx===true);
     const metrics=node('div',undefined,'as-node-metrics');for(const [k,v] of [['System',d.system],['Input',d.signal],['Uptime',d.uptime],['Keyups',d.keyups],['TX time',d.tx_time]])metrics.append(node('span',k+': '+v));card.append(metrics);
     const table=node('table',undefined,'as-table');const head=node('tr');for(const title of ['Node','Node information','Last keyed','Link','Direction','Connected for','Mode',''])head.append(node('th',title));table.append(head);
     const connected=d.connections?.length?d.connections.map(r=>r.node):d.connected;for(const id of connected){const detail=(d.connections||[]).find(r=>r.node===id)||{};const row=node('tr');row.classList.toggle('as-keyed',detail.keyed===true);for(const value of [id,detail.name||asNodes.find(r=>r.node===id)?.name||'Name unavailable',asReceived(detail,d.updated),detail.keyed===true?'● KEYED':detail.state||'Connected',detail.direction||'—',detail.duration||'—',detail.mode||'—'])row.append(node('td',value));const actions=node('td');if(asAccess()){const b=node('button','Unlink');b.disabled=asBusy;b.onclick=()=>asAction('unlink',id,n.node);actions.append(b);}row.append(actions);table.append(row);}
     const wrap=node('div',undefined,'table-wrap');wrap.append(table);card.append(wrap);if(!connected.length)card.append(node('p','No connected nodes.'));
    }
    if(asAccess()){const b=node('button','Control '+n.name);b.onclick=()=>{$('as-node').value=n.node;$('as-controls').scrollIntoView({block:'nearest'});$('as-target').focus();};card.append(b);}
   }catch(e){card.append(node('p','Status unavailable: '+e.message));}
   const previous=container.children[index];if(previous)previous.replaceWith(card);else container.append(card);
   return card;
  }));
  $('as-metrics').replaceChildren();fill('as-status',asNodes.length?'Live status · '+asNodes.length+' configured nodes · Last keyed records observed activity, including while this page is closed':'Setup required. Add nodes in Administration.');
 }finally{asLoading=false;}
}
async function asAction(operation,target,sourceOverride){if(asBusy)return;const source=sourceOverride||$('as-node').value;if(!confirm(operation+' node '+source+' '+(operation==='unlink'?'from':'to')+' '+target+'?'))return;asBusy=true;document.querySelectorAll('[data-as]').forEach(b=>b.disabled=true);fill('as-message','Sending command…');try{const r=await api('allstar/action',{method:'POST',body:JSON.stringify({node:source,operation,target})});fill('as-message',r.message);await asRefresh();}catch(e){fill('as-message',e.message);}finally{asBusy=false;document.querySelectorAll('[data-as]').forEach(b=>b.disabled=false);}}
$('as-node').onchange=asRefresh;$('as-refresh').onclick=asList;$('as-favorites').onchange=()=>{$('as-target').value=$('as-favorites').value;};document.querySelectorAll('[data-as]').forEach(b=>b.onclick=()=>asAction(b.dataset.as,$('as-target').value.trim()));
async function asSetup(){try{const d=await api('allstar/setup');asSettings=d.nodes;$('as-edit').replaceChildren(new Option('New node',''),...d.nodes.map(n=>new Option(n.name+' · '+n.node,n.node)));}catch(e){fill('as-setup-message',e.message);}}
$('as-load').onclick=asSetup;$('as-new').onclick=()=>{$('as-edit').value='';$('as-edit').onchange();$('as-id').focus();};$('as-edit').onchange=()=>{const n=asSettings.find(n=>n.node===$('as-edit').value);$('as-form').reset();$('as-id').readOnly=!!n;$('as-remove').disabled=!n;$('as-secret').required=!n;$('as-secret').placeholder=n?'Saved password hidden — blank keeps it':'Enter AMI password';if(n){for(const [id,key] of [['as-id','node'],['as-name','name'],['as-host','host'],['as-port','port'],['as-user','username']])$(id).value=n[key];$('as-tls').checked=n.tls;$('as-favs').value=(n.favorites||[]).join(', ');}};
async function asSave(remove){if(remove&&!confirm('Remove this saved connection? Existing radio links will not be disconnected.'))return;try{const body={node:$('as-id').value.trim(),name:$('as-name').value,host:$('as-host').value.trim(),port:Number($('as-port').value),username:$('as-user').value,secret:$('as-secret').value,tls:$('as-tls').checked,favorites:$('as-favs').value,remove};const d=await api('allstar/setup',{method:'POST',body:JSON.stringify(body)});$('as-secret').value='';fill('as-setup-message',d.message);await asSetup();$('as-edit').value='';$('as-edit').onchange();await asList();}catch(e){fill('as-setup-message',e.message);}}
$('as-form').onsubmit=e=>{e.preventDefault();asSave(false);};$('as-remove').onclick=()=>asSave(true);
asList().catch(e=>fill('as-status',e.message));setInterval(()=>{asAccess();if(!$('allstar').hidden)asRefresh();},1000);
