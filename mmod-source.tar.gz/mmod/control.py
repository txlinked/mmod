"""Root-only worker for a fixed set of dashboard maintenance operations."""
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import time

STATE = Path('/var/lib/mmod/state')
LIVE = Path('/run/mmod')
CONFIG = Path('/etc/mmod/config.json')
ACTIONS = {'start', 'stop', 'restart', 'reload', 'reboot', 'radio'}

def allowed_services(config):
    return [n for n in dict.fromkeys(config.get('services', []))
            if re.fullmatch(r'[A-Za-z0-9_][A-Za-z0-9_.@-]*\.service', n)
            and n not in {'mmod.service','mmod-control.service','mmod-collector.service'}]

def run(args):
    return subprocess.run(['/usr/bin/systemctl', *args], capture_output=True, text=True, timeout=20)

def execute(job, config):
    action=job.get('action')
    if action not in ACTIONS or job.get('confirmation') != ('REBOOT' if action=='reboot' else 'CONFIRM'):
        raise ValueError('Invalid operation or confirmation')
    if abs(time.time()-float(job.get('created',0)))>120:
        raise ValueError('Expired request')
    if action=='radio':
        from v2_radio import execute as radio_execute
        return [{'service':job.get('mode'),'ok':True,'message':radio_execute(job)}]
    if action=='reboot':
        result=run(['--no-block','reboot'])
        return [{'service':'Dell','ok':result.returncode==0,'message':'Reboot requested' if result.returncode==0 else result.stderr.strip()[:300]}]
    results=[]
    for name in allowed_services(config):
        installed=run(['show',name,'--property=LoadState','--value'])
        if installed.returncode or installed.stdout.strip()!='loaded':
            continue
        if action=='reload':
            capable=run(['show',name,'--property=CanReload','--value'])
            if capable.stdout.strip()!='yes':
                results.append({'service':name,'ok':False,'message':'Reload unsupported; use Restart if needed'})
                continue
        try:
            result=run([action,name])
            results.append({'service':name,'ok':result.returncode==0,'message':action+' completed' if result.returncode==0 else result.stderr.strip()[:300]})
        except subprocess.TimeoutExpired:
            results.append({'service':name,'ok':False,'message':'Timed out; check current service status'})
    return results

def report(data):
    LIVE.mkdir(mode=0o750,exist_ok=True)
    temp=LIVE/'control-result.new'
    temp.write_text(json.dumps(data))
    temp.chmod(0o640)
    temp.replace(LIVE/'control-result.json')

def main():
    path=STATE/'control-request.json'
    try:
        fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
    except FileNotFoundError:
        return
    try:
        info=os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_size>4096:
            raise ValueError('Invalid request file')
        with os.fdopen(fd) as stream:
            fd=None
            job=json.load(stream)
        report({'pending':True,'action':job.get('action'),'message':'Operation in progress'})
        config=json.loads(CONFIG.read_text())
        # Consume reboot before requesting shutdown so it cannot replay at startup.
        if job.get('action')=='reboot':path.unlink(missing_ok=True)
        results=execute(job,config)
        report({'pending':False,'action':job.get('action'),'results':results,'updated':time.time()})
        print('MMOD maintenance:',job.get('username','admin'),job.get('action'),json.dumps(results),flush=True)
    except Exception as error:
        report({'pending':False,'message':str(error)[:300],'updated':time.time()})
    finally:
        if fd is not None:os.close(fd)
        path.unlink(missing_ok=True)

if __name__=='__main__':main()
