"""Waco pilot: local/remote AMI, fixed commands, authenticated configuration."""
import json, os, re, socket, ssl, threading, time
from pathlib import Path
from fastapi import HTTPException, Request
from pydantic import BaseModel, Field
import accounts

LOCK=threading.RLock()
CACHE={}
NODE_LOCKS={}
LAST_KEYED={}

DIRECTORY_STAMP=None
DIRECTORY_NAMES={}
DIRECTORY_LOCK=threading.Lock()
def node_names(state):
    global DIRECTORY_STAMP,DIRECTORY_NAMES
    path=state/'allstar-directory.txt'
    try:
        stamp=path.stat().st_mtime_ns
        with DIRECTORY_LOCK:
            if stamp!=DIRECTORY_STAMP:
                names={}
                for line in path.read_text(encoding='utf-8',errors='replace').splitlines():
                    fields=line.split('|')
                    if len(fields)>=4 and fields[0].isdigit():names.setdefault(fields[0],' · '.join(x.strip() for x in fields[1:4] if x.strip()))
                DIRECTORY_NAMES=names;DIRECTORY_STAMP=stamp
            return DIRECTORY_NAMES
    except OSError:return {}

def link_keying(text):
    active=re.search(r'RPT_ALINKS=([^\r\n]+)',text)
    return {ident:state=='K' for ident,mode,state in re.findall(r'(?:^|,)(\d+)([A-Z])([KU])(?=,|$)',active[1].strip() if active else '')}

def number(value):
    if not re.fullmatch(r'[1-9][0-9]{2,8}',str(value)):raise ValueError('Use a numeric AllStar node ID')
    return str(value)

def command(node,operation,target=''):
    node=number(node)
    if operation=='status':return 'rpt stats '+node
    if operation not in {'link','monitor','unlink'}:raise ValueError('Unsupported action')
    target=number(target)
    if target==node:raise ValueError('Cannot link a node to itself')
    return f"rpt cmd {node} ilink { {'link':3,'monitor':2,'unlink':1}[operation]} {target}"

def ami(config,cmd):
    for key in ('username','secret'):
        if any(c in config.get(key,'') for c in '\r\n'):raise ValueError('Invalid AMI credentials')
    with socket.create_connection((config['host'],config['port']),timeout=5) as raw:
        connection=ssl.create_default_context().wrap_socket(raw,server_hostname=config['host']) if config.get('tls') else raw
        connection.settimeout(5)
        stream=connection.makefile('rb')
        def read(command_response=False):
            lines=[];size=0;deadline=time.monotonic()+8
            while time.monotonic()<deadline:
                line=stream.readline(16385)
                if not line:raise ValueError('AMI connection closed')
                size+=len(line)
                if size>131072:raise ValueError('AMI response too large')
                text=line.decode(errors='replace').rstrip('\r\n');lines.append(text)
                if not text and any(x.startswith('Response:') for x in lines):
                    if not command_response or any('END COMMAND' in x for x in lines) or any(x=='Response: Error' for x in lines) or not any(x=='Response: Follows' for x in lines):return lines
            raise ValueError('AMI response timed out')
        def send(fields):connection.sendall(('\r\n'.join(k+': '+str(v) for k,v in fields.items())+'\r\n\r\n').encode())
        try:
            send({'Action':'Login','Username':config['username'],'Secret':config['secret'],'Events':'off'})
            if 'Response: Success' not in read():raise ValueError('AMI login rejected')
            outputs=[]
            for item in (cmd if isinstance(cmd,list) else [cmd]):
                send({'Action':'Command','Command':item})
                lines=read(True)
                if 'Response: Error' in lines:raise ValueError('AMI command rejected; check command permission')
                output='\n'.join(x.removeprefix('Output: ') for x in lines if not x.startswith(('Response:','Privilege:','ActionID:')) and 'END COMMAND' not in x).strip()
                if any(x in output.lower() for x in ('no such command','unable to find','unknown node','node not found')):raise ValueError('AllStar command or node unavailable')
                outputs.append(output)
            return outputs if isinstance(cmd,list) else outputs[0]
        finally:
            stream.close()
            if connection is not raw:connection.close()

def parse_status(text):
    fields={}
    for line in text.splitlines():
        if ':' in line:
            k,v=line.split(':',1);fields[k.strip().rstrip('.').strip()]=v.strip()
    if not any('Nodes currently connected' in k for k in fields):raise ValueError('Unrecognized node status; check node number and app_rpt')
    linked=next(v for k,v in fields.items() if 'Nodes currently connected' in k)
    return {'connected':re.findall(r'\b[1-9][0-9]{2,8}\b',linked),'signal':fields.get('Signal on input','Unknown'),'system':fields.get('System','Unknown'),'uptime':fields.get('Uptime','Unknown'),'keyups':fields.get('Keyups today','Unknown'),'tx_time':fields.get('TX time today','Unknown')}

class NodeSetup(BaseModel):
    node:str=Field(max_length=9)
    name:str=Field(min_length=1,max_length=80)
    host:str=Field(min_length=1,max_length=253)
    port:int=Field(default=5038,ge=1,le=65535)
    tls:bool=False
    username:str=Field(min_length=1,max_length=80)
    secret:str=Field(default='',max_length=256)
    favorites:str=Field(default='',max_length=500)
    remove:bool=False

class Action(BaseModel):
    node:str
    operation:str
    target:str=Field(max_length=9)

def install(app,state):
    path=state/'allstar-nodes.json'
    def load():
        try:return json.loads(path.read_text())
        except FileNotFoundError:return {}
    def public(n):return {k:v for k,v in n.items() if k not in ('secret',)}
    def audit(user,action,detail):
        with accounts.connect(state) as con:accounts.record(con,user['username'],action,detail)
    @app.get('/api/allstar/setup')
    def setup(request:Request):
        accounts.require(state,request,admin=True)
        return {'nodes':[dict(public(n),configured=bool(n.get('secret'))) for n in load().values()]}
    @app.post('/api/allstar/setup')
    def save(body:NodeSetup,request:Request):
        user=accounts.require(state,request,write=True,admin=True)
        try:
            node=number(body.node)
            if not re.fullmatch(r'[A-Za-z0-9.:-]+',body.host):raise ValueError('Enter a hostname or IP address without a URL')
            if any(c in body.username+body.secret for c in '\r\n'):raise ValueError('Credentials cannot contain line breaks')
            favorites=[number(n.strip()) for n in body.favorites.split(',') if n.strip()]
            with LOCK:
                data=load()
                if body.remove:data.pop(node,None)
                else:
                    if node not in data and len(data)>=16:raise ValueError('Maximum 16 controlled nodes')
                    secret=body.secret or data.get(node,{}).get('secret','')
                    if not secret:raise ValueError('Enter the AMI password')
                    data[node]=dict(node=node,name=body.name,host=body.host,port=body.port,tls=body.tls,username=body.username,secret=secret,favorites=favorites)
                temp=path.with_suffix('.new');fd=os.open(temp,os.O_WRONLY|os.O_CREAT|os.O_TRUNC,0o600)
                with os.fdopen(fd,'w') as f:json.dump(data,f)
                temp.replace(path);CACHE.pop(node,None)
            audit(user,'allstar setup',node+(' removed' if body.remove else ' saved'))
            return {'message':'Removed node' if body.remove else 'Saved. Use Refresh to test status.'}
        except ValueError as e:raise HTTPException(400,str(e))
    @app.get('/api/allstar')
    def nodes():return {'nodes':[{'node':n['node'],'name':n['name'],'favorites':n.get('favorites',[])} for n in load().values()]}
    @app.get('/api/allstar/{node}')
    def status(node:str):
        config=load().get(node)
        if not config:raise HTTPException(404,'Node not configured')
        with LOCK:node_lock=NODE_LOCKS.setdefault(node,threading.RLock())
        with node_lock:
            cached=CACHE.get(node)
            if cached and time.time()-cached['updated']<0.5:return cached
            try:
                stats,details,xnode=ami(config,[command(node,'status'),'rpt lstats '+number(node),'rpt xnode '+number(node)])
                result=dict(parse_status(stats),ok=True)
                result['connections']=[]
                try:
                    seen=set()
                    for line in details.splitlines():
                        parts=line.split()
                        if len(parts)>=6 and parts[0].isdigit() and parts[3] in ('IN','OUT') and parts[0] not in seen:
                            seen.add(parts[0]);result['connections'].append(dict(node=parts[0],direction=parts[3],duration=parts[4],state=' '.join(parts[5:])))
                    active=re.search(r'RPT_ALINKS=([^\r\n]+)',xnode)
                    modes={m[0]:{'T':'Transceive','R':'Monitor','L':'Local monitor'}.get(m[1],'Unknown') for m in re.findall(r'(\d+)([TRL])[A-Z]*',(active[1] if active else ''))}
                    keying=link_keying(xnode)
                    names=node_names(state)
                    for row in result['connections']:
                        row['name']=names.get(row['node'],'')
                        row['mode']=modes.get(row['node'],'Unknown')
                        row['keyed']=keying.get(row['node'])
                        key=(node,row['node'])
                        if row['keyed']:LAST_KEYED[key]=time.time()
                        row['last_keyed']=LAST_KEYED.get(key,0)
                    result['connections'].sort(key=lambda row:(not bool(row['keyed']),-row['last_keyed']))
                    tx=re.search(r'RPT_TXKEYED=(\d)',xnode);result['tx']=bool(tx and tx[1]=='1')
                except Exception:result['details_unavailable']=True
            except Exception:result={'ok':False,'error':'Node unavailable. Check AMI address, credentials, command permission and connectivity.'}
            result.update(updated=time.time(),node=node);CACHE[node]=result;return result
    @app.post('/api/allstar/action')
    def action(body:Action,request:Request):
        user=accounts.require(state,request,write=True)
        config=load().get(body.node)
        if not config:raise HTTPException(404,'Node not configured')
        try:
            cmd=command(body.node,body.operation,body.target)
            if body.operation=='status':raise ValueError('Use the status endpoint')
        except ValueError as e:raise HTTPException(400,str(e))
        try:ami(config,cmd)
        except Exception:
            audit(user,'allstar failed',body.node+' '+body.operation+' '+body.target)
            raise HTTPException(502,'Command was not confirmed. Refresh status before retrying.')
        with LOCK:CACHE.pop(body.node,None)
        audit(user,'allstar '+body.operation,body.node+' → '+body.target)
        return {'message':'Command accepted by Asterisk. Refreshing node status to confirm the connection.'}
