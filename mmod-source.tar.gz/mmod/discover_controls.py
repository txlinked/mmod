"""Detect local gateway paths without importing station settings from another host."""
import configparser,json,re,shlex,subprocess
from pathlib import Path

def ini(path):
    c=configparser.ConfigParser(strict=False,interpolation=None,inline_comment_prefixes=('#',';'))
    if path:c.read(path)
    return c

def service(name,binary):
    try:
        raw=subprocess.check_output(['systemctl','show',name,'-p','ExecStart','--value'],text=True,timeout=5)
        m=re.search(r'argv\[\]=(.*?) ;',raw)
        if not m:return {}
        args=shlex.split(m[1]);exe=next((a for a in args if Path(a).name==binary and a.startswith('/')),None)
        if not exe:return {}
        config=next((a for a in args if a.startswith('/') and (a.endswith('.ini') or a in ['/etc/ysfgateway','/etc/dmrgateway'])),None)
        # Runtime overrides are temporary; discover the original service config instead.
        if config and config.startswith('/run/'):
            for candidate in [str(Path(exe).parent/(binary+'.ini')),'/etc/'+binary.lower()]:
                if Path(candidate).is_file():config=candidate;break
        if not config or not Path(config).is_file():return {}
        if not all(re.fullmatch(r'/[A-Za-z0-9_./+-]+',a) for a in (exe,config)):return {}
        return {'service':name,'binary':exe,'ini':config}
    except (OSError,subprocess.SubprocessError,ValueError):return {}

def discover(config):
    result={};ysf=service('ysfgateway.service','YSFGateway');dmr=service('dmrgateway.service','DMRGateway')
    if ysf:result['ysf']=ysf
    if dmr:result['dmr']=dmr
    modem=ini(config.get('mmdvm_ini'))
    result['duplex']=modem.get('General','Duplex',fallback='0')=='1'
    fallback=modem.get('DMR','Id',fallback=modem.get('General','Id',fallback=''))
    c=ini(dmr.get('ini'))
    for section in c.sections():
        m=re.fullmatch(r'DMR Network ([1-5])',section)
        if not m or c.get(section,'Enabled',fallback='0')!='1':continue
        name=c.get(section,'Name',fallback='').lower()
        if name=='bm' or 'brandmeister' in name:
            result['bm_id']=c.get(section,'Id',fallback=fallback);result['bm_net']='net'+m[1]
        if 'dmr2ysf' in name:
            result['ysf_net']='net'+m[1]
            rule=c.get(section,'TGRewrite0',fallback='').split(',')
            if len(rule)==5 and rule[0] in ('1','2'):result['ysf_slot']=int(rule[0])
    if not dmr:
        host=modem.get('DMR Network','Address',fallback=modem.get('DMR Network','RemoteAddress',fallback=''))
        if 'brandmeister' in host.lower():result['bm_id']=fallback
    if not re.fullmatch(r'\d{6,9}',result.get('bm_id','')):result.pop('bm_id',None)
    result['ysf_route']='unverified'
    if ysf:
        gateway=ini(ysf['ini'])
        def matches(peer, section, local, remote):
            return (gateway.get('General','RptPort',fallback='')==peer.get(section,local,fallback='missing')
                    and gateway.get('General','LocalPort',fallback='')==peer.get(section,remote,fallback='missing')
                    and gateway.get('General','RptAddress',fallback='')==peer.get(section,'LocalAddress',fallback='127.0.0.1')
                    and gateway.get('General','LocalAddress',fallback='')==peer.get(section,'GatewayAddress',fallback='missing'))
        native=(modem.get('System Fusion','Enable',fallback='0')=='1' and modem.get('System Fusion Network','Enable',fallback='0')=='1' and matches(modem,'System Fusion Network','LocalPort','GatewayPort'))
        bridge=service('dmr2ysf.service','DMR2YSF')
        cross=bool(bridge and result.get('ysf_net') and matches(ini(bridge.get('ini')),'YSF Network','LocalPort','GatewayPort'))
        if native and not cross:result['ysf_route']='native'
        elif cross and not native:result['ysf_route']='crossmode'
    return result

def crossmode_sources(data):
    if data.get('ysf_route')!='crossmode':return []
    bridge=service('dmr2ysf.service','DMR2YSF')
    if not bridge:return []
    settings=ini(bridge['ini'])
    if settings.get('Log','FileLevel',fallback='0')=='0':return []
    folder=Path(settings.get('Log','FilePath',fallback='.'))
    if not folder.is_absolute():
        working=subprocess.check_output(['systemctl','show','dmr2ysf.service','-p','WorkingDirectory','--value'],text=True,timeout=5).strip()
        folder=Path(working or Path(bridge['binary']).parent)/folder
    gateway=ini(data['dmr']['ini']);sources=[]
    section='DMR Network '+data['ysf_net'].removeprefix('net')
    for key,value in gateway.items(section):
        if not key.lower().startswith('tgrewrite'):continue
        try:slot,start,remote_slot,remote_start,count=map(int,value.split(','))
        except ValueError:continue
        if slot not in (1,2) or count<1:continue
        sources.append(dict(slot=slot,log_directory=str(folder.resolve()),target_offset=start-remote_start,
                            routed_targets=[str(start)] if count==1 else [],target_range=[start,start+count-1],
                            log_root=settings.get('Log','FileRoot',fallback='DMR2YSF')))
    return sources

def main():
    config_path=Path('/etc/mmod/config.json')
    config=json.loads(config_path.read_text());data=discover(config)
    sources=crossmode_sources(data)
    if sources:
        config['crossmode_sources']=sources
        temp=config_path.with_suffix('.new');temp.write_text(json.dumps(config,indent=2)+'\n');temp.chmod(config_path.stat().st_mode & 0o777);temp.replace(config_path)
    p=Path('/etc/mmod/control-profile.json');p.write_text(json.dumps(data));p.chmod(0o644)
    # Writable gateway configuration directories remain explicit, discovered, root-controlled.
    paths=sorted({str(Path(data[k]['ini']).parent) for k in ('ysf','dmr') if k in data})
    for p in ['/var/backups/mmod-v2','/run/mmod-radio-control']:Path(p).mkdir(parents=True,exist_ok=True,mode=0o700)
    drop=Path('/etc/systemd/system/mmod-control.service.d');drop.mkdir(exist_ok=True)
    (drop/'v2.conf').write_text('[Service]\nProtectHome=read-only\nRuntimeDirectory=mmod-radio-control\nRuntimeDirectoryMode=0700\nRuntimeDirectoryPreserve=yes\nReadWritePaths=/run/mmod-radio-control /run/systemd/system /var/backups/mmod-v2 '+ ' '.join(paths)+'\n')
    # Fix only the known erroneous DMRGateway screen stop target, preserving all other units.
    if data.get('dmr'):
        text=subprocess.check_output(['systemctl','cat','dmrgateway.service'],text=True)
        if 'screen -S DMRGateway -D -m' in text and 'ExecStop=/usr/bin/screen -S MMDVMHost -X quit' in text:
            d=Path('/etc/systemd/system/dmrgateway.service.d');d.mkdir(exist_ok=True)
            (d/'90-correct-stop.conf').write_text('[Service]\nExecStop=\nExecStop=/usr/bin/screen -S DMRGateway -X quit\n')
    print('Detected control capabilities:',', '.join(k for k in data if k in ('ysf','dmr','bm_id')) or 'Setup required')
if __name__=='__main__':main()
