"""Refresh the local RadioID directory; retain the last good file on failure."""
import csv
import os
from pathlib import Path
import subprocess

target=Path('/var/lib/mmod/subscribers.csv')
temp=target.with_suffix('.download')
try:
    subprocess.run(['curl','--fail','--location','--silent','--show-error',
                    '--connect-timeout','20','--max-time','900',
                    'https://database.radioid.net/static/user.csv','-o',str(temp)],check=True)
    with temp.open(encoding='utf-8-sig',newline='') as stream:
        rows=csv.DictReader(stream)
        assert {'RADIO_ID','CALLSIGN','FIRST_NAME','CITY','STATE','COUNTRY'} <= set(rows.fieldnames or []), 'Unexpected subscriber format'
        count=sum(1 for row in rows if row['RADIO_ID'].isdigit() and row['CALLSIGN'])
        assert count>10000, 'Incomplete subscriber directory'
    os.chmod(temp,0o644)
    os.replace(temp,target)
    print(f'Updated {count} subscriber records')
finally:
    temp.unlink(missing_ok=True)

