"""Refresh the local RadioID directory; retain the last good file on failure."""
import csv
import json
import os
from pathlib import Path
import subprocess

target=Path('/var/lib/mmod/subscribers.csv')
temp=target.with_suffix('.download')
try:
    subprocess.run(['curl','--fail','--location','--silent','--show-error',
                    '--connect-timeout','20','--max-time','900',
                    'https://database.radioid.net/static/user.csv','-o',str(temp)],check=True)
    with temp.open(encoding='utf-8-sig',newline='') as stream:
        rows=csv.DictReader(stream)
        assert {'RADIO_ID','CALLSIGN','FIRST_NAME','CITY','STATE','COUNTRY'} <= set(rows.fieldnames or []), 'Unexpected subscriber format'
        count=sum(1 for row in rows if row['RADIO_ID'].isdigit() and row['CALLSIGN'])
        assert count>10000, 'Incomplete subscriber directory'
    os.chmod(temp,0o644)
    os.replace(temp,target)
    print(f'Updated {count} subscriber records')
except Exception as error:
    print('Subscriber update failed; keeping last good file:',error)
finally:
    temp.unlink(missing_ok=True)

# Repeater IDs are a separate directory and do not identify an individual operator.
target=Path('/var/lib/mmod/repeaters.json')
temp=target.with_suffix('.download')
try:
    subprocess.run(['curl','--fail','--location','--silent','--show-error',
                    '--connect-timeout','20','--max-time','120',
                    'https://database.radioid.net/static/rptrs.json','-o',str(temp)],check=True)
    rows=json.loads(temp.read_text())['rptrs']
    assert isinstance(rows,list) and sum(1 for r in rows if str(r.get('id') or r.get('locator','')).isdigit() and r.get('callsign'))>1000, 'Incomplete repeater directory'
    os.chmod(temp,0o644)
    os.replace(temp,target)
    print(f'Updated {len(rows)} repeater records')
except Exception as error:
    print('Repeater update failed; keeping last good file:',error)
finally:
    temp.unlink(missing_ok=True)
