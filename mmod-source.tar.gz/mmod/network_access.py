"""Use one IPv4 wildcard listener; preserve port and retire fixed-IP proxies."""
from pathlib import Path
import subprocess,re,shutil,time

def migrate(base=Path('/')):
    env=base/'etc/mmod/listen.env';old=env.read_text()
    port=re.search(r'^MMOD_PORT=([^\r\n]+)',old,re.M)
    if not port or not port[1].isdigit() or not 1<=int(port[1])<=65535:raise ValueError('Invalid existing MMOD port')
    units=base/'etc/systemd/system'
    names=['mmod-44net.socket','mmod-network.socket','mmod-44net.service','mmod-network.service']
    backup=base/('var/backups/mmod-network-'+str(time.time_ns()));backup.mkdir(parents=True,mode=0o700)
    shutil.copy2(env,backup/'listen.env')
    for name in names:
        p=units/name
        if p.exists():shutil.copy2(p,backup/name)
    # Stop obsolete socket listeners before binding every address on the port.
    for name in names:
        if (units/name).exists():
            subprocess.run(['systemctl','disable','--now',name] if name.endswith('.socket') else ['systemctl','stop',name],check=True)
    data=re.sub(r'^MMOD_BIND=[^\r\n]*','MMOD_BIND=0.0.0.0',old,flags=re.M)
    if not re.search(r'^MMOD_BIND=',data,re.M):data+='\nMMOD_BIND=0.0.0.0\n'
    env.write_text(data)
    subprocess.run(['systemctl','daemon-reload'],check=True)
    subprocess.run(['systemctl','restart','mmod'],check=True)
    print('Dashboard listens on every IPv4 interface, port '+port[1]+'. Use http://<this-computer-IP>:'+port[1]+'/')

if __name__=='__main__':migrate()
