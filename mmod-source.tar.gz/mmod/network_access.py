"""Configure explicit dashboard listeners without wildcard exposure or radio changes."""
from pathlib import Path
import subprocess,json,ipaddress,re,shutil,time
networks=[ipaddress.ip_network(n) for n in ['44.0.0.0/8','10.0.0.0/8','172.16.0.0/12','192.168.0.0/16']]
addresses=[];zt=[]
for iface in json.loads(subprocess.check_output(['ip','-j','-4','addr','show','scope','global'])):
 for a in iface.get('addr_info',[]):
  if a.get('family')!='inet':continue
  addr=a['local']
  if any(ipaddress.ip_address(addr) in n for n in networks):
   addresses.append(addr)
   if iface['ifname'].startswith('zt'):zt.append(addr)
p=Path('/etc/mmod/listen.env');s=p.read_text();old=re.search(r'^MMOD_BIND=(.*)$',s,re.M).group(1)
if not addresses:raise RuntimeError('No 44net, ZeroTier or private LAN address detected')
primary=old if old in addresses or old not in ('0.0.0.0','') else (zt or addresses)[0]
port=int(re.search(r'^MMOD_PORT=(.*)$',s,re.M).group(1));assert 1024<=port<=65535
proxy=next((x for x in ['/lib/systemd/systemd-socket-proxyd','/usr/lib/systemd/systemd-socket-proxyd'] if Path(x).exists()),None);assert proxy
backup=Path('/var/backups/mmod-network-'+str(int(time.time())));backup.mkdir(mode=0o700);shutil.copy2(p,backup/'listen.env')
for unit in ['mmod-44net.socket','mmod-network.socket']:
 if Path('/etc/systemd/system/'+unit).exists():subprocess.run(['systemctl','disable','--now',unit],check=True)
for unit in ['mmod-44net.service','mmod-network.service']:
 if Path('/etc/systemd/system/'+unit).exists():subprocess.run(['systemctl','stop',unit],check=True)
p.write_text(re.sub(r'^MMOD_BIND=.*$', 'MMOD_BIND='+primary,s,flags=re.M))
others=[x for x in addresses if x!=primary]
socket='[Unit]\nDescription=MMOD explicit 44net ZeroTier and LAN listeners\n[Socket]\n'+''.join('ListenStream='+a+':'+str(port)+'\n' for a in others)+'FreeBind=true\n[Install]\nWantedBy=sockets.target\n'
service='[Unit]\nDescription=MMOD explicit interface proxy\nRequires=mmod.service\nAfter=mmod.service\n[Service]\nExecStart='+proxy+' '+primary+':'+str(port)+'\nDynamicUser=yes\nNoNewPrivileges=yes\nPrivateTmp=yes\nProtectSystem=strict\nProtectHome=yes\n'
for name,data in ([('mmod-network.socket',socket),('mmod-network.service',service)] if others else []):
 f=Path('/etc/systemd/system')/name
 if f.exists():shutil.copy2(f,backup/name)
 f.write_text(data);f.chmod(0o644)
subprocess.run(['systemctl','daemon-reload'],check=True);subprocess.run(['systemctl','restart','mmod'],check=True)

if others:subprocess.run(['systemctl','enable','--now','mmod-network.socket'],check=True)
print('Dashboard URLs: '+', '.join('http://'+a+':'+str(port)+'/' for a in addresses))
