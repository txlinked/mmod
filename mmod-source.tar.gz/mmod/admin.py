"""Set the local MMOD administrator password: sudo python3 /opt/mmod/admin.py."""
import getpass
import hashlib
import json
import os
from pathlib import Path
import secrets
import shutil
import sqlite3

def set_password(password, root=Path('/var/lib/mmod/state')):
    if len(password) < 6:
        raise ValueError('Use at least 6 characters')
    salt = secrets.token_bytes(32)
    data = dict(username='admin', salt=salt.hex(), hash=hashlib.pbkdf2_hmac('sha256', password.encode(), salt, 600000).hex())
    path = root / 'credentials.json'
    temp = root / 'credentials.new'
    fd = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'w') as stream:
        stream.write(json.dumps(data))
    shutil.chown(temp, user='mmod', group='mmod')
    temp.replace(path)
    if (root / 'auth.sqlite').exists():
        with sqlite3.connect(root / 'auth.sqlite') as con:
            con.execute('DELETE FROM sessions')

if __name__ == '__main__':
    if os.geteuid() != 0:
        raise SystemExit('Run with sudo: sudo python3 /opt/mmod/admin.py')
    password = getpass.getpass('New admin password: ')
    if password != getpass.getpass('Repeat password: '):
        raise SystemExit('Passwords do not match')
    try:
        set_password(password)
    except ValueError as error:
        raise SystemExit(str(error))
    Path('/etc/mmod/initial-admin.txt').unlink(missing_ok=True)
    print('Administrator password updated. Existing sessions signed out.')
