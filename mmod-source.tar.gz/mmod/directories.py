"""Read-only destination directories. Downloads run separately from live radio polling."""
import argparse
import hashlib
import io
import json
import os
from pathlib import Path
import tarfile
import time
import urllib.request

ROOT = Path(os.environ.get('MMOD_ROOT', '/var/lib/mmod'))
BUNDLE = 'https://m17project.org/wpsd/wpsd-hostfiles.tar.bz2'
BM = 'https://api.brandmeister.network/v2/talkgroup'
DAPNET = 'https://hampager.de/api/rubrics'
# Offsets are WPSD file encoding, not assumed repeater routing rules.
FILES = {
    'BrandMeister': ('TGList_BM.txt', 'bm', 0),
    'TGIF': ('TGList_TGIF.txt', 'pair', 5000000),
    'ADN': ('TGList_ADN-NoPrefix.txt', 'pair', 0),
    'AmComm': ('TGList_AmComm-NoPrefix.txt', 'pair', 0),
    'DMR+': ('TGList_DMRp_NoPrefix.txt', 'pair', 0),
    'FreeDMR': ('TGList_FreeDMR.txt', 'pair', 8000000),
    'QuadNet': ('TGList_QuadNet-NoPrefix.txt', 'pair', 0),
    'YSF': ('YSFHosts.txt', 'ysf', 0),
    'FCS': ('FCSHosts.txt', 'fcs', 0),
    'P25': ('TGList_P25.txt', 'pair', 0),
    'NXDN': ('TGList_NXDN.txt', 'pair', 0),
    'D-Star REF': ('DPlus_Hosts.txt', 'host', 0),
    'D-Star XRF': ('DExtra_Hosts.txt', 'host', 0),
    'D-Star DCS': ('DCS_Hosts.txt', 'host', 0),
    'D-Star XLX': ('XLXHosts.txt', 'xlx', 0),
}

def atomic(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(value, ensure_ascii=False), encoding='utf-8')
    temp.chmod(0o644)
    temp.replace(path)

def fetch(url, maximum=12000000):
    request = urllib.request.Request(url, headers={'User-Agent': 'MMOD-directory-updater/1.0'})
    with urllib.request.urlopen(request, timeout=45) as response:
        data = response.read(maximum + 1)
    if len(data) > maximum:
        raise ValueError('Download exceeds size limit')
    return data

def parse_text(data, kind, offset=0):
    text = data.decode('utf-8-sig')
    if '<html' in text.lower() or '<!doctype' in text.lower():
        raise ValueError('Received a web page instead of a directory')
    rows = {}
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        fields = line.split() if kind == 'host' else line.split(';' if ';' in line else ',', 2 if ';' not in line else -1)
        if len(fields) < 2:
            continue
        key = fields[0].strip()
        if kind == 'bm':
            if len(fields) < 3: continue
            name = fields[2]
        elif kind in ('ysf', 'fcs'):
            name = ' · '.join(dict.fromkeys(x.strip() for x in fields[1:3] if x.strip()))
        elif kind in ('host', 'xlx'):
            if kind == 'xlx': key = 'XLX' + key
            name = 'Reflector ' + key
        else:
            name = fields[1]
        if offset and key.isdigit() and offset <= int(key) < offset + 1000000:
            key = str(int(key) - offset)
        if key and name.strip() and len(key) < 40 and len(name) < 500:
            rows[key] = name.strip()
    if not rows: raise ValueError('Directory contains no valid entries')
    return rows

def parse_bm(data):
    value = json.loads(data)
    if not isinstance(value, dict): raise ValueError('Invalid BrandMeister directory')
    rows = {str(k): v.strip() for k, v in value.items() if str(k).isdigit() and isinstance(v, str) and v.strip()}
    if not rows: raise ValueError('Empty BrandMeister directory')
    return rows

def parse_rubrics(data):
    value = json.loads(data)
    if isinstance(value, dict): value = value.get('rows', [])
    if not isinstance(value, list): raise ValueError('Invalid DAPNET rubric list')
    result = {}
    for row in value:
        if not isinstance(row, dict): continue
        row = row.get('doc', row)
        key = row.get('number')
        name = row.get('label') or row.get('name') or row.get('description')
        if key is not None and name: result[str(key)] = str(name)
    if not result: raise ValueError('No public paging rubrics available')
    return result

def load():
    try: return json.loads((ROOT / 'directories.json').read_text(encoding='utf-8'))
    except (OSError, ValueError): return {'lists': {}}

def update(bundle_path=None):
    old = load()
    lists = old.get('lists', {})
    now = time.time()
    def good(network, entries, source, attribution=''):
        lists[network] = dict(entries=entries, updated=now, checked=now, source=source,
                              attribution=attribution, error='')
    def failed(network):
        item = lists.setdefault(network, dict(entries={}, updated=None))
        item.update(checked=now, error='Download unavailable; keeping last successful copy' if item['entries'] else 'List unavailable from upstream')
    try:
        payload = Path(bundle_path).read_bytes() if bundle_path else fetch(BUNDLE)
        with tarfile.open(fileobj=io.BytesIO(payload), mode='r:bz2') as archive:
            def member(name):
                item = archive.getmember('./' + name)
                if not item.isfile() or item.size > 3000000: raise ValueError('Invalid directory member')
                return archive.extractfile(item).read()
            for network, (filename, kind, offset) in FILES.items():
                try:
                    raw = member(filename)
                    entries = parse_text(raw, kind, offset)
                    attribution = '\n'.join(line for line in raw.decode('utf-8-sig').splitlines() if line.startswith('#'))
                    # Keep upstream attribution intact in the local raw cache.
                    raw_dir = ROOT / 'directory-sources'; raw_dir.mkdir(exist_ok=True)
                    (raw_dir / filename).write_bytes(raw)
                    good(network, entries, BUNDLE, attribution)
                    lists[network]['sha256'] = hashlib.sha256(raw).hexdigest()
                except (OSError, ValueError, KeyError, UnicodeError): failed(network)
    except (OSError, ValueError, tarfile.TarError, KeyError):
        for network in FILES: failed(network)
    try: good('BrandMeister', parse_bm(fetch(BM)), BM)
    except (OSError, ValueError):
        if not lists.get('BrandMeister', {}).get('entries'): failed('BrandMeister')
    try:
        local = Path('/etc/mmod/dapnet-rubrics.json')
        good('POCSAG / DAPNET', parse_rubrics(local.read_bytes() if local.is_file() else fetch(DAPNET)),
             'Local DAPNET rubric export' if local.is_file() else DAPNET)
    except (OSError, ValueError): failed('POCSAG / DAPNET')
    atomic(ROOT / 'directories.json', dict(checked=now, schedule='Weekly: Sunday 04:00–05:00 (system time)', lists=lists))
    for network, item in lists.items(): print(network, len(item['entries']), item.get('error') or 'OK')

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--bundle', help='Use a previously downloaded WPSD bundle')
    update(parser.parse_args().bundle)
