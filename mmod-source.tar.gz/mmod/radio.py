"""Fast, independent DMR event snapshots; no radio commands or Internet queries."""
from collections import deque
from functools import lru_cache
import configparser
import csv
import datetime as dt
import json
from pathlib import Path
import re
import sqlite3
import time
from concurrent.futures import ThreadPoolExecutor
from collector import atomic, tail, CONFIG, LIVE, ROOT
from log_capture import native_log, CAPTURE

START = re.compile(r'DMR Slot ([12]), received (RF|network) (?:voice header|late entry) from (\S+) to (?:TG )?(\S+)')
END = re.compile(r'DMR Slot ([12]), received (RF|network) end of voice transmission from (\S+) to (?:TG )?(\S+), ([\d.]+) seconds')
ALIAS = re.compile(r'DMR Slot ([12]), Talker Alias "([^"]*)"')
LOST = re.compile(r'DMR Slot ([12]),.*(?:watchdog.*expired|transmission lost|lost transmission)',re.I)

@lru_cache(maxsize=16384)
def log_timestamp(value):
    return dt.datetime.strptime(value,'%Y-%m-%d %H:%M:%S.%f').replace(tzinfo=dt.timezone.utc).timestamp()

@lru_cache(maxsize=8)
def crossmode_records(signature, offset):
    records=[];header=None
    for filename,mtime,size in signature:
        for line in tail(Path(filename)):
            if not any(word in line for word in ('Received YSF Header:', 'DMR ID', 'YSF received end of voice transmission')):continue
            try:stamp=log_timestamp(line[3:26])
            except ValueError:continue
            match=re.search(r'Received YSF Header: Src: (\S+)',line)
            if match:header=(stamp,match[1])
            match=re.search(r'(?:DMR ID not found, using default ID|DMR ID of \S+): (\d+), DstID: TG (\d+)',line)
            if match and header and 0<=stamp-header[0]<=1:
                records.append([header[0],header[1],match[1],str(int(match[2])+offset),header[0]+3])
            if 'YSF received end of voice transmission' in line:
                for record in records[-2:]:
                    if 0<=stamp-record[0]<=180:record[4]=stamp+3
    return records


def events(lines, now=None):
    now=time.time() if now is None else now
    slots={1:None,2:None}; history=[]
    for line in lines:
        line=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]', '', line).strip('\r\n')
        try: stamp=log_timestamp(line[3:26])
        except ValueError: continue
        match=START.search(line)
        if match:
            slot,source,caller,target=match.groups();slot=int(slot)
            row=dict(time=line[3:26],started=stamp,slot=slot,source=source,caller=caller,target=target,seconds=0.0,active=True,name='',country='')
            row['start_kind']='late' if 'received '+source+' late entry' in line else 'header'
            if slots[slot]:slots[slot]['active']=False
            slots[slot]=row;history.append(row)
        match=ALIAS.search(line)
        if match and slots[int(match[1])] and match[2].strip():
            row=slots[int(match[1])];alias=match[2].strip()
            row['name']=alias[len(row['caller']):].strip() if alias.startswith(row['caller']+' ') else alias
        match=END.search(line)
        if match:
            slot,source,caller,target,seconds=match.groups();slot=int(slot);row=slots[slot]
            if not row or row['caller']!=caller or row['target']!=target:
                row=dict(time=line[3:26],started=stamp-float(seconds),slot=slot,source=source,caller=caller,target=target,name='',country='');history.append(row)
            row.update(active=False,seconds=float(seconds),ended=stamp,loss=(float(re.search(r"([\d.]+)% packet loss",line)[1]) if re.search(r"([\d.]+)% packet loss",line) else None));slots[slot]=None
            row['end_reason']='end'
        match=LOST.search(line)
        if match:
            slot=int(match[1])
            if slots[slot]:
                slots[slot].update(active=False,ended=stamp,seconds=max(0,stamp-slots[slot]['started']),loss=(float(re.search(r'([\d.]+)% packet loss',line)[1]) if re.search(r'([\d.]+)% packet loss',line) else None))
                slots[slot]['end_reason']='watchdog' if 'watchdog' in line.lower() else 'lost'
            slots[slot]=None
        if 'Mode set to Idle' in line:
            for slot in slots:
                if slots[slot]:slots[slot]['active']=False
                slots[slot]=None
    for slot,row in slots.items():
        if row and (now-row['started']>180 or row['started']>now+5):
            row['active']=False;slots[slot]=None
        elif row:row['seconds']=max(0,now-row['started'])
    return dict(updated=now,slots=[dict(slot=n,transmission=slots[n]) for n in (1,2)],activity=history[-40:][::-1])

class Countries:
    def __init__(self,path):
        self.prefixes={};self.exact={}
        if not path.is_file():return
        country=''
        for line in path.read_text(errors='replace').splitlines():
            if line and not line[0].isspace() and ':' in line:country=line.split(':')[0].strip()
            else:
                for value in line.strip().rstrip(';').split(','):
                    key=re.split(r'[({<~\[]',value.strip())[0]
                    if key.startswith('='):self.exact[key[1:]]=country
                    elif key:self.prefixes[key]=country
    def get(self,call):
        call=call.upper()
        if call in self.exact:return self.exact[call]
        if '/' in call:return ''
        for length in range(len(call),0,-1):
            if call[:length] in self.prefixes:return self.prefixes[call[:length]]
        return ''

class Lookup:
    """On-disk index keeps large local subscriber lists out of RAM."""
    def __init__(self, db_path=None):
        self.signature=None;self.db=None;self.repeaters={};self.repeater_signature=None
        self.db_path=db_path or ROOT/'radio-lookup.sqlite'
        self.pending=None;self.executor=None;self.async_signature=None
    def refresh_async(self,path):
        self.finish_refresh()
        paths=[path,ROOT/'repeaters.json']
        signature=tuple((str(p),p.stat().st_mtime_ns,p.stat().st_size) if p and p.is_file() else None for p in paths)
        if self.pending or signature==self.async_signature:return
        if self.executor is None:self.executor=ThreadPoolExecutor(max_workers=1)
        if self.db is None and self.db_path.is_file():
            self.db=sqlite3.connect(self.db_path)
        self.async_signature=signature
        def build():
            worker=Lookup(ROOT/'radio-lookup.next.sqlite')
            worker.refresh(path)
            return worker
        self.pending=self.executor.submit(build)
    def finish_refresh(self):
        if not self.pending or not self.pending.done():return
        pending=self.pending;self.pending=None
        try:
            worker=pending.result()
            if worker.db:
                worker.db.close()
                worker.db_path.replace(self.db_path)
                if self.db:self.db.close()
                self.db=sqlite3.connect(self.db_path)
            self.repeaters=worker.repeaters or self.repeaters
        except (OSError,ValueError,sqlite3.Error):
            self.async_signature=None
    def refresh(self,path):
        repeaters=ROOT/'repeaters.json'
        if repeaters.is_file():
            stat=repeaters.stat();signature=(stat.st_mtime_ns,stat.st_size)
            if signature!=self.repeater_signature:
                try:
                    rows=json.loads(repeaters.read_text())['rptrs']
                    index={str(r.get('id') or r.get('locator')):r for r in rows if r.get('callsign')}
                    if not index:raise ValueError('Empty repeater directory')
                    self.repeaters=index;self.repeater_signature=signature
                except (OSError,ValueError,KeyError,TypeError):pass
        if not path or not path.is_file():return
        sig=(str(path),path.stat().st_mtime_ns,path.stat().st_size)
        if sig==self.signature:return
        if self.db:self.db.close()
        db=sqlite3.connect(self.db_path,check_same_thread=False)
        db.execute('CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY, call TEXT, name TEXT, country TEXT)')
        if 'location' not in [col[1] for col in db.execute('PRAGMA table_info(users)')]:
            db.execute("ALTER TABLE users ADD COLUMN location TEXT DEFAULT ''")
        db.execute('DELETE FROM users')
        with path.open(encoding='utf-8-sig',errors='replace') as f:
            first=f.readline();f.seek(0)
            if ',' in first and any(x in first.lower() for x in ['radio_id','callsign','fname','country']):
                for raw in csv.DictReader(f):
                    row={str(k).strip().lower():str(v or '').strip() for k,v in raw.items()}
                    ident=row.get('radio_id') or row.get('id');call=row.get('callsign') or row.get('call')
                    name=row.get('first_name') or row.get('fname') or (row.get('name','').split() or [''])[0]
                    country=row.get('country','')
                    country='USA' if country in ('United States','United States of America') else country
                    location=', '.join(value for value in [row.get('city',''),row.get('state',''),country] if value and value.lower() not in ('n/a','null','none'))
                    if ident and call:db.execute('INSERT OR REPLACE INTO users (id,call,name,country,location) VALUES (?,?,?,?,?)',(ident,call.upper(),name,country,location))
            else:
                for line in f:
                    parts=line.strip().split(None,2)
                    if len(parts)>=2 and parts[0].isdigit():db.execute('INSERT OR REPLACE INTO users (id,call,name,country,location) VALUES (?,?,?,?,?)',(parts[0],parts[1].upper(),parts[2] if len(parts)>2 else '','',''))
        db.execute('CREATE INDEX IF NOT EXISTS calls ON users(call)');db.commit();self.db=db;self.signature=sig
    def enrich(self,snapshot):
        for row in snapshot['activity']:
            found=self.db.execute('SELECT call,name,country,location FROM users WHERE id=? OR call=? LIMIT 1',(row['caller'],row['caller'])).fetchone() if self.db else None
            if found:
                row['callsign']=found[0];row['name']=found[1] or row['name'];row['country']=found[2];row['location']=found[3]
            elif row.get('caller','').isdigit() and row['caller'] in self.repeaters:
                repeater=self.repeaters[row['caller']]
                country=repeater.get('country','')
                country='USA' if country in ('United States','United States of America') else country
                person=self.db.execute('SELECT name FROM users WHERE call=? LIMIT 1',(repeater['callsign'].upper(),)).fetchone() if self.db else None
                row.update(callsign=repeater['callsign'],name=person[0] if person else '',country=country,
                           location=', '.join(v for v in [repeater.get('city',''),repeater.get('state',''),country] if v),
                           identity_source='RadioID repeater directory')

def crossmode(snapshot, config):
    # Require matching transport ID, mapped target, slot, and start time.
    for source in config.get('crossmode_sources', []):
        for row in snapshot['activity']:
            bounds=source.get('target_range',[])
            routed=str(row['target']) in [str(t) for t in source.get('routed_targets',[])] or (len(bounds)==2 and str(row['target']).isdigit() and bounds[0]<=int(row['target'])<=bounds[1])
            if row['slot']==source['slot'] and routed:
                row['mode']='DMR2YSF'
        folder=Path(source['log_directory'])
        paths=sorted(folder.glob(source.get('log_root','DMR2YSF')+'*.log'),key=lambda p:p.stat().st_mtime)[-2:]
        signature=tuple((str(p),p.stat().st_mtime_ns,p.stat().st_size) for p in paths)
        records=crossmode_records(signature,source.get('target_offset',0))
        for row in snapshot['activity']:
            if row['source']!='network' or row['slot']!=source['slot']:continue
            matches=[r for r in records if r[2]==row['caller'] and r[3]==row['target'] and r[0]<=row['started']<=r[4]]
            if not matches:continue
            match=max(matches,key=lambda r:r[0]);call,_,name=match[1].partition('-')
            if not re.fullmatch(r'[A-Za-z0-9/]+',call):continue
            row['transport_caller']=row['caller'];row['caller']=call;row['name']=name
            row['callsign']=call;row['country']='';row['location']=''
            row['identity_source']='DMR2YSF log';row['mode']='DMR2YSF'


def suppress_bridge_tails(snapshot):
    """Hide only evidenced trailing bridge fragments, never ordinary rekeys."""
    previous={};removed=[];kept=[]
    for row in sorted(snapshot['activity'],key=lambda r:r['started']):
        key=(row['slot'],row['source'],row['caller'],row['target'])
        prior=previous.get(key)
        duplicate=(prior and row.get('mode')=='DMR2YSF' and row.get('start_kind')=='late'
                   and row.get('end_reason')=='watchdog' and (row.get('loss') or 0)>=80
                   and row.get('seconds',999)<=2 and prior.get('end_reason')=='end'
                   and 0<=row['started']-prior.get('ended',0)<=0.25)
        if duplicate:removed.append([row['slot'],row['started'],row['target']])
        else:kept.append(row);previous[key]=row
    snapshot['activity']=list(reversed(kept))
    snapshot['suppressed_calls']=removed

def preserve_history(snapshot, lookup=None):
    """Retain completed, enriched calls beyond the rolling input-log window."""
    path=ROOT/'caller-history.json'
    try: previous=json.loads(path.read_text())
    except (OSError,ValueError): previous=[]
    before=json.dumps(previous,sort_keys=True)
    if lookup:lookup.enrich({'activity':previous})
    for row in previous:label_bridge_identity(row)
    now=snapshot.get('updated',time.time())
    merged={}
    for row in previous+list(reversed(snapshot['activity'])):
        if [row['slot'],row['started'],row.get('target')] in snapshot.get('suppressed_calls',[]):continue
        key=(row['slot'],row['started'],row.get('target'))
        old=merged.get(key,{})
        saved=dict(row)
        for field in ('callsign','name','location','country','identity_source','mode'):
            if not saved.get(field) and old.get(field):saved[field]=old[field]
        merged[key]=saved
    rows=sorted(merged.values(),key=lambda r:r['started'],reverse=True)[:20]
    completed=[r for r in rows if not r.get('active')]
    if json.dumps(completed,sort_keys=True)!=before:atomic(path,completed)
    snapshot['activity']=rows

def service_reply(row):
    """Known network service identities are not individual last callers."""
    return row.get('source') == 'network' and str(row.get('caller', '')) in {'9990', '4000'}

def retain_callers(snapshot, lookup=None):
    path=ROOT/'last-callers.json'
    try:previous=json.loads(path.read_text())
    except (OSError,ValueError):previous={}
    before=json.dumps(previous,sort_keys=True)
    previous={k:r for k,r in previous.items() if not service_reply(r) and [r['slot'],r['started'],r.get('target')] not in snapshot.get('suppressed_calls',[])}
    if lookup:lookup.enrich({'activity':list(previous.values())})
    changed=before!=json.dumps(previous,sort_keys=True)
    for row in list(previous.values())+snapshot['activity']:label_bridge_identity(row)
    for row in reversed(snapshot['activity']):
        if row.get('active') or service_reply(row):continue
        key=str(row['slot']);old=previous.get(key)
        if not old or row['started']>=old['started']:
            saved=dict(row);saved['active']=False
            if old and row['started']==old['started']:
                for field in ('callsign','name','location','country','identity_source','mode'):
                    if not saved.get(field) and old.get(field):saved[field]=old[field]
            if saved!=old:previous[key]=saved;changed=True
    snapshot['last_calls']=list(previous.values())
    if changed:atomic(path,previous)

def seed_event_lines(log, limit=10*1024*1024):
    """Read a bounded startup window; debug audio must not evict call events."""
    retained={1:deque(maxlen=2000),2:deque(maxlen=2000)}
    try:
        with Path(log).open('rb') as stream:
            stream.seek(0,2); end=stream.tell(); start=max(0,end-limit)
            stream.seek(start)
            if start: stream.readline()
            while stream.tell()<end:
                line=stream.readline(min(16384,end-stream.tell())).decode(errors='replace')
                if START.search(line) or END.search(line) or LOST.search(line) or ALIAS.search(line):
                    match=re.search(r"DMR Slot ([12]),",line)
                    if match:retained[int(match[1])].append(line)
    except OSError:
        return tail(log)
    return sorted(list(retained[1])+list(retained[2]),key=lambda line:line[3:26])


def label_bridge_identity(row):
    # Preserve the raw ID for diagnostics; never invent a subscriber for ID 1.
    if row.get('mode')=='DMR2YSF' and row.get('source')=='network' and str(row.get('caller'))=='1' and not row.get('callsign'):
        row['display_caller']='Unknown bridge caller'
    else:
        row.pop('display_caller',None)


def seed_last_callers(log,config,lookup):
    from collections import deque
    per_slot={1:deque(maxlen=100),2:deque(maxlen=100)}
    # Read at most 10 MiB once at startup, retaining only bounded call events.
    for line in seed_event_lines(log):
        match=re.search(r'DMR Slot ([12]),',line)
        if match:per_slot[int(match[1])].append(line)
    for lines in per_slot.values():
        snapshot=events(list(lines))
        crossmode(snapshot,config);lookup.enrich(snapshot);suppress_bridge_tails(snapshot);retain_callers(snapshot);preserve_history(snapshot)


def main():
    seeded=False;lookup=Lookup();countries=Countries(Path("/etc/mmod/cty.dat"));log=None;next_config=0;signature=None
    while True:
        try:
            now=time.time()
            lookup.finish_refresh()
            if now>=next_config:
                config=json.loads(CONFIG.read_text());ini_path=Path(config['mmdvm_ini'])
                ini=configparser.ConfigParser(interpolation=None,strict=False,inline_comment_prefixes=('#',';'));ini.read(ini_path)
                log=native_log(config,ini)
                if not log and not config.get('radio_log_file') and CAPTURE.is_file():log=CAPTURE
                source=config.get('subscriber_file') or ('/var/lib/mmod/subscribers.csv' if Path('/var/lib/mmod/subscribers.csv').is_file() else ini.get('DMR Id Lookup','File',fallback=''))
                path=None
                if source:
                    path=Path(source)
                    if not path.is_absolute():path=ini_path.parent/path
                lookup.refresh_async(path)
                next_config=now+30
            if log:
                if not seeded:seed_last_callers(log,config,lookup);seeded=True
                info=log.stat();sig=(str(log),info.st_mtime_ns,info.st_size)
                if sig!=signature:
                    lines=(tail(CAPTURE.with_suffix('.previous.log')) if log==CAPTURE and CAPTURE.with_suffix('.previous.log').is_file() else [])+tail(log)
                    signature=sig
                snapshot=events(lines,now);crossmode(snapshot,config);lookup.enrich(snapshot);suppress_bridge_tails(snapshot)
                for row in snapshot['activity']:
                    row['country']=row['country'] or countries.get(row.get('callsign',row['caller']))
                snapshot['log_updated']=info.st_mtime
                snapshot['source']='local-log'
                if log==CAPTURE:
                    try:
                        capture=json.loads((LIVE/'log-source.json').read_text())
                        if capture.get('error') or now-capture['updated']>30:snapshot['error']='Local radio log capture unavailable'
                    except (OSError,ValueError,KeyError):snapshot['error']='Waiting for local log capture'
            else:
                snapshot=events([],now);snapshot['error']='No radio log source found; check MMDVM logging settings'
            retain_callers(snapshot,lookup)
            preserve_history(snapshot,lookup)
            atomic(LIVE/'radio.json',snapshot)
        except Exception as error:
            atomic(LIVE/'radio.json',dict(updated=time.time(),error='Radio log unavailable',slots=[],activity=[]))
            next_config=0
        time.sleep(0.5)

if __name__=='__main__':main()
