"""Fast, independent DMR event snapshots; no radio commands or Internet queries."""
from collections import deque
import threading
import configparser
import csv
import datetime as dt
import json
from pathlib import Path
import re
import sqlite3
import time
from collector import atomic, tail, CONFIG, LIVE, ROOT

START = re.compile(r'DMR Slot ([12]), received (RF|network) (?:voice header|late entry) from (\S+) to (?:TG )?(\S+)')
END = re.compile(r'DMR Slot ([12]), received (RF|network) end of voice transmission from (\S+) to (?:TG )?(\S+), ([\d.]+) seconds')
ALIAS = re.compile(r'DMR Slot ([12]), Talker Alias "([^"]*)"')
LOST = re.compile(r'DMR Slot ([12]),.*(?:watchdog.*expired|transmission lost|lost transmission)',re.I)

def events(lines, now=None):
    now=time.time() if now is None else now
    slots={1:None,2:None}; history=[]
    for line in lines:
        try: stamp=dt.datetime.strptime(line[3:26],'%Y-%m-%d %H:%M:%S.%f').replace(tzinfo=dt.timezone.utc).timestamp()
        except ValueError: continue
        match=START.search(line)
        if match:
            slot,source,caller,target=match.groups();slot=int(slot)
            row=dict(time=line[3:26],started=stamp,slot=slot,source=source,caller=caller,target=target,seconds=0.0,active=True,name='',country='')
            if slots[slot]:slots[slot]['active']=False
            slots[slot]=row;history.append(row)
        match=ALIAS.search(line)
        if match and slots[int(match[1])] and match[2].strip():
            row=slots[int(match[1])];alias=match[2].strip()
            row['name']=alias[len(row['caller']):].strip() if alias.startswith(row['caller']+' ') else alias
        match=END.search(line)
        if match:
            slot,source,caller,target,seconds=match.groups();slot=int(slot);row=slots[slot]
            if not row or row['caller']!=caller or row['target']!=target:
                row=dict(time=line[3:26],started=stamp-float(seconds),slot=slot,source=source,caller=caller,target=target,name='',country='');history.append(row)
            row.update(active=False,seconds=float(seconds),ended=stamp,loss=(float(re.search(r"([\d.]+)% packet loss",line)[1]) if re.search(r"([\d.]+)% packet loss",line) else None));slots[slot]=None
        match=LOST.search(line)
        if match:
            slot=int(match[1])
            if slots[slot]:
                slots[slot].update(active=False,ended=stamp,seconds=max(0,stamp-slots[slot]['started']),loss=(float(re.search(r'([\d.]+)% packet loss',line)[1]) if re.search(r'([\d.]+)% packet loss',line) else None))
            slots[slot]=None
        if 'Mode set to Idle' in line:
            for slot in slots:
                if slots[slot]:slots[slot]['active']=False
                slots[slot]=None
    for slot,row in slots.items():
        if row and (now-row['started']>180 or row['started']>now+5):
            row['active']=False;slots[slot]=None
        elif row:row['seconds']=max(0,now-row['started'])
    return dict(updated=now,slots=[dict(slot=n,transmission=slots[n]) for n in (1,2)],activity=history[-40:][::-1])

class Countries:
    def __init__(self,path):
        self.prefixes={};self.exact={}
        if not path.is_file():return
        country=''
        for line in path.read_text(errors='replace').splitlines():
            if line and not line[0].isspace() and ':' in line:country=line.split(':')[0].strip()
            else:
                for value in line.strip().rstrip(';').split(','):
                    key=re.split(r'[({<~\[]',value.strip())[0]
                    if key.startswith('='):self.exact[key[1:]]=country
                    elif key:self.prefixes[key]=country
    def get(self,call):
        call=call.upper()
        if call in self.exact:return self.exact[call]
        if '/' in call:return ''
        for length in range(len(call),0,-1):
            if call[:length] in self.prefixes:return self.prefixes[call[:length]]
        return ''

class Lookup:
    """On-disk index keeps large local subscriber lists out of RAM."""
    def __init__(self):self.signature=None;self.db=None
    def refresh(self,path):
        if not path or not path.is_file():return
        sig=(str(path),path.stat().st_mtime_ns,path.stat().st_size)
        if sig==self.signature:return
        if self.db:self.db.close()
        db=sqlite3.connect(ROOT/'radio-lookup.sqlite')
        db.execute('CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY, call TEXT, name TEXT, country TEXT)')
        if 'location' not in [col[1] for col in db.execute('PRAGMA table_info(users)')]:
            db.execute("ALTER TABLE users ADD COLUMN location TEXT DEFAULT ''")
        db.execute('DELETE FROM users')
        with path.open(encoding='utf-8-sig',errors='replace') as f:
            first=f.readline();f.seek(0)
            if ',' in first and any(x in first.lower() for x in ['radio_id','callsign','fname','country']):
                for raw in csv.DictReader(f):
                    row={str(k).strip().lower():str(v or '').strip() for k,v in raw.items()}
                    ident=row.get('radio_id') or row.get('id');call=row.get('callsign') or row.get('call')
                    name=row.get('first_name') or row.get('fname') or (row.get('name','').split() or [''])[0]
                    country=row.get('country','')
                    country='USA' if country in ('United States','United States of America') else country
                    location=', '.join(value for value in [row.get('city',''),row.get('state',''),country] if value and value.lower() not in ('n/a','null','none'))
                    if ident and call:db.execute('INSERT OR REPLACE INTO users (id,call,name,country,location) VALUES (?,?,?,?,?)',(ident,call.upper(),name,country,location))
            else:
                for line in f:
                    parts=line.strip().split(None,2)
                    if len(parts)>=2 and parts[0].isdigit():db.execute('INSERT OR REPLACE INTO users (id,call,name,country,location) VALUES (?,?,?,?,?)',(parts[0],parts[1].upper(),parts[2] if len(parts)>2 else '','',''))
        db.execute('CREATE INDEX IF NOT EXISTS calls ON users(call)');db.commit();self.db=db;self.signature=sig
    def enrich(self,snapshot):
        if not self.db:return
        for row in snapshot['activity']:
            found=self.db.execute('SELECT call,name,country,location FROM users WHERE id=? OR call=? LIMIT 1',(row['caller'],row['caller'])).fetchone()
            if found:
                row['callsign']=found[0];row['name']=found[1] or row['name'];row['country']=found[2];row['location']=found[3]

class MQTTLogs:
    """Read the host's log topic without changing radio configuration."""
    def __init__(self, ini):
        import paho.mqtt.client as mqtt
        self.lines=deque(maxlen=1500);self.lock=threading.Lock();self.connected=False
        self.topic=ini.get('MQTT','Name',fallback='host').rstrip('/')+'/log'
        self.client=mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
        if ini.getboolean('MQTT','Auth',fallback=False):
            self.client.username_pw_set(ini.get('MQTT','Username',fallback=''),ini.get('MQTT','Password',fallback=''))
        self.client.on_connect=self.on_connect
        self.client.on_disconnect=self.on_disconnect
        self.client.on_message=self.on_message
        self.client.connect_async(ini.get('MQTT','Host',fallback='127.0.0.1'),ini.getint('MQTT','Port',fallback=1883),60)
        self.client.loop_start()
    def on_connect(self,client,userdata,flags,reason,properties):
        self.connected=reason==0
        if self.connected:client.subscribe(self.topic)
    def on_disconnect(self,client,userdata,flags,reason,properties):self.connected=False
    def on_message(self,client,userdata,message):
        if message.retain:return
        with self.lock:self.lines.extend(message.payload.decode('utf-8',errors='replace').splitlines())
    def read(self):
        with self.lock:return list(self.lines)


def main():
    lookup=Lookup();countries=Countries(Path("/etc/mmod/cty.dat"));log=None;next_config=0;signature=None;mqtt_logs=None
    while True:
        try:
            now=time.time()
            if now>=next_config:
                config=json.loads(CONFIG.read_text());ini_path=Path(config['mmdvm_ini'])
                ini=configparser.ConfigParser(interpolation=None,strict=False,inline_comment_prefixes=('#',';'));ini.read(ini_path)
                folder=Path(ini.get('Log','FilePath',fallback=str(ini_path.parent)))
                if not folder.is_absolute():folder=ini_path.parent/folder
                candidates=list(folder.glob(ini.get('Log','FileRoot',fallback='MMDVM')+'*.log'))
                log=max(candidates,key=lambda p:p.stat().st_mtime) if candidates else None
                if not log and ini.has_section('MQTT') and ini.getint('Log','MQTTLevel',fallback=0)>0 and mqtt_logs is None:
                    mqtt_logs=MQTTLogs(ini)
                source=config.get('subscriber_file') or ('/var/lib/mmod/subscribers.csv' if Path('/var/lib/mmod/subscribers.csv').is_file() else ini.get('DMR Id Lookup','File',fallback=''))
                if source:
                    path=Path(source)
                    if not path.is_absolute():path=ini_path.parent/path
                    lookup.refresh(path)
                next_config=now+30
            if mqtt_logs:
                snapshot=events(mqtt_logs.read(),now);lookup.enrich(snapshot)
                snapshot['source']='mqtt'
                if not mqtt_logs.connected:snapshot['error']='MQTT log connection unavailable'
            elif log:
                info=log.stat();sig=(str(log),info.st_mtime_ns,info.st_size)
                if sig!=signature:lines=tail(log);signature=sig
                snapshot=events(lines,now);lookup.enrich(snapshot)
                for row in snapshot['activity']:
                    row['country']=row['country'] or countries.get(row.get('callsign',row['caller']))
                snapshot['log_updated']=info.st_mtime
            else:
                snapshot=events([],now);snapshot['error']='No radio log source found; check MMDVM logging settings'
            atomic(LIVE/'radio.json',snapshot)
        except Exception as error:
            atomic(LIVE/'radio.json',dict(updated=time.time(),error='Radio log unavailable',slots=[],activity=[]))
            next_config=0
        time.sleep(0.5)

if __name__=='__main__':main()
