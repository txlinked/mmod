"""Interactive installer questions. Only validated argument JSON goes to stdout."""
import json
from pathlib import Path, PurePosixPath
import subprocess
import sys
import setup_config

def ask(label, default='', valid=lambda value: bool(value)):
    while True:
        print(f'{label}'+(f' [{default}]' if default else '')+': ', end='', file=sys.stderr, flush=True)
        value=input().strip() or str(default)
        if valid(value): return value
        print('Please enter a valid value.',file=sys.stderr)

def yes(label, default='y'):
    return ask(label+' (y/n)',default,lambda x:x.lower() in ('y','n','yes','no')).lower() in ('y','yes')

def wizard(directory=Path('/etc/mmod')):
    config=json.loads((directory/'config.json').read_text()) if (directory/'config.json').exists() else {}
    env=directory/'listen.env'
    values=dict(line.split('=',1) for line in env.read_text().splitlines() if '=' in line) if env.exists() else {}
    print('\nMMOD setup — press Enter to accept a default.\n',file=sys.stderr)
    text_ok=lambda x: bool(x.strip()) and len(x)<=160 and not any(ord(c)<32 for c in x)
    site=ask('Repeater / dashboard name',config.get('site','My DMR Repeater'),text_ok)
    network=ask('Club or network name',config.get('network','MMOD'),text_ok)
    bind='0.0.0.0'
    print('Dashboard listens on all IPv4 interfaces (LAN, ZeroTier and 44net).',file=sys.stderr)
    port=ask('Web port',values.get('MMOD_PORT','8000'),lambda x:x.isdigit() and 1024<=int(x)<=65535)
    candidates=['/etc/mmdvmhost','/etc/mmdvmhost.ini','/home/repeater/MMDVM-Host/MMDVM-Host.ini','/home/repeater/MMDVMHost/MMDVM.ini','/etc/mmdvm/MMDVM.ini','/etc/mmdvmhost/MMDVM.ini','/etc/MMDVM.ini']
    ini=config.get('mmdvm_ini') or next((p for p in candidates if Path(p).is_file()),'/etc/mmdvm/MMDVM.ini')
    service=config.get('host_service') or ('mmdvm-host.service' if Path('/home/repeater/MMDVM-Host/MMDVM-Host.ini').is_file() else 'mmdvmhost.service')
    print(f'\nRadio configuration: {ini}'+(' (found)' if Path(ini).is_file() else ' (not installed yet; system dashboard will still work)'),file=sys.stderr)
    print(f'Radio service: {service}\nDefault: keep the settings above. Press Enter to continue.',file=sys.stderr)
    if yes('Change these radio settings?', 'n'):
        ini=ask('Full path to MMDVM.ini',ini,lambda x:PurePosixPath(x).is_absolute())
        service=ask('MMDVMHost service name',service,lambda x:bool(__import__('re').fullmatch(r'[A-Za-z0-9_.@-]+\.service',x)))
    args=['--site',site,'--network',network,'--bind',bind,'--port',port,'--ini',ini,'--host-service',service]
    plan=setup_config.make_plan(setup_config.parser().parse_args(args),directory)
    setup_config.check_interface(plan)
    print(f'\nReady to install {site}\nDashboard: http://<this-computer-IP>:{port}\nAdmin username: admin\nRadio settings will not be changed.\n',file=sys.stderr)
    if not yes('Start installation?'): raise ValueError('Installation cancelled. No settings were changed.')
    return args

if __name__=='__main__':
    try: print(json.dumps(wizard()))
    except (ValueError,EOFError,KeyboardInterrupt) as error:
        print(str(error) or 'Installation cancelled.',file=sys.stderr)
        sys.exit(1)
